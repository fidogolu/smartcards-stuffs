/*
* Copyright (c) 2006, Matthijs Koot (matthijs at koot.biz)
* All rights reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the Koot Organization nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================

  CHIPKNIPTINKER.CPP

  License     : BSD-style (yep, just sell it!)
  Author      : Matthijs Koot (matthijs at koot.biz)
  Description : CChipknipTinker specification.

  History :
     2007-12-29, mrkoot: file created

  Remarks :
    - none

*/

#include "StdAfx.h"

#include "APDUScanner.h"
#include "APDUScannerDlg.h"

#include "smartcard.h"
#include "chipknip.h"
#include "mpcos.h"

#include ".\chipkniptinker.h"

CChipknipTinker::CChipknipTinker(void)
{
}

CChipknipTinker::~CChipknipTinker(void)
{
}

UINT CChipknipTinker::doTinker()
{
	long lReturn = 0; // some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = theApp.dlg.m_pSmartCard->m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	// SUBMIT_CERTIFICATE
	// BYTE bcAPDU1[] = { 0xE1, 0x5a, 0x00, 0x00, 0x08, 0xDE, 0xAD, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF };

	// Perform sequential scan on AC bytes
	BYTE bAC1=0,bAC2=0,bAC3=0,bAC4=0,bAC5=0,bAC6=0,bAC7=0;

	  //for (bAC7 = 0x00; bAC7 <= 0xFF; bAC7++)
	    //for (bAC6 = 0x00; bAC6 <= 0xFF; bAC6++)
          //for (bAC5 = 0x00; bAC5 <= 0xFF; bAC5++)
	        //for (bAC4 = 0x00; bAC4 <= 0xFF; bAC4++)
	          //for (bAC3 = 0x00; bAC3 <= 0xFF; bAC3++)
	            //for (bAC2 = 0x00; bAC2 <= 0xFF; bAC2++)
                  for (bAC1 = 0x00; bAC1 <= 0xFF; bAC1++)
				  {	
					if (theApp.dlg.m_bChipknipTinkerThreadIsRunning == false)
					{ // user pressed 'Stop' 
						theApp.dlg.m_pSmartCard->CardDisconnect();
						TerminateThread(GetCurrentThread(), 0);					
					}


					// establish a fresh context to continue the scan
					theApp.dlg.m_pSmartCard->CardDisconnect();

					BYTE bRawATR[60];
					DWORD dwATRlen = 0;
					ZeroMemory( bRawATR, 60 );
					if (!theApp.dlg.m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen ))
					{
						theApp.dlg.m_pSmartCard->CardDisconnect();
						theApp.dlg.OnBnClickedBtnstop();
						TerminateThread(GetCurrentThread(), -1);
						theApp.dlg.WriteToLog("SCAN ABORTED: there was an error while trying to continue the scan!");
						return -1; // never reached due to TerminateThread
					}

					// INITIALIZE_UPDATE
					BYTE bcAPDU1[] = { 0xE1, 0x50, 0x05, 0x00, 0x0E };
					BYTE brAPDU1[256+2];
					LPBYTE pbcAPDU1 = bcAPDU1;
					LPBYTE pbrAPDU1 = brAPDU1;
					DWORD dwrAPDU1 = 16;
					ZeroMemory( brAPDU1, sizeof(brAPDU1) );
					////theApp.dlg.WriteToLog("Sending INITIALIZE_UPDATE {" + theApp.dlg.ConvertBytesToHexString(sizeof(bcAPDU1), bcAPDU1, true) + "}... ");
					lReturn = SCardTransmit( theApp.dlg.m_pSmartCard->m_hSCardHandle, SCARD_PCI_T0, bcAPDU1, sizeof(bcAPDU1), &ioRecvPci, pbrAPDU1, &dwrAPDU1 );
					if (lReturn != SCARD_S_SUCCESS)
					{		
						theApp.dlg.m_pSmartCard->handleSCardError(lReturn, "SCardTransmit");
						return -1;
					}
					////theApp.dlg.WriteToLog("  Received response APDU: {" + theApp.dlg.ConvertBytesToHexString(dwrAPDU1, brAPDU1, true) + "}", true); 
					/*theApp.dlg.WriteToLog("    IEP_HOST_ID  = {" + theApp.dlg.ConvertBytesToHexString(3, &brAPDU1[0], true) + "}");
					theApp.dlg.WriteToLog("    PUR_ID       = {" + theApp.dlg.ConvertBytesToHexString(5, &brAPDU1[3], true) + "}");
					theApp.dlg.WriteToLog("    PUR_SEC_ALGO = {" + theApp.dlg.ConvertBytesToHexString(1, &brAPDU1[8], true) + "}");
					theApp.dlg.WriteToLog("    PUR_KV_ID    = {" + theApp.dlg.ConvertBytesToHexString(1, &brAPDU1[9], true) + "}");
					theApp.dlg.WriteToLog("    PUR_RAND     = {" + theApp.dlg.ConvertBytesToHexString(4, &brAPDU1[10], true) + "}");*/
	
					// UPDATE_PARAMETER_OR_KEY
					//
					// CLA = E1 for IEP
					// INS = 58 for par/key update (, INS = D6 for data update (yields 6D00 on current cards?)
					// P1 =  01 for key update, P1 = 02 for par update
					// P2 = 00 (always)
					// P3 = 1A for par1, 1B for par2, 27 for keyd, 1f for keys
					//
					// then...
					// PUR_PARAM_ID = 7 bytes (unknown) --> PUR_PARAM_ID[2] must be 0x01 - 0x06?
					// SAM_ID = 4 bytes
					// PDV_RAND = 4 bytes random number
					// NEW_VALUE = 3 or 4 bytes for par update; 8 bytes for single key update; 16 bytes for double key update
					// IEP_TX_UPD_PAR_AC = 8 bytes authentication code supplied byh SAM to validate the parameter or key
					//
					// 9405 ==> BAD_UPD
					// 9302 ==> BAD_AC
					// 6A86 ==> BAD_PAR
					//BYTE bcAPDU2[] = { 0xE1, 0x58, 0x02, 0x00, 0x1A, 0xDE, 0xAD, 0xBE, 0xEF, 0x33, 0x33, 0x33, 0x44, 0x44, 0x44, 0x44, 0x55, 0x55, 0x55, 0x55, 0x66, 0x66, 0x66, 0x66, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77 };

					
					// Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3}  { ------------PUR_PARAM_ID------------- } { ------SAM_ID------- } { ------PDV_RAND------ } { -----NEW_VALUE------ } { ----------IEP_TX_UPD_PAR_AC----------- } 
					//BYTE bcAPDU2[] = { 0xE1, 0x58, 0x02, 0x00, 0x1A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x05, 0xF8, 0x03, 0xF4, 0xFF, 0xFF, 0xFF, 0xFF, 0x66, 0x66, 0x66, 0x66, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77 };

					//BYTE bcAPDU2[] = { 0xE1, 0x58, 0x02, 0x00, 0x1A, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0x66, 0x66, 0x66, 0x66, bAC1, bAC2, bAC3, bAC4, bAC5, bAC6, bAC7 };
					BYTE bcAPDU2[] = { 0xE1, 0x58, 0x02, 0x00, 0x1A, bAC1 };

					// this yields a 9302 (BAD AC):  BYTE bcAPDU2[] = { 0xE1, 0x58, 0x02, 0x00, 0x1A, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0x66, 0x66, 0x66, 0x66, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
					BYTE brAPDU2[256+2];

					// copy PDV_RAND from last response
					//memcpy(&bcAPDU2[16], &brAPDU1[10], 4);

					LPBYTE pbcAPDU2 = bcAPDU2;
					LPBYTE pbrAPDU2 = brAPDU2;
					DWORD dwrAPDU2 = 2;
					ZeroMemory( brAPDU2, sizeof(brAPDU2) );
					////theApp.dlg.WriteToLog("Sending UPDATE_PARAMETER_OR_KEY {" + theApp.dlg.ConvertBytesToHexString(sizeof(bcAPDU2), bcAPDU2, true) + "}... ");

					CString log = "Trying command APDU {" + theApp.dlg.ConvertBytesToHexString(sizeof(bcAPDU2), bcAPDU2, true) + "}...";
					theApp.dlg.c_txtCurrentAPDU.SetWindowText(log);
					theApp.dlg.WriteToLog("  " + log); 
					lReturn = SCardTransmit( theApp.dlg.m_pSmartCard->m_hSCardHandle, SCARD_PCI_T0, bcAPDU2, sizeof(bcAPDU2), &ioRecvPci, pbrAPDU2, &dwrAPDU2 );
					if (lReturn != SCARD_S_SUCCESS)
					{		
						theApp.dlg.WriteToLog(" failed.", true);
						//theApp.dlg.m_pSmartCard->handleSCardError(lReturn, "SCardTransmit");
						//return -1;
					}
					else
					{						
						theApp.dlg.WriteToLog("SUCCES!", true);
						theApp.dlg.WriteToLog("    Response data: {" + theApp.dlg.ConvertBytesToHexString(dwrAPDU2, brAPDU2, true) + "}", false); 
					}
					
				}

	return 0;
}



UINT CChipknipTinker::doTest()
{


	return 0;
}


UINT CChipknipTinker::ChipknipTinkerThread(LPVOID param)
{
	theApp.dlg.m_bChipknipTinkerThreadIsRunning = true;

    BYTE bRawATR[60];
	DWORD dwATRlen = 0;
    ZeroMemory( bRawATR, 60 );


    /*------
    Prepare */

		if (!theApp.dlg.m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen ))
		{
			theApp.dlg.m_pSmartCard->CardDisconnect();
			theApp.dlg.OnBnClickedBtnstop();
			TerminateThread(GetCurrentThread(), -1);
			return -1; // never reached due to TerminateThread
		}
		theApp.dlg.WriteToLog( "Answer-To-Reset: " + theApp.dlg.ConvertBytesToHexString( dwATRlen, bRawATR, true ) + "\r\n", true );	


    /*------
    Tinker */
	
		//UINT ret = doTinker();		
		UINT ret = doTest();


    /*------
    clean up */

		theApp.dlg.m_pSmartCard->CardDisconnect();

		char dateStr [9];
		char timeStr [9];
		_strdate(dateStr);
		_strtime(timeStr);
		theApp.dlg.WriteToLog("------ TINKER attempt completed on " + CString(dateStr) + " at " + CString(timeStr));
		theApp.dlg.WriteToLog("===========================================================");

		theApp.dlg.m_bChipknipTinkerThreadIsRunning = false;

		// enable GUI
		theApp.dlg.ToggleGUI(theApp.dlg.GUI_DEFAULT);

		CString sCurrentAPDU;
		theApp.dlg.c_txtCurrentAPDU.GetWindowText(sCurrentAPDU);
		theApp.dlg.c_txtCurrentAPDU.SetWindowText("");

	AfxEndThread(ret);
	return ret;

}


