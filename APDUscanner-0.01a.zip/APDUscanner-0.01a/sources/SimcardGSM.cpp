/*
* Copyright (c) 2006, Matthijs Koot (matthijs at koot.biz)
* All rights reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the Koot Organization nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================

  SIMCARDGSM.CPP

  License     : BSD-style (yep, just sell it!)
  Author      : Matthijs Koot (matthijs at koot.biz)
  Description : CSimcardGSM specification.

  History :
     2008-05-18, mrkoot: file created


  Remarks :
    - none

*/


#include "StdAfx.h"

#include "APDUScanner.h"
#include "APDUScannerDlg.h"

#include ".\simcardgsm.h"

CSimcardGSM::CSimcardGSM(void)
{
}

CSimcardGSM::~CSimcardGSM(void)
{
}


/*---------------------------------------------------------------------
  Name   : UNBLOCK_CHV()
  Param  : (out) byte *pbStatusSW12 --> store returned SW12 status bytes
		   (in) byte bCHVno --> 0x01 for PIN1, 0x02 for PIN2, etc.
		   (in) byte bUnblockCHV[8] --> PUK code (appended by FFs)
		   (in) byte bNewCHV[8] --> new PIN code (appended by FFs)
		   (in) bool bSuppressOutput --> if true, no output is written
  Pre    : -
  Post   : -
  Return : void

  Description:
    Sends an UNBLOCK_CHV command APDU to the GSM SIM.
---------------------------------------------------------------------*/
void CSimcardGSM::UNBLOCK_CHV(byte *pbStatusSW12, byte bCHVno, byte bUnblockCHV[8], byte bNewCHV[8], bool bSuppressOutput)
{
  //-------
  // UNBLOCK_CHV command APDU (GSM SIM-cards):
  //
  // CLA  = 0xA0 (fixed)
  // INS  = 0x2C 
  // P1   = 0x00
  // P2   = CHVno (0x00=CHV1, 0x02=CHV2) 
  //        --> NOTE: the coding of CHV1 (0x00) is different from its coding elsewhere (0x01)!
  // P3   = 0x10
  // Data = 8-bytes PUK-code + 8 bytes new PIN
  //
  // Preconditions: 
  //   -
  //-------

	// Kill thread if user pressed 'Stop'
	if (theApp.dlg.m_bGSMDumperThreadIsRunning == false)
	{
		theApp.dlg.m_pSmartCard->CardDisconnect();		
		TerminateThread(GetCurrentThread(), 0);
	}

  // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3}  

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd;	

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = 0xA0; // CLA = instruction class field
	cmd.bIns = 0x2C; // INS = instruction code
	cmd.bP1  = 0x00; // P1  = parameter 1 
	cmd.bP2  = bCHVno; // P2  = parameter 2
	cmd.bP3  = 0x10; //bLcRecv; // P3  = Le (expected size of IO transfer)
	memcpy(bSend, &cmd, sizeof(cmd));
	memcpy(&bSend[5], bUnblockCHV, 8);
	memcpy(&bSend[13], bNewCHV, 8);

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND) + 8 + 8;
	DWORD dwRecvLength = cmd.bP3 + 2; // Lc + 2 status bytes

	if (!bSuppressOutput) theApp.dlg.WriteToLog("    Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) 
	{
		theApp.dlg.WriteToLog("    Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");

		if (bRecv[dwRecvLength-2] == 0x90)
		{
			theApp.dlg.WriteToLog("    Response data (hex) = {" + theApp.dlg.ConvertBytesToHexString(dwRecvLength-2, &bRecv[0], true) + "}");
			CString sContents;
			for (UINT i=0; i < (dwRecvLength - 2); i++)
			if (bRecv[i] != 0x00)
				sContents.AppendChar(bRecv[i]);
			theApp.dlg.WriteToLog("    Response data (ASCII) = {" + sContents + "}");
		}
	}
	
	// copy response APDU to buffer
	//if (pbResponse)
	//	memcpy(pbResponse, &bRecv, bReadLn);
	
	// copy SW12 to buffer
	if (pbStatusSW12)
		memcpy(pbStatusSW12, &bRecv, 2);

}


/*---------------------------------------------------------------------
  Name   : ENABLE_CHV()
  Param  : (out) byte *pbStatusSW12 --> store returned SW12 status bytes
		   (in) byte bNewCHV[8] --> new PIN code (appended by FFs)
		   (in) bool bSuppressOutput --> if true, no output is written
  Pre    : -
  Post   : -
  Return : void

  Description:
    Sends an ENABLE_CHV command APDU to the GSM SIM.
---------------------------------------------------------------------*/
void CSimcardGSM::ENABLE_CHV(byte *pbStatusSW12, byte bNewCHV1[8], bool bSuppressOutput)
{
  //-------
  // ENABLE_CHV command APDU (GSM SIM-cards):
  //
  // CLA  = 0xA0 (fixed)
  // INS  = 0x28
  // P1   = 0x00
  // P2   = 0x01
  // P3   = 0x08
  // Data = New CHV bytes (i.e. PIN-code)
  //
  // Preconditions: 
  //   -
  //-------

	// Kill thread if user pressed 'Stop'
	if (theApp.dlg.m_bGSMDumperThreadIsRunning == false)
	{
		theApp.dlg.m_pSmartCard->CardDisconnect();		
		TerminateThread(GetCurrentThread(), 0);
	}

  // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3}  

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = 0xA0; // CLA = instruction class field
	cmd.bIns = 0x28; // INS = instruction code
	cmd.bP1  = 0x00; // P1  = parameter 1 
	cmd.bP2  = 0x01; // P2  = parameter 2
	cmd.bP3  = 0x08; //bLcRecv; // P3  = Le (expected size of IO transfer)
	memcpy(bSend, &cmd, sizeof(cmd));
	memcpy(&bSend[5], bNewCHV1, 8);

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND) + 8;
	DWORD dwRecvLength = cmd.bP3 + 2; // Lc + 2 status bytes

	if (!bSuppressOutput) theApp.dlg.WriteToLog("    Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) 
	{
		theApp.dlg.WriteToLog("    Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");

		if (bRecv[dwRecvLength-2] == 0x90)
		{
			theApp.dlg.WriteToLog("    Response data (hex) = {" + theApp.dlg.ConvertBytesToHexString(dwRecvLength-2, &bRecv[0], true) + "}");
			CString sContents;
			for (UINT i=0; i < (dwRecvLength - 2); i++)
			if (bRecv[i] != 0x00)
				sContents.AppendChar(bRecv[i]);
			theApp.dlg.WriteToLog("    Response data (ASCII) = {" + sContents + "}");
		}
	}
	
	// copy response APDU to buffer
	//if (pbResponse)
	//	memcpy(pbResponse, &bRecv, bReadLn);
	
	// copy SW12 to buffer
	if (pbStatusSW12)
		memcpy(pbStatusSW12, &bRecv, 2);

}


/*---------------------------------------------------------------------
  Name   : DISABLE_CHV()
  Param  : (out) byte *pbStatusSW12 --> store returned SW12 status bytes
		   (in) byte bCurrentCHV1[8] --> current PIN code (appended by FFs)
		   (in) bool bSuppressOutput --> if true, no output is written
  Pre    : -
  Post   : -
  Return : void

  Description:
    Sends an DISABLE_CHV command APDU to the GSM SIM.
---------------------------------------------------------------------*/
void CSimcardGSM::DISABLE_CHV(byte *pbStatusSW12, byte bCurrentCHV1[8], bool bSuppressOutput)
{
  //-------
  // DISABLE_CHV command APDU (GSM SIM-cards):
  //
  // CLA  = 0xA0 (fixed)
  // INS  = 0x26
  // P1   = 0x00
  // P2   = 0x01
  // P3   = 0x08
  // Data = Current CHV bytes (i.e. current PIN-code)
  //
  // Preconditions: 
  //   -
  //-------

	// Kill thread if user pressed 'Stop'
	if (theApp.dlg.m_bGSMDumperThreadIsRunning == false)
	{
		theApp.dlg.m_pSmartCard->CardDisconnect();		
		TerminateThread(GetCurrentThread(), 0);
	}

  // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3}  

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd;	

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = 0xA0; // CLA = instruction class field
	cmd.bIns = 0x26; // INS = instruction code
	cmd.bP1  = 0x00; // P1  = parameter 1 
	cmd.bP2  = 0x01; // P2  = parameter 2
	cmd.bP3  = 0x08; //bLcRecv; // P3  = Le (expected size of IO transfer)
	memcpy(bSend, &cmd, sizeof(cmd));
	memcpy(&bSend[5], bCurrentCHV1, 8);

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND) + 8;
	DWORD dwRecvLength = cmd.bP3 + 2; // Lc + 2 status bytes

	if (!bSuppressOutput) theApp.dlg.WriteToLog("    Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) 
	{
		theApp.dlg.WriteToLog("    Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");

		if (bRecv[dwRecvLength-2] == 0x90)
		{ 
			theApp.dlg.WriteToLog("    Response data (hex) = {" + theApp.dlg.ConvertBytesToHexString(dwRecvLength-2, &bRecv[0], true) + "}");
			CString sContents;
			for (UINT i=0; i < (dwRecvLength - 2); i++)
			if (bRecv[i] != 0x00)
				sContents.AppendChar(bRecv[i]);
			theApp.dlg.WriteToLog("    Response data (ASCII) = {" + sContents + "}");
		}
	}
	
	// copy response APDU to buffer
	//if (pbResponse)
	//	memcpy(pbResponse, &bRecv, bReadLn);
	
	// copy SW12 to buffer
	if (pbStatusSW12)
		memcpy(pbStatusSW12, &bRecv, 2);

}



/*---------------------------------------------------------------------
  Name   : READ_RECORD()
  Param  : (out) byte *pbStatusSW12 --> store returned SW12 status bytes
           (out) byte *pbResponse --> store read data
		   (in) byte bReadLn --> number of bytes to read (record length)
		   (in) byte bRecordNr --> record number
		   (in) byte bMode --> e.g. current, next, previous
		   (in) bool bSuppressOutput --> if true, no output is written
  Pre    : -
  Post   : -
  Return : void

  Description:
    Sends an READ_RECORD command APDU to the GSM SIM.
---------------------------------------------------------------------*/
void CSimcardGSM::READ_RECORD(byte *pbStatusSW12, byte *pbResponse, byte bReadLn, byte bRecordNr, byte bMode, bool bSuppressOutput)
{ 
  //-------
  // READ_RECORD command APDU (GSM SIM-cards):
  //
  // CLA  = 0xA0 (fixed)
  // INS  = 0xB2 
  // P1   = record nr (not used when P2=next or P2=previous)
  // P2   = reading mode
  //        0x00: current record
  //        0x02: next record
  //        0x03: previous record
  //        0x04: absolute mode
  // P3   = read length
  //
  // Preconditions: 
  //   1. An EF must have been selected
  //-------

	// Kill thread if user pressed 'Stop'
	if (theApp.dlg.m_bGSMDumperThreadIsRunning == false)
	{
		theApp.dlg.m_pSmartCard->CardDisconnect();
		TerminateThread(GetCurrentThread(), 0);
	}


  // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3}  

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = 0xA0; // CLA = instruction class field
	cmd.bIns = 0xB2; // INS = instruction code
	cmd.bP1  = bRecordNr; // P1  = parameter 1 
	cmd.bP2  = bMode; // P2  = parameter 2
	cmd.bP3  = bReadLn; //bLcRecv; // P3  = Le (expected size of IO transfer)
	memcpy(bSend, &cmd, sizeof(cmd));

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND);
	DWORD dwRecvLength = cmd.bP3 + 2; // Lc + 2 status bytes

	if (!bSuppressOutput) theApp.dlg.WriteToLog("    Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) 
	{
		theApp.dlg.WriteToLog("    Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");

		if (bRecv[dwRecvLength-2] == 0x90)
		{
			theApp.dlg.WriteToLog("    Response data (hex) = {" + theApp.dlg.ConvertBytesToHexString(dwRecvLength-2, &bRecv[0], true) + "}");
			CString sContents;
			for (UINT i=0; i < (dwRecvLength - 2); i++)
			if (bRecv[i] != 0x00)
				sContents.AppendChar(bRecv[i]);
			theApp.dlg.WriteToLog("    Response data (ASCII) = {" + sContents + "}");
		}
	}
	
	// copy response APDU to buffer
	if (pbResponse)
		memcpy(pbResponse, &bRecv, bReadLn);
	
	// copy SW12 to buffer
	if (pbStatusSW12)
		memcpy(pbStatusSW12, &bRecv, 2);


}


/*---------------------------------------------------------------------
  Name   : READ_BINARY()
  Param  : (out) byte *pbStatusSW12 --> store returned SW12 status bytes
           (out) byte *pbResponse --> store read data
		   (in) byte bReadLn --> number of bytes to read (record length)
		   (in) byte bOffsetMSB --> offset MSB
		   (in) byte bOffsetLSB --> offset LSB
		   (in) bool bSuppressOutput --> if true, no output is written
  Pre    : -
  Post   : -
  Return : void

  Description:
    Sends an READ_BINARY command APDU to the GSM SIM.
---------------------------------------------------------------------*/
void CSimcardGSM::READ_BINARY(byte *pbStatusSW12, byte *pbResponse, byte bReadLn, byte bOffsetMSB, byte bOffsetLSB, bool bSuppressOutput)
{ 
  //-------
  // READ_BINARY command APDU (GSM SIM-cards):
  //
  // CLA  = 0xA0 (fixed)
  // INS  = 0xB0 
  // P1   = offset MSB 
  // P2   = offset LSB
  // P3   = length
  // Data = File ID (2 bytes)
  //
  // Known File IDs:
  //   - see ETSI TS 100 977
  //   - GSM MF is at 0x3F00
  //   - 
  //	
  // Preconditions: 
  //   1. none
  //-------

	// Kill thread if user pressed 'Stop'
	if (theApp.dlg.m_bGSMDumperThreadIsRunning == false)
	{
		theApp.dlg.m_pSmartCard->CardDisconnect();		
		TerminateThread(GetCurrentThread(), 0);
	}

  // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3}  

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = 0xA0; // CLA = instruction class field
	cmd.bIns = 0xB0; // INS = instruction code
	cmd.bP1  = bOffsetMSB; // P1  = parameter 1 
	cmd.bP2  = bOffsetLSB; // P2  = parameter 2
	cmd.bP3  = bReadLn; //bLcRecv; // P3  = Le (expected size of IO transfer)
	memcpy(bSend, &cmd, sizeof(cmd));

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND);
	DWORD dwRecvLength = cmd.bP3 + 2; // Lc + 2 status bytes

	if (!bSuppressOutput) theApp.dlg.WriteToLog("    Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) 
	{
		theApp.dlg.WriteToLog("    Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");

		if (bRecv[dwRecvLength-2] == 0x90)
		{
			theApp.dlg.WriteToLog("    Response data (hex) = {" + theApp.dlg.ConvertBytesToHexString(dwRecvLength-2, &bRecv[0], true) + "}");
			CString sContents;
			for (UINT i=0; i < (dwRecvLength - 2); i++)
			if (bRecv[i] != 0x00)
				sContents.AppendChar(bRecv[i]);
			theApp.dlg.WriteToLog("    Response data (ASCII) = {" + sContents + "}");
		}
	}
	
	// copy response APDU to buffer
	if (pbResponse)
		memcpy(pbResponse, &bRecv, bReadLn);
	
	// copy SW12 to buffer
	if (pbStatusSW12)
		memcpy(pbStatusSW12, &bRecv, 2);
}


/*---------------------------------------------------------------------
  Name   : GET_RESPONSE()
  Param  : (out) byte *pbStatusSW12 --> store returned SW12 status bytes
           (out) byte *pbResponse --> store read data
		   (in) byte bReadLn --> number of bytes to read (record length)
		   (in) bool bSuppressOutput --> if true, no output is written
  Pre    : -
  Post   : -
  Return : void

  Description:
    Sends an GET_RESPONSE command APDU to the GSM SIM.
---------------------------------------------------------------------*/
void CSimcardGSM::GET_RESPONSE(byte *pbStatusSW12, byte *pbResponse, byte bReadLn, bool bSuppressOutput)
{ 
  //-------
  // GET_RESPONSE command APDU (GSM SIM-cards):
  //
  // CLA  = 0xA0 (fixed)
  // INS  = 0xC0 
  // P1   = 0x00
  // P2   = 0x00
  // P3   = number of response bytes
  // Data = response bytes
  //
  // Preconditions: 
  //   1. Some response-generated command APDU must have been sent
  //-------

	// Kill thread if user pressed 'Stop'
	if (theApp.dlg.m_bGSMDumperThreadIsRunning == false)
	{
		theApp.dlg.m_pSmartCard->CardDisconnect();		
		TerminateThread(GetCurrentThread(), 0);
	}

  // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3}  

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = 0xA0; // CLA = instruction class field
	cmd.bIns = 0xC0; // INS = instruction code
	cmd.bP1  = 0x00; // P1  = parameter 1 
	cmd.bP2  = 0x00; // P2  = parameter 2
	cmd.bP3  = bReadLn; //bLcRecv; // P3  = Le (expected size of IO transfer)
	memcpy(bSend, &cmd, sizeof(cmd));

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND);
	DWORD dwRecvLength = cmd.bP3 + 2; // Lc + 2 status bytes

	if (!bSuppressOutput) theApp.dlg.WriteToLog("    Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) 
	{
		theApp.dlg.WriteToLog("    Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");

		if (bRecv[dwRecvLength-2] == 0x90)
		{
			theApp.dlg.WriteToLog("    Response data (hex) = {" + theApp.dlg.ConvertBytesToHexString(dwRecvLength-2, &bRecv[0], true) + "}");
			CString sContents;
			for (UINT i=0; i < (dwRecvLength - 2); i++)
			if (bRecv[i] != 0x00)
				sContents.AppendChar(bRecv[i]);
			theApp.dlg.WriteToLog("    Response data (ASCII) = {" + sContents + "}");
		}
	}
	
	// copy response APDU to buffer
	if (pbResponse)
		memcpy(pbResponse, &bRecv, bReadLn);
	
	// copy SW12 to buffer
	if (pbStatusSW12)
		memcpy(pbStatusSW12, &bRecv, 2);
}

/*---------------------------------------------------------------------
  Name   : SELECT()
  Param  : (out) byte *pbStatusSW12 --> store returned SW12 status bytes
		   (in) byte bFileID[2] --> File ID of file to select (EF/DF/MF)
		   (in) bool bSuppressOutput --> if true, no output is written
  Pre    : -
  Post   : -
  Return : void

  Description:
    Sends an SELECT command APDU to the GSM SIM.
---------------------------------------------------------------------*/
void CSimcardGSM::SELECT(byte *pbStatusSW12, byte bFileID[2], bool bSuppressOutput)
{
  //-------
  // SELECT command APDU (GSM SIM-cards):
  //
  // CLA  = 0xA0 (fixed)
  // INS  = 0xA4 
  // P1   = 0x00 
  // P2   = 0x00 
  // P3   = 0x02 
  // Data = File ID (2 bytes)
  //
  // Known File IDs:
  //   - see ETSI TS 100 977
  //   - GSM MF is at 0x3F00
  //   - 
  //	
  // Preconditions: 
  //   1. none
  //-------

	
	// Kill thread if user pressed 'Stop'
	if (theApp.dlg.m_bGSMDumperThreadIsRunning == false)
	{
		theApp.dlg.m_pSmartCard->CardDisconnect();		
		TerminateThread(GetCurrentThread(), 0);
	}
	
	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = 0xA0; // CLA = instruction class field 
	cmd.bIns = 0xA4; // INS = instruction code 
	cmd.bP1  = 0x00; // P1  = parameter 1 
	cmd.bP2  = 0x00; // P2  = parameter 2 
	cmd.bP3  = 0x02; // P3  = Le (expected size of IO transfer)
	memcpy(bSend, &cmd, sizeof(cmd));

	bSend[5] = bFileID[0];
	bSend[6] = bFileID[1];

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND) + cmd.bP3; // CLA/INS/P1/P2/P3 is followed by <cmd.bP3> extra command bytes 
	DWORD dwRecvLength = 2;	// we'll only receive 2 status bytes, e.g. 0x9000

	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{		
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
	//if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response data = (n/a)");

	// copy SW12 to buffer
	if (pbStatusSW12)
	  memcpy(pbStatusSW12, &bRecv, 2);

}



/*---------------------------------------------------------------------
  Name   : VERIFY_CHV()
  Param  : (out) byte *pbStatusSW12 --> store returned SW12 status bytes
		   (in) byte bCHVno --> 0x01 for PIN1, 0x02 for PIN2, etc.
		   (in) byte bPINcode[8] --> PIN code (appended by FFs)
		   (in) bool bSuppressOutput --> if true, no output is written
  Pre    : -
  Post   : -
  Return : void

  Description:
    Sends an VERIFY_CHV command APDU to the GSM SIM.
---------------------------------------------------------------------*/
void CSimcardGSM::VERIFY_CHV(byte *pbStatusSW12, byte bCHVno, byte bPINcode[8], bool bSuppressOutput)
{	
  //-------
  // VERIFY CHV command APDU (GSM SIM-cards):
  //
  // CLA  = 0xA0 (fixed)
  // INS  = 0x20 
  // P1   = 0x00 
  // P2   = CHV nr ("PIN number": PIN1 or PIN2)
  // P3   = 0x08 
  // Data = PIN code (8 bytes)
  //
  // Preconditions: 
  //   1. none
  //-------
	
	// Kill thread if user pressed 'Stop'
	if (theApp.dlg.m_bGSMDumperThreadIsRunning == false)
	{
		theApp.dlg.m_pSmartCard->CardDisconnect();		
		TerminateThread(GetCurrentThread(), 0);
	}
	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = 0xA0; // CLA = instruction class field 
	cmd.bIns = 0x20; // INS = instruction code 
	cmd.bP1  = 0x00; // P1  = parameter 1 
	cmd.bP2  = bCHVno; // P2  = parameter 2 
	cmd.bP3  = 0x08; // P3  = Le (expected size of IO transfer)

	memcpy(bSend, &cmd, sizeof(cmd));
	memcpy(&bSend[5], bPINcode, 8); // "8" is hardcoded because sizeof(bPINcode) returns 4

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND) + cmd.bP3; // CLA/INS/P1/P2/P3 is followed by <cmd.bP3> extra command bytes 
	DWORD dwRecvLength = 2;	// we'll only receive 2 status bytes, e.g. 0x9000

	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{		
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
	//if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response data = (n/a)");

	// copy SW12 to buffer
	if (pbStatusSW12)
	  memcpy(pbStatusSW12, &bRecv, 2);

}


/*---------------------------------------------------------------------
  Name   : UPDATE_RECORD()
  Param  : (out) byte *pbStatusSW12 --> store returned SW12 status bytes
		   (in) byte *pbNewData --> data to write
		   (in) byte bWriteLn --> number of bytes to write
		   (in) byte bRecordNr --> record number
		   (in) byte bMode --> e.g. current, next, previous
		   (in) bool bSuppressOutput --> if true, no output is written
  Pre    : -
  Post   : -
  Return : void

  Description:
    Sends an UPDATE_RECORD command APDU to the GSM SIM.
---------------------------------------------------------------------*/
void CSimcardGSM::UPDATE_RECORD(byte *pbStatusSW12, byte *pbNewData, BYTE bWriteLn, byte bRecordNr, byte bMode, bool bSuppressOutput)
{	
  //-------
  // UPDATE_RECORD command APDU (GSM SIM-cards):
  //
  // CLA  = 0xA0 (fixed)
  // INS  = 0xDC 
  // P1   = record nr (not used when P2=next or P2=previous)
  // P2   = writing mode
  //        0x00: current record
  //        0x02: next record
  //        0x03: previous record
  //        0x04: absolute mode
  // P3   = I/O length
  // Data = data to write
  //
  // Preconditions: 
  //   1. none
  //-------
	// Kill thread if user pressed 'Stop'
	if (theApp.dlg.m_bGSMDumperThreadIsRunning == false)
	{
		theApp.dlg.m_pSmartCard->CardDisconnect();		
		TerminateThread(GetCurrentThread(), 0);
	}
	
	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = 0xA0; // CLA = instruction class field 
	cmd.bIns = 0xDC; // INS = instruction code 
	cmd.bP1  = bRecordNr; // P1  = parameter 1 
	cmd.bP2  = bMode; // P2  = parameter 2 
	cmd.bP3  = bWriteLn; // P3  = Le (expected size of IO transfer)

	memcpy(bSend, &cmd, sizeof(cmd));
	memcpy(&bSend[5], pbNewData, bWriteLn); // "8" is hardcoded because sizeof(bPINcode) returns 4

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND) + cmd.bP3; // CLA/INS/P1/P2/P3 is followed by <cmd.bP3> extra command bytes 
	DWORD dwRecvLength = 2;	// we'll only receive 2 status bytes, e.g. 0x9000

	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{		
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
	//if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response data = (n/a)");

	// copy SW12 to buffer
	if (pbStatusSW12)
	  memcpy(pbStatusSW12, &bRecv, 2);
}




/*---------------------------------------------------------------------
  Name   : UPDATE_BINARY()
  Param  : (out) byte *pbStatusSW12 --> store returned SW12 status bytes
		   (in) byte *pbNewData --> data to write
		   (in) byte bWriteLn --> number of bytes to write
		   (in) byte bRecordNr --> record number
		   (in) byte bMode --> e.g. current, next, previous
		   (in) bool bSuppressOutput --> if true, no output is written
  Pre    : -
  Post   : -
  Return : void

  Description:
    Sends an UPDATE_BINARY command APDU to the GSM SIM.
---------------------------------------------------------------------*/
void CSimcardGSM::UPDATE_BINARY(byte *pbStatusSW12, byte *pbNewData, BYTE bWriteLn, byte bOffsetMSB, byte bOffsetLSB, bool bSuppressOutput)
{	
  //-------
  // UPDATE_RECORD command APDU (GSM SIM-cards):
  //
  // CLA  = 0xA0 (fixed)
  // INS  = 0xD6 
  // P1   = offset MSB
  // P2   = offset LSB
  // P3   = I/O length
  // Data = data to write
  //
  // Preconditions: 
  //   1. none
  //-------
	// Kill thread if user pressed 'Stop'
	if (theApp.dlg.m_bGSMDumperThreadIsRunning == false)
	{
		theApp.dlg.m_pSmartCard->CardDisconnect();		
		TerminateThread(GetCurrentThread(), 0);
	}
	
	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = 0xA0; // CLA = instruction class field 
	cmd.bIns = 0xD6; // INS = instruction code 
	cmd.bP1  = bOffsetMSB; // P1  = parameter 1 
	cmd.bP2  = bOffsetLSB; // P2  = parameter 2 
	cmd.bP3  = bWriteLn; // P3  = Le (expected size of IO transfer)

	memcpy(bSend, &cmd, sizeof(cmd));
	memcpy(&bSend[5], pbNewData, bWriteLn); // "8" is hardcoded because sizeof(bPINcode) returns 4

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND) + cmd.bP3; // CLA/INS/P1/P2/P3 is followed by <cmd.bP3> extra command bytes 
	DWORD dwRecvLength = 2;	// we'll only receive 2 status bytes, e.g. 0x9000

	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{		
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
	//if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response data = (n/a)");

	// copy SW12 to buffer
	if (pbStatusSW12)
	  memcpy(pbStatusSW12, &bRecv, 2);
}





/*---------------------------------------------------------------------
  Name   : DumpInfo_ReadAndDecodeADN()
  Param  : -
  Pre    : EFadn should be selected
  Post   : -
  Return : void

  Description:
    Attempts to read/dump currently selected EFadn file.
---------------------------------------------------------------------*/
void CSimcardGSM::DumpInfo_ReadAndDecodeADN(byte *pbResponse, byte bResponseLn)
{ 
	BYTE bStatusSW12[2];
	BYTE *pbStatusSW12 = bStatusSW12;

	byte bFileSize[2] = {pbResponse[2], pbResponse[3]};
	UINT iFileSize = bFileSize[0] << 8 | bFileSize[1];
    byte bStructureType = pbResponse[13];	
	byte bRecordSize = pbResponse[14];
	int iNumRecords = iFileSize / bRecordSize;

	theApp.dlg.WriteToLog("  Reading (record mode)... ");

	CSimcardGSM *pCard = ((CSimcardGSM*)theApp.dlg.m_pSmartCard);

	if ((bStructureType == 0x01) || (bStructureType == 0x03))
	{
		//----- NOTE
		// iMAX_RECORDS specifies a "time out" to prevent loops
		// (set it to the maximum likely number of records) 
		//int iMAX_RECORDS = 256; 
		int iCounter=0;
		//while ((bStatusSW12[0] != 0x94) && iCounter < iMAX_RECORDS)
		while ((bStatusSW12[0] != 0x94) && iCounter < iNumRecords)
		{ 
			// read next record
			pCard->READ_RECORD(pbStatusSW12, pbResponse, bRecordSize, 0x00, 0x02, true);

			// expected response: 90 00
			// 98 04 --> seems to occur if not authenticated (VERIFY_CHV required)

			//-----			
			// Address book item decoding
			//-----
			CString sName;
			int iNameLn = bRecordSize - 14;
			for (int i=0; i < iNameLn; i++)
			{
				if (pbResponse[i] == 0xFF) break;
				sName.AppendChar(pbResponse[i]);
			}
			
			CString sTelNr;
			int iTelLn = pbResponse[iNameLn];

			if (pbResponse[iNameLn+1] == 0x91)
				sTelNr.AppendChar('+');
				//sTelNr.AppendChar('\+');
			else if ((pbResponse[iNameLn+i] == 0xFF) || (pbResponse[iNameLn+i] == 0x81))
			{ // suppress (not an international number)
			}
			else sTelNr.AppendChar(pbResponse[iNameLn+1]);

			for (int i=2; i < iTelLn; i++)
			{
				if (pbResponse[iNameLn+i] == 0xFF) break;
				byte b = pbResponse[iNameLn+i];
				byte bReversed = ((b >> 4) & 15) | (b << 4);				
				sTelNr.Append(theApp.dlg.ConvertBytesToHexString(1, &bReversed));
			}

			theApp.dlg.WriteToLog("    Item: '" + sName + " ("  + sTelNr + ")'");
			iCounter++;
		}
	} else
		theApp.dlg.WriteToLog("  ERROR --> this file is not of a known record-based format, skipping... ");
	
	pCard = 0;
}

/*---------------------------------------------------------------------
  Name   : DumpInfo_ReadAndDecodeSMS()
  Param  : -
  Pre    : EFsms should be selected
  Post   : -
  Return : void

  Description:
    Attempts to read/dump currently selected EFsms file.
---------------------------------------------------------------------*/
void CSimcardGSM::DumpInfo_ReadAndDecodeSMS(byte *pbResponse, byte bResponseLn)
{ 
	BYTE bStatusSW12[2];
	BYTE *pbStatusSW12 = bStatusSW12;

	byte bFileSize[2] = {pbResponse[2], pbResponse[3]};
	UINT iFileSize = bFileSize[0] << 8 | bFileSize[1];
    byte bStructureType = pbResponse[13];	
	byte bRecordSize = pbResponse[14];
	int iNumRecords = iFileSize / bRecordSize;

	theApp.dlg.WriteToLog("  Reading (record mode)... ");

	CSimcardGSM *pCard = ((CSimcardGSM*)theApp.dlg.m_pSmartCard);

	if ((bStructureType == 0x01) || (bStructureType == 0x03))
	{
		//----- NOTE
		// iMAX_RECORDS specifies a "time out" to prevent loops
		// (set it to the maximum likely number of records) 
		//int iMAX_RECORDS = 256; 
		int iCounter=0;
		//while ((bStatusSW12[0] != 0x94) && iCounter < iMAX_RECORDS)
		while ((bStatusSW12[0] != 0x94) && iCounter < iNumRecords)
		{ 
			// read next record
			pCard->READ_RECORD(pbStatusSW12, pbResponse, bRecordSize, 0x00, 0x02);

			//-----
			// SMS decoding 
			// adapted from Stefan Siegl: http://brokenpipe.de/misc/chipcard/sim-intro.html)
			//-----

			byte bStatus = pbResponse[0];
			byte bSMSCln = pbResponse[1];

			int iPosFromLn = 2 + bSMSCln + 1;
			byte bFromln = pbResponse[iPosFromLn];

			int iSkip = (int) (ceil((float)bFromln / 2));
			int iMsgStart = iPosFromLn + iSkip + 3 + 8;

			byte bMsgLn  = pbResponse[iMsgStart];
			byte bMsg  = pbResponse[iMsgStart+1];

			unsigned char cEncodedSMS[255];
			ZeroMemory(cEncodedSMS, 255);
			unsigned char *pcEncodedSMS = cEncodedSMS;
			memcpy(pcEncodedSMS, &pbResponse[iMsgStart], pbResponse[iMsgStart]);

			char *pcSMS = new char[bMsgLn+1];
			int len = cEncodedSMS[0];  
			unsigned char *inp = cEncodedSMS + 1;

			for(int i = 0; i <= len; i ++) 
			{
				int ipos = i - i / 8;
				int offset = i % 8;
				pcSMS[i] = (inp[ipos] & (0x7F >> offset)) << offset;

				if(offset)
					pcSMS[i] |= (inp[ipos - 1] & (0x7F << (8 - offset)) & 0xFF) >> (8 - offset);
			}

			pcSMS[bMsgLn] = 0x00;
			
			CString sSMS = pcSMS;
			theApp.dlg.WriteToLog("    --> SMS message = '" + sSMS + "'");

			inp = 0;
			pcSMS = 0;
			pcEncodedSMS = 0;

			iCounter++;
		}
	} else
		theApp.dlg.WriteToLog("  ERROR --> this file is not of a known record-based format, skipping... ");
	
	pCard = 0;

}

/*---------------------------------------------------------------------
  Name   : DumpInfo_ReadSelectedFile()
  Param  : -
  Pre    : -
  Post   : -
  Return : void

  Description:
    Attempts to read/dump currently selected file. Tries both
	READ_BINARY or READ_RECORD.
---------------------------------------------------------------------*/
void CSimcardGSM::DumpInfo_ReadSelectedFile(byte *pbResponse, byte bResponseLn) // byte bStructureType, int iFileSize)
{ // READ_BINARY 
	BYTE bStatusSW12[2];
	BYTE *pbStatusSW12 = bStatusSW12;

	byte bFileSize[2] = {pbResponse[2], pbResponse[3]};
	UINT iFileSize = bFileSize[0] << 8 | bFileSize[1];

    byte bStructureType = pbResponse[13];

	theApp.dlg.WriteToLog("  Reading (binary mode)... ");
	CSimcardGSM *pCard = ((CSimcardGSM*)theApp.dlg.m_pSmartCard);

	if (bStructureType == 0x00) // transparent 
	{
		UINT iRead = 0;
		while (iRead < iFileSize)
		{
			byte bReadLn;
			int iLeft = iFileSize - iRead;
			if (iLeft < 0xFF)
				bReadLn = (byte)iLeft;			
			else
				bReadLn = 0xFF;
			
			pCard->READ_BINARY(pbStatusSW12, pbResponse, bReadLn, 0x00, 0x00);
				
			// expected: 90 00
			if (bStatusSW12[0]==0x67)
			{ // wrong read length, try again with length suggested in SW2
				/*theApp.dlg.WriteToLog("  Reading (binary mode, corrected length)... ");
				pCard->READ_BINARY(pbStatusSW12, pbResponse, bReadLn, 0x00, 0x00);

				if (bStatusSW12[0]==0x90)
					iRead += bReadLn;
				//else: to-be-fixed*/
			}
			iRead += bReadLn;
		}
	}
	else if ((bStructureType == 0x01) || (bStructureType == 0x03))
	{
	//if ((bStatusSW12[0]==0x94) && (bStatusSW12[1]==0x08))
	//{ // wrong reading method --> try READ_RECORD
		theApp.dlg.WriteToLog("  Reading (record mode)... ");

		byte bRecordSize = pbResponse[14]; // from GET_RESPONSE
		int iNumRecords = iFileSize / bRecordSize;

		//pCard->READ_RECORD(pbStatusSW12, pbResponse, bReadSize, 0x00, 0x00);

		/*if (bStatusSW12[0]==0x67)
		{ // wrong read length, try again with length suggested in SW2
			theApp.dlg.WriteToLog("  Reading (record mode, corrected length)... ");
			bReadSize = bStatusSW12[1];
		}*/

		//----- NOTE
		// iMAX_RECORDS specifies a "time out" to prevent loops
		// (set it to the maximum likely number of records) 
		int iCounter=0;
		while ((bStatusSW12[0] != 0x94) && iCounter < iNumRecords)
		{ 
			// read next record
			pCard->READ_RECORD(pbStatusSW12, pbResponse, bRecordSize, 0x00, 0x02);
			iCounter++;
		}
	//}

	}
	
	pCard = 0;
}

/*---------------------------------------------------------------------
  Name   : DumpInfo()
  Param  : -
  Pre    : -
  Post   : -
  Return : void

  Description:
    Writes a dump of most EF/DFs specified in ETSI TS 100.977. It 
	SELECTs the	files by their FID (hardcoded here) and attempts 
	a READ_BINARY. If that doesn't work, it attempts READ_RECORD 
	(if that successful in which case it loops through all records).
	If P3 was incorrect, it retries with the suggestion from SW2.
---------------------------------------------------------------------*/
void CSimcardGSM::DumpInfo()
{
	//
	// TODO:
	// At this point, we could inspect the ATR bytes to see if it matches a GSM SIM card.
	//
	BYTE bStatusSW12[2];
	BYTE *pbStatusSW12 = bStatusSW12;
	BYTE bResponse[255];
	BYTE *pbResponse = bResponse;


	//============================== 
	// Structure of result from GET_RESPONSE after selecting EF:
	//-------
	// bResponse[0-1] --> RFU
	// bResponse[2-3] --> File size
	// bResponse[4-5] --> File ID
	// bResponse[6]   --> Type of file:
	//                     0x00=RFU
	//                     0x01=MF
	//                     0x02=DF
	//                     0x04=EF
	// bResponse[7]   --> for cyclic EF, b7=1 indicates that INCREASE is allowed
	// bResponse[8-10]--> Access conditions
	// bResponse[11]  --> File status
	// bResponse[13]  --> Structure of file:
	//                     0x00=transparent --> READ/UPDATE BINARY
	//                     0x01=linear fixed --> READ/UPDATE RECORD, SEEK
	//                     0x03=cyclic --> READ/UPDATE RECORD, INCREASE
	// bResponse[14]  --> Length of a record (for non-transparent files)
	//
	//============================== 
	//
	// Structure of result from GET_RESPONSE after selecting DF/MF:
	//-------
	// bResponse[0-1] --> RFU
	// bResponse[2-3] --> "Total amount of memory of the selected directory 
	//                     which is not allocated to any of the DFs or EFs 
	//                     under the selected directory"
	// bResponse[4-5] --> File ID
	// bResponse[6]   --> Type of file:
	//                     0x00=RFU
	//                     0x01=MF
	//                     0x02=DF
	//                     0x04=EF
	// bResponse[7-11]--> RFU
	// bResponse[12]  --> length of following data
	//
	// bResponse[13-33] --> GSM specific data
	//         bResponse[13] --> File characteristics
	//         bResponse[14] --> Number of DF below current DF/MF
	//         bResponse[15] --> Number of EF below current DF/MF
	//         bResponse[16] --> Number of CHVs, UNBLOCK CHVs and administrative codes
	//         bResponse[17] --> RFU
	//         bResponse[18] --> CHV1 status (see "Status byte of secret code")
	//         bResponse[19] --> UNBLOCK CHV1 (idem)
	//         bResponse[20] --> CHV2 status (idem)
	//         bResponse[21] --> UNBLOCK CHV2 (idem)
	// 
	// ------------------------------------
	// --> "Status byte of secret code":
	// ------------------------------------
	// (b8 is first bit, b1 is last bit)
	//
	// b8-b7 ---> 1: secret code initialized
	//            0: secret code not initialized
    // b6-b5 ---> RFU
    // b4-b1 ---> number of attempts remaining
    //

	CSimcardGSM *pCard = ((CSimcardGSM*)theApp.dlg.m_pSmartCard);
	

	//-------------------------------------------------
	// MF
	//-------------------------------------------------
			
		{ // MF
			theApp.dlg.WriteToLog("Selecting MF... ");
			BYTE bFID[2] = { 0x3F, 0x00 };
			pCard->SELECT(pbStatusSW12, bFID);

			// expected: 9F 22 (SW2 is length of response data)
			if (bStatusSW12[0] == 0x9F)
			{
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);

				CString sNumDFs; sNumDFs.Format("%d", bResponse[14]);
				theApp.dlg.WriteToLog("  Number of DFs below MF: " + sNumDFs);
				CString sNumEFs; sNumEFs.Format("%d", bResponse[15]);
				theApp.dlg.WriteToLog("  Number of EFs below MF: " + sNumEFs);
				CString sNumCHVs; sNumCHVs.Format("%d", bResponse[16]);
				theApp.dlg.WriteToLog("  Number of CHVs, UNBLOCK CHVs and administrative codes: " + sNumCHVs);

				theApp.dlg.WriteToLog("  CHV1 status: " +  DumpInfo_DecodeCHVStatusByte(bResponse[18]));
				theApp.dlg.WriteToLog("  UNBLOCK CHV1 status: " + DumpInfo_DecodeCHVStatusByte(bResponse[19]));
				theApp.dlg.WriteToLog("  CHV2 status: " + DumpInfo_DecodeCHVStatusByte(bResponse[20]));
				theApp.dlg.WriteToLog("  UNBLOCK CHV2 status: " + DumpInfo_DecodeCHVStatusByte(bResponse[21]));
			}
		}

		/*{ // DISABLE CHV1
			BYTE bCHV1[8] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };

			CString sPIN = "0000";
			bCHV1[0] = sPIN[0];
			bCHV1[1] = sPIN[1];
			bCHV1[2] = sPIN[2];
			bCHV1[3] = sPIN[3];
			
			theApp.dlg.WriteToLog("Disabling CHV1... ");
			pCard->DISABLE_CHV(pbStatusSW12, bCHV1);
			// expected: 90 00
		}

		{ // ENABLE CHV1
			BYTE bCHV1[8] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };

			CString sPIN = "0000";
			bCHV1[0] = sPIN[0];
			bCHV1[1] = sPIN[1];
			bCHV1[2] = sPIN[2];
			bCHV1[3] = sPIN[3];
			
			theApp.dlg.WriteToLog("Enabling CHV1... ");
			pCard->ENABLE_CHV(pbStatusSW12, bCHV1);
			// expected: 90 00
		}
		{ // UNBLOCK CHV1
			BYTE bUnblockCHV1[8] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
			BYTE bNewCHV1[8] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };

			CString sPUKcode = "68418993";
			for (int i=0;i < sPUKcode.GetLength(); i++)
				bUnblockCHV1[i] = sPUKcode[i];

			
			CString sNewPIN = "9605";
			for (int i=0;i < sNewPIN.GetLength(); i++)
				bNewCHV1[i] = sNewPIN[i];
			
			theApp.dlg.WriteToLog("Unblocking CHV1... ");
			pCard->UNBLOCK_CHV(pbStatusSW12, 0x00, bUnblockCHV1, bNewCHV1);
			// expected: 90 00
			// 98 04 --> - seems to occur when trying to unblock a non-blocked CHV?
			//           - also seems to occur when using wrong PUK (remaining attempts decreases by 1)
			// 6B 00 --> - seems to occur when trying to unblock a non-existing CHV?
		}
		*/


	
		
		if (theApp.dlg.c_chkUsePIN_GSMSIM.GetCheck()==1)
		{ // VERIFY CHV1
			CString sPIN;
			theApp.dlg.c_txtPIN_GSMSIM.GetWindowText(sPIN);
			if (sPIN.GetLength() == 0)
			{
				AfxMessageBox("You checked the 'Use PIN' (GSM SIM) box, but didn't enter a PIN-code. Aborting read.");
				pCard = 0;
				return;
			}

			BYTE bCHV1[8] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };

			for (int i=0; i < sPIN.GetLength(); i++) 
				bCHV1[i] = sPIN[i];

			theApp.dlg.WriteToLog("\r\nVerifying CHV1... ");
			pCard->VERIFY_CHV(pbStatusSW12, 0x01, bCHV1);

			// expected: 90 00
			// 98 08 --> seems to occur if CHV1 was disabled ("remaining attempts" is not decreased for a wrong CHV, because it is not matched at all)  
			// 98 04 --> seems to occur on wrong PIN
			if (bStatusSW12[0]!=0x90)
			{ // PIN incorrect, ask if user wants to continue
				
				// get number of remaining attempts by reselecting MF and inspecting the response
				BYTE bFID[2] = { 0x3F, 0x00 };
				pCard->SELECT(pbStatusSW12, bFID, true);
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1], true);

				CString s; s.Format("PIN-code incorrect! %d attempts remaining. Do you want to continue unauthenticated? \r\n (only non-ACLd files can be dumped)", (bResponse[18] & 15));
				if (AfxMessageBox(s, MB_YESNO) != IDYES)
				{
					theApp.dlg.WriteToLog("DUMP CANCELLED");
					pCard = 0;
					return;
				}
			}
		}
		
		{ // EFiccid
			theApp.dlg.WriteToLog("\r\nSelecting EFiccid (ICC identification)... ");
			BYTE bFID[2] = { 0x2F, 0xE2 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F			
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);

				CString sICCid;
				for (int i=0; i < bResponseLn; i++)
					sICCid.AppendFormat("%d", pbResponse[i]);
				theApp.dlg.WriteToLog("  SIM card number (ICC ID): " + sICCid);
			}
		}		

		
		{ // EFelp
			theApp.dlg.WriteToLog("\r\nSelecting EFelp (Extended Language)... ");
			BYTE bFID[2] = { 0x2F, 0x05 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

	//-------------------------------------------------
	// DFgsm
	//-------------------------------------------------
		
		{ // DFgsm 
			theApp.dlg.WriteToLog("\r\nSelecting DFgsm... ");
			BYTE bFID[2] = { 0x7F, 0x20 };
			pCard->SELECT(pbStatusSW12, bFID);

			// expected: 9F 22 (SW2 is length of response data)
			if (bStatusSW12[0] == 0x9F)
			{
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);

				// List some DF-related details
				CString sNumDFs; sNumDFs.Format("%d", bResponse[14]);
				theApp.dlg.WriteToLog("  Number of DFs below DFgsm: " + sNumDFs);
				CString sNumEFs; sNumEFs.Format("%d", bResponse[15]);
				theApp.dlg.WriteToLog("  Number of EFs below DFgsm: " + sNumEFs);
				CString sNumCHVs; sNumCHVs.Format("%d", bResponse[16]);
				theApp.dlg.WriteToLog("  Number of CHVs, UNBLOCK CHVs and administrative codes: " + sNumCHVs);
			}
		}
		

		
		{ // EFkc
			theApp.dlg.WriteToLog("\r\nSelecting EFkc (Ciphering key Kc)... ");
			BYTE bFID[2] = { 0x6F, 0x20 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFkcgprs  
			theApp.dlg.WriteToLog("\r\nSelecting EFkcgprs (GPRS ciphering key KcGPRS)... ");
			BYTE bFID[2] = { 0x6F, 0x52 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}


		{ // EFlp
			theApp.dlg.WriteToLog("\r\nSelecting EFlp (Language Preference)... ");
			BYTE bFID[2] = { 0x6F, 0x05 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F (SW2 is length of response data)
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		
		{ // EFimsi
			theApp.dlg.WriteToLog("\r\nSelecting EFimsi (IMSI)... ");
			BYTE bFID[2] = { 0x6F, 0x07 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFspn
			theApp.dlg.WriteToLog("\r\nSelecting EFspn (Service Provider Name)... ");
			BYTE bFID[2] = { 0x6F, 0x46 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFgid1
			theApp.dlg.WriteToLog("\r\nSelecting EFgid1 (Group Identifier 1)... ");
			BYTE bFID[2] = { 0x6F, 0x3E };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFgid2
			theApp.dlg.WriteToLog("\r\nSelecting EFgid2 (Group Identifier 2)... ");
			BYTE bFID[2] = { 0x6F, 0x3F };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFpuct
			theApp.dlg.WriteToLog("\r\nSelecting EFpuct (Price per unit and currency table)... ");
			BYTE bFID[2] = { 0x6F, 0x41 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFcbmi 
			theApp.dlg.WriteToLog("\r\nSelecting EFcbmi (Cell Broadcast Message Identifier)... ");
			BYTE bFID[2] = { 0x6F, 0x45 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFlocigprs  
			theApp.dlg.WriteToLog("\r\nSelecting EFlocigprs (GPRS location information)... ");
			BYTE bFID[2] = { 0x6F, 0x53 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFbcch  
			theApp.dlg.WriteToLog("\r\nSelecting EFbcch (BCCH information)... ");
			BYTE bFID[2] = { 0x6F, 0x74 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFacc  
			theApp.dlg.WriteToLog("\r\nSelecting EFacc (Access control class)... ");
			BYTE bFID[2] = { 0x6F, 0x78 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFfplmns 
			theApp.dlg.WriteToLog("\r\nSelecting EFfplmns (Forbidden PLMNs)... ");
			BYTE bFID[2] = { 0x6F, 0x7B };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFloci 
			theApp.dlg.WriteToLog("\r\nSelecting EFloci (Location information)... ");
			BYTE bFID[2] = { 0x6F, 0x7E };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFad
			theApp.dlg.WriteToLog("\r\nSelecting EFad (Administrative data)... ");
			BYTE bFID[2] = { 0x6F, 0xAD };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
	//-------------------------------------------------
	// DFtelecom
	//-------------------------------------------------
	
		
		{ // DFtelecom
			theApp.dlg.WriteToLog("\r\nSelecting DFtelecom... ");
			BYTE bFID[2] = { 0x7F, 0x10 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 22

			// expected: 9F 22 (SW2 is length of response data)
			if (bStatusSW12[0] == 0x9F)
			{
				// List some DF-related details
				CString sNumDFs; sNumDFs.Format("%d", bResponse[14]);
				theApp.dlg.WriteToLog("  Number of DFs below DFtelecom: " + sNumDFs);
				CString sNumEFs; sNumEFs.Format("%d", bResponse[15]);
				theApp.dlg.WriteToLog("  Number of EFs below DFtelecom: " + sNumEFs);
				CString sNumCHVs; sNumCHVs.Format("%d", bResponse[16]);
				theApp.dlg.WriteToLog("  Number of CHVs, UNBLOCK CHVs and administrative codes: " + sNumCHVs);
			}
		}
		
		
		{ // EFadn
			theApp.dlg.WriteToLog("\r\nSelecting EFadn (Abbreviated Dialing Numbers)... ");
			BYTE bFID[2] = { 0x6F, 0x3A };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadAndDecodeADN(pbResponse, bResponseLn);
			}
		}

				
		{ // EFsms
			theApp.dlg.WriteToLog("\r\nSelecting EFsms (Short Messages)... ");
			BYTE bFID[2] = { 0x6F, 0x3C };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadAndDecodeSMS(pbResponse, bResponseLn);
			}
		}
		
	
		
		{ // EFfdn
			theApp.dlg.WriteToLog("\r\nSelecting EFfdn (Fixed Dialing Numbers)... ");
			BYTE bFID[2] = { 0x6F, 0x3B };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadAndDecodeADN(pbResponse, bResponseLn);
			}
		}

		
		{ // EFmsisdn 
			theApp.dlg.WriteToLog("\r\nSelecting EFmsisdn (MSISDN)... ");
			BYTE bFID[2] = { 0x6F, 0x40 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFsmsp 
			theApp.dlg.WriteToLog("\r\nSelecting EFsmsp (SMS parameters)... ");
			BYTE bFID[2] = { 0x6F, 0x42 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFsmss 
			theApp.dlg.WriteToLog("\r\nSelecting EFsmss (SMS status)... ");
			BYTE bFID[2] = { 0x6F, 0x43 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFlnd 
			theApp.dlg.WriteToLog("\r\nSelecting EFlnd (Last Number Dialed)... ");
			BYTE bFID[2] = { 0x6F, 0x44 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadAndDecodeADN(pbResponse, bResponseLn);
			}
		}	

		
		
		{ // EFsdn 
			theApp.dlg.WriteToLog("\r\nSelecting EFsdn (Service Dialing Numbers)... ");
			BYTE bFID[2] = { 0x6F, 0x49 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadAndDecodeADN(pbResponse, bResponseLn);
			}
		}
		
		
		
		{ // EFext1 
			theApp.dlg.WriteToLog("\r\nSelecting EFext1 (Extension 1)... ");
			BYTE bFID[2] = { 0x6F, 0x4A };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFext2
			theApp.dlg.WriteToLog("\r\nSelecting EFext2 (Extension 2)... ");
			BYTE bFID[2] = { 0x6F, 0x4B };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFbdn
			theApp.dlg.WriteToLog("\r\nSelecting EFbdn (Barred Dialing Numbers)... ");
			BYTE bFID[2] = { 0x6F, 0x4D };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		

		
		{ // EFcmi
			theApp.dlg.WriteToLog("\r\nSelecting EFcmi (Comparison Method Information)... ");
			BYTE bFID[2] = { 0x6F, 0x58 };
			pCard->SELECT(pbStatusSW12, bFID);
			// expected: 9F 0F
			if (bStatusSW12[0] == 0x9F)
			{	// read filesize from response bytes
				byte bResponseLn = bStatusSW12[1]; // needed after the next call
				pCard->GET_RESPONSE(pbStatusSW12, pbResponse, bStatusSW12[1]);
				DumpInfo_ReadSelectedFile(pbResponse, bResponseLn);
			}
		}
		
	pCard = 0;
}


/*---------------------------------------------------------------------
  Name   : DumperThread()
  Param  : (in) byte bStatusByte --> some CHV1/CHV2/etc. status byte
  Pre    : -
  Post   : -
  Return : CString --> text interpretation of the byte

  Description:
    Interprets a given secret code status byte, returns string.
---------------------------------------------------------------------*/
CString CSimcardGSM::DumpInfo_DecodeCHVStatusByte(byte bStatusByte)
{
	if (bStatusByte & 0x80) // if first bit is set
	{
		CString s; s.Format("%d", (bStatusByte & 15));
		return "initialized (" + s + " attempts remaining)";
	}
	else
		return "uninitialized";
}



/*---------------------------------------------------------------------
  Name   : DumperThread()
  Param  : -
  Pre    : -
  Post   : -
  Return : void

  Description:
    The main dumper thread. It invokes DumpInfo().
---------------------------------------------------------------------*/
UINT CSimcardGSM::DumperThread(LPVOID param)
{
	theApp.dlg.m_bGSMDumperThreadIsRunning = true;

	theApp.dlg.c_txtCurrentAPDU.SetWindowText("");


    BYTE bRawATR[60];
	DWORD dwATRlen=0;
    ZeroMemory( bRawATR, 60 );

	//if (!sgSimcardGSM.PrepareCard( false, bRawATR, &dwATRlen ))
	if (!theApp.dlg.m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen ))
    {
        theApp.dlg.m_pSmartCard->CardDisconnect();
		theApp.dlg.ToggleGUI(theApp.dlg.GUI_DEFAULT);
		theApp.dlg.OnBnClickedBtnstop();
		TerminateThread(GetCurrentThread(), -1);
		return -1; // never reached due to TerminateThread
    }
    theApp.dlg.WriteToLog( "Answer-To-Reset: " + theApp.dlg.ConvertBytesToHexString( dwATRlen, bRawATR, true ) + "\r\n\r\n", true );
	
	// get all interesting stuff
	//sgSimcardGSM.DumpInfo();
	DumpInfo();

	
	char dateStr [9];
    char timeStr [9];
    _strdate(dateStr);
    _strtime(timeStr);

	theApp.dlg.WriteToLog("------ GSM SIM dump completed on " + CString(dateStr) + " at " + CString(timeStr));
    theApp.dlg.WriteToLog("===========================================================");

	// disconnect card
	//sgSimcardGSM.CardDisconnect();
	theApp.dlg.m_pSmartCard->CardDisconnect();

	// enable GUI
	theApp.dlg.ToggleGUI(theApp.dlg.GUI_DEFAULT);

	theApp.dlg.m_bGSMDumperThreadIsRunning = false;

	CString sCurrentAPDU;
	theApp.dlg.c_txtCurrentAPDU.GetWindowText(sCurrentAPDU);
	theApp.dlg.c_txtCurrentAPDU.SetWindowText("");

	AfxEndThread(0);
	return 0;
}

