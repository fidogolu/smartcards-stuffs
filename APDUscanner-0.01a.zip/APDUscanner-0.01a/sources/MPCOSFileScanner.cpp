/*
* Copyright (c) 2006, Matthijs Koot (matthijs at koot.biz)
* All rights reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the Koot Organization nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================

  MPCOSFILESCANNER.CPP

  License     : BSD-style (yep, just sell it!)
  Author      : Matthijs Koot (matthijs at koot.biz)
  Description : This CMPCOSFileScanner class defines behavior for scanning
                MPCOS-based cards for MF/DF/EFs.

  History :
     2007-12-28, mrkoot: file created

  Remarks :
    - none

===============================================================================*/

#include "StdAfx.h"

#include "APDUScanner.h"
#include "APDUScannerDlg.h"

#include "smartcard.h"
#include ".\mpcosfilescanner.h"


CMPCOSFileScanner::CMPCOSFileScanner()
{	
}

CMPCOSFileScanner::~CMPCOSFileScanner()
{	
	theApp.dlg.m_pSmartCard->CardDisconnect();
}


void CMPCOSFileScanner::StartScan()
{

}


void CMPCOSFileScanner::TrySelectMF()
{

}


void CMPCOSFileScanner::TrySelectDF()
{
}


void CMPCOSFileScanner::TrySelectEF()
{
}


void CMPCOSFileScanner::TryReadDF()
{
}


void CMPCOSFileScanner::TryReadEF()
{
}


/*---------------------------------------------------------------------
  Name   : FileScannerThread()
  Param  : (LPVOID) param
  Pre    : -
  Post   : -
  Return : 0

  Description:
    This is the actual code for EF/DF scanning.
---------------------------------------------------------------------*/
UINT CMPCOSFileScanner::FileScannerThread(LPVOID param)  // defines what our threads actually do
{
//    THREADSTRUCT *ts = (THREADSTRUCT*)param;
    theApp.dlg.m_bFileScannerThreadIsRunning = true;

    BYTE bRawATR[60];
	DWORD dwATRlen=0;
    ZeroMemory( bRawATR, 60 );

	if (!theApp.dlg.m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen ))
    {
        theApp.dlg.m_pSmartCard->CardDisconnect();
		theApp.dlg.OnBnClickedBtnstop();
		TerminateThread(GetCurrentThread(), -1);
        return -1; // never reached due to TerminateThread
    }
    theApp.dlg.WriteToLog( "Answer-To-Reset: " + theApp.dlg.ConvertBytesToHexString( 60, bRawATR, true ) + "\r\n", true );
	
	SCARD_IO_REQUEST ioRecvPci;							// create IO buffer
	ioRecvPci.dwProtocol = SCARD_PROTOCOL_T0;			// fixed 
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	DWORD dwSendLength = 0;			// size of the command APDU
	DWORD dwRecvLength = 0;			// size of the response APDU

	long lReturn;				// some Smartcard SDK return code



	//===================================
	// Next: SELECT MF
    //===================================

		SCARD_T0_COMMAND cmd;

		// clear buffers
		ZeroMemory(bRecv, sizeof(bRecv));
		ZeroMemory(bSend, sizeof(bSend));

		// build APDU (in the SCARD_T0_COMMAND struct)
		cmd.bCla = 0x00; // CLA = instruction class field
		cmd.bIns = 0xA4; // INS = instruction code 
		cmd.bP1  = 0x00; // P1  = parameter 1 (type = select MF)
		cmd.bP2  = 0x00; // P2  = parameter 2 (response)
		cmd.bP3  = 0x02; // P3  = Lc (expected size of IO transfer)
		memcpy(bSend, &cmd, sizeof(cmd));

		// MF is always at 0x3F00
		bSend[5] = 0x3F;
		bSend[6] = 0x00;

		dwSendLength = sizeof(SCARD_T0_COMMAND) + cmd.bP3; // CLA/INS/P1/P2/P3 is followed by <cmd.bP3> extra command bytes */
		dwRecvLength = 0x20;	// we'll only receive 2 status bytes, e.g. 0x9000

		theApp.dlg.WriteToLog("Selecting MF at 0x3F00... ");		
		lReturn = SCardTransmit( theApp.dlg.m_pSmartCard->m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
		if (lReturn != SCARD_S_SUCCESS)
		{		
			theApp.dlg.m_pSmartCard->handleSCardError(lReturn, "SCardTransmit");
			return -1;
		}
		theApp.dlg.WriteToLog(" OK! (SW12=" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2]) + "}", true); 

		theApp.dlg.WriteToLog("Command APDU={" + theApp.dlg.ConvertBytesToHexString(dwSendLength, pbSend, true) + "}", false, true);
		if (!theApp.dlg.m_pSmartCard->ResponseIsOK(bRecv[0], bRecv[1], false))
		{ 
			// establish a fresh context to continue the scan
			theApp.dlg.m_pSmartCard->CardDisconnect();

			if (!theApp.dlg.m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen ))
			{
				theApp.dlg.m_pSmartCard->CardDisconnect();
				theApp.dlg.OnBnClickedBtnstop();
				TerminateThread(GetCurrentThread(), -1);
				theApp.dlg.WriteToLog("SCAN ABORTED: there was an error while trying to continue the scan!");
				return -1; // never reached due to TerminateThread
		    }
		} 
		else
		{
			theApp.dlg.WriteToLog("done.", true);
		}



		if (bRecv[0] == 0x61)
		{
			// if SW1==0x61, then SW2 (=bRecv[1]) specifies that X more bytes are available
			// so let's do GET RESPONSE

			BYTE bNr = bRecv[1];

			// clear buffers
			ZeroMemory(bRecv, sizeof(bRecv));
			ZeroMemory(bSend, sizeof(bSend));

			// build APDU (in the SCARD_T0_COMMAND struct)
			cmd.bCla = 0x00; // CLA = instruction class field
			cmd.bIns = 0xC0; // INS = instruction code 
			cmd.bP1  = 0x00; // P1  = parameter 1 (type)
			cmd.bP2  = 0x00; // P2  = parameter 2 (response)
			cmd.bP3  = bNr;// bRecv[1]; // P3  = Lc (expected size of IO transfer)
			//cmd.bP3  = 0x02; // P3  = Lc (expected size of IO transfer)
			memcpy(bSend, &cmd, sizeof(cmd));

			dwSendLength = sizeof(SCARD_T0_COMMAND);// + cmd.bP3; // CLA/INS/P1/P2/P3 is followed by <cmd.bP3> extra command bytes */
			dwRecvLength = bNr+2; // the nr of bytes specified by SW2 + response code

			CString sSW2;
			sSW2.Format("Getting %d more bytes from this file...", bNr);
			theApp.dlg.WriteToLog(sSW2);

			lReturn = SCardTransmit( theApp.dlg.m_pSmartCard->m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
			if (lReturn != SCARD_S_SUCCESS)
			{		
				theApp.dlg.m_pSmartCard->handleSCardError(lReturn, "SCardTransmit");
				return -1;
			}
			//theApp.dlg.WriteToLog("  Response APDU = {" + theApp.dlg.ConvertBytesToHexString(dwRecvLength, bRecv, true) + "}"); 

			//theApp.dlg.WriteToLog("Command APDU={" + theApp.dlg.ConvertBytesToHexString(dwSendLength, pbSend, true) + "}", false, true);
			if (!theApp.dlg.m_pSmartCard->ResponseIsOK(bRecv[dwRecvLength-2], bRecv[dwRecvLength-1]))
			{ 
				// establish a fresh context to continue the scan
				theApp.dlg.m_pSmartCard->CardDisconnect();

				if (!theApp.dlg.m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen ))
				{
					theApp.dlg.m_pSmartCard->CardDisconnect();
					theApp.dlg.OnBnClickedBtnstop();
					TerminateThread(GetCurrentThread(), -1);
					theApp.dlg.WriteToLog("SCAN ABORTED: there was an error while trying to continue the scan!");
					return -1; // never reached due to TerminateThread
				}
			}
			else
			{ // display file contents
				theApp.dlg.WriteToLog("  --> Contents of this MF (hex): " + theApp.dlg.ConvertBytesToHexString(dwRecvLength, &bRecv[0], true));
				CString sContents;
				for (UINT i=0; i < (dwRecvLength - 2); i++)
				if (bRecv[i] != 0x00)
					sContents.AppendChar(bRecv[i]);
				theApp.dlg.WriteToLog("  --> Contents of this MF (ASCII): " + sContents);
			}
		}


//----------
	BYTE bD1_MIN = 0x00;
	BYTE bD1_MAX = 0xFF;

	BYTE bD2_MIN = 0x00;
	BYTE bD2_MAX = 0xFF;
//----------


	// Scan through all possible D1/D2 values to find a DF
	int iD1=0,iD2=0;

	// !!!! TBD: FixD1 and FixD2 don't work for 0x00
	for (iD2 = bD2_MIN; iD2 <= bD2_MAX; iD2++)
	{
		BYTE bD2 = intToByte(iD2);
		//::OutputDebugString("D2\r\n");

		for (iD1 = bD1_MIN; iD1 <= bD1_MAX; iD1++)
		{
			BYTE bD1 = intToByte(iD1);
			//::OutputDebugString("D2 D1\r\n");

			if (theApp.dlg.m_bFileScannerThreadIsRunning == false)
			{
				theApp.dlg.m_pSmartCard->CardDisconnect();
				TerminateThread(GetCurrentThread(), 0);
			}

			/*
			// ================= (RE)SELECT MF =====================
			SCARD_T0_COMMAND cmd;

			// clear buffers
			ZeroMemory(bRecv, sizeof(bRecv));
			ZeroMemory(bSend, sizeof(bSend));

			// build APDU (in the SCARD_T0_COMMAND struct)
			cmd.bCla = 0x00; // CLA = instruction class field
			cmd.bIns = 0xA4; // INS = instruction code 
			cmd.bP1  = 0x00; // P1  = parameter 1 (type = select MF)
			cmd.bP2  = 0x00; // P2  = parameter 2 (response)
			cmd.bP3  = 0x02; // P3  = Lc (expected size of IO transfer)
			memcpy(bSend, &cmd, sizeof(cmd));

			// MF is always at 0x3F00
			bSend[5] = 0x3F;
			bSend[6] = 0x00;

			dwSendLength = sizeof(SCARD_T0_COMMAND) + cmd.bP3; // CLA/INS/P1/P2/P3 is followed by <cmd.bP3> extra command bytes
			dwRecvLength = 0x20; // we'll only receive 2 status bytes, e.g. 0x9000

//			theApp.dlg.WriteToLog("Reselecting MF at 0x3F00... ");
			lReturn = SCardTransmit( theApp.dlg.m_pSmartCard->m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
			if (lReturn != SCARD_S_SUCCESS)
			{		
				theApp.dlg.m_pSmartCard->handleSCardError(lReturn, "SCardTransmit");
				return -1;
			}*/


			// ================= TRY NEXT DF =====================

			ZeroMemory(bRecv, sizeof(bRecv));
			ZeroMemory(bSend, sizeof(bSend));

			// build APDU (in the SCARD_T0_COMMAND struct)
			cmd.bCla = 0x00; // CLA = instruction class field
			cmd.bIns = 0xA4; // INS = instruction code 
			cmd.bP1  = 0x01; // P1  = parameter 1 (type = select DF)
			cmd.bP2  = 0x00; // P2  = parameter 2 (response)
			cmd.bP3  = 0x02; // P3  = Lc (expected size of IO transfer)
			memcpy(bSend, &cmd, sizeof(cmd));

			bSend[5]=bD1;
			bSend[6]=bD2;

			dwSendLength = sizeof(SCARD_T0_COMMAND) + 2;
			dwRecvLength = 256;	// Great Expectations! :-)

			CString sDF;
			sDF.Format("0x%02x%02x", bD1, bD2);
			theApp.dlg.c_txtCurrentAPDU.SetWindowText("Attempting to select DF at " + sDF + " with APDU {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, pbSend, true) + "}...");
			//theApp.dlg.WriteToLog(sDF);
			lReturn = SCardTransmit( theApp.dlg.m_pSmartCard->m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
			if (lReturn != SCARD_S_SUCCESS)
			{		
				theApp.dlg.m_pSmartCard->handleSCardError(lReturn, "SCardTransmit");
				return -1;
			}

			//CString bla = "Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, pbSend, true) + "}";
			//theApp.dlg.WriteToLog(bla, false, true);
			if (theApp.dlg.m_pSmartCard->ResponseIsOK(bRecv[0], bRecv[1], true))
			{
				theApp.dlg.WriteToLog("");
				theApp.dlg.WriteToLog("-- A DEDICATED FILE WAS FOUND AT " + sDF + "!");
			}


			// GET RESPONSE
			if (bRecv[0] == 0x61)
			{
				// if SW1==0x61, then SW2 (=bRecv[1]) specifies that X more bytes are available
				// so let's do GET RESPONSE

				BYTE bNr = bRecv[1];

				// clear buffers
				ZeroMemory(bRecv, sizeof(bRecv));
				ZeroMemory(bSend, sizeof(bSend));

				// build APDU (in the SCARD_T0_COMMAND struct)
				cmd.bCla = 0x00; // CLA = instruction class field
				cmd.bIns = 0xC0; // INS = instruction code 
				cmd.bP1  = 0x00; // P1  = parameter 1 (type)
				cmd.bP2  = 0x00; // P2  = parameter 2 (response)
				cmd.bP3  = bNr;// bRecv[1]; // P3  = Lc (expected size of IO transfer)
				//cmd.bP3  = 0x02; // P3  = Lc (expected size of IO transfer)
				memcpy(bSend, &cmd, sizeof(cmd));

				dwSendLength = sizeof(SCARD_T0_COMMAND);// + cmd.bP3; // CLA/INS/P1/P2/P3 is followed by <cmd.bP3> extra command bytes */
				dwRecvLength = bNr+2; // the nr of bytes specified by SW2 + response code

				CString sSW2;
				sSW2.Format("Getting %d more bytes from this file...", bNr);
				theApp.dlg.WriteToLog(sSW2);

				lReturn = SCardTransmit( theApp.dlg.m_pSmartCard->m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
				if (lReturn != SCARD_S_SUCCESS)
				{		
					theApp.dlg.m_pSmartCard->handleSCardError(lReturn, "SCardTransmit");
					return -1;
				}

				theApp.dlg.WriteToLog(" OK! (SW12=" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2]) + "}", true); 

				//theApp.dlg.WriteToLog("  Response APDU = {" + theApp.dlg.ConvertBytesToHexString(dwRecvLength, bRecv, true) + "}"); 
				//string s3(bRecv, dwRecvLength);
				//theApp.dlg.WriteToLog("CONTENTS: (todo)");

				//theApp.dlg.WriteToLog("Command APDU={" + theApp.dlg.ConvertBytesToHexString(dwSendLength, pbSend, true) + "}", false, true);
				if (!theApp.dlg.m_pSmartCard->ResponseIsOK(bRecv[dwRecvLength-2], bRecv[dwRecvLength-1]))
				{ 
					// establish a fresh context to continue the scan
					theApp.dlg.m_pSmartCard->CardDisconnect();

					if (!theApp.dlg.m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen ))
					{
						theApp.dlg.m_pSmartCard->CardDisconnect();
						theApp.dlg.OnBnClickedBtnstop();
						theApp.dlg.WriteToLog("SCAN ABORTED: there was an error while trying to continue the scan!");
						TerminateThread(GetCurrentThread(), -1);
						return -1; // never reached due to TerminateThread
					}
				}
				else
				{ // display contents of DF
					theApp.dlg.WriteToLog("  --> Contents of this DF (hex): " + theApp.dlg.ConvertBytesToHexString(dwRecvLength, &bRecv[0], true));
					CString sContents;
					for (UINT i=0; i < (dwRecvLength - 2); i++)
					if (bRecv[i] != 0x00)
						sContents.AppendChar(bRecv[i]);
					theApp.dlg.WriteToLog("  --> Contents of this DF (ASCII): " + sContents);
				}

			} // if (bRecv[0] == 0x61)

			if (theApp.dlg.c_chkReconnect.GetCheck()==1)
			{
				theApp.dlg.m_pSmartCard->CardDisconnect();
				theApp.dlg.m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen );
			}

		} // D1
	} // D2


    /*------
    clean up */

	theApp.dlg.m_pSmartCard->CardDisconnect();

	char dateStr [9];
    char timeStr [9];
    _strdate(dateStr);
    _strtime(timeStr);
    theApp.dlg.WriteToLog("------ MPCOS EF/DF scan completed on " + CString(dateStr) + " at " + CString(timeStr));
    theApp.dlg.WriteToLog("===========================================================");

	theApp.dlg.m_bFileScannerThreadIsRunning = false;

	// enable GUI
	theApp.dlg.ToggleGUI(false);

	CString sCurrentAPDU;
	theApp.dlg.c_txtCurrentAPDU.GetWindowText(sCurrentAPDU);
	theApp.dlg.c_txtCurrentAPDU.SetWindowText("");

	AfxEndThread(0);
    return 0;
}



