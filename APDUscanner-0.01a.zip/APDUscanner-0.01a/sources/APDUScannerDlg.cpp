/*
* Copyright (c) 2006, Matthijs Koot (matthijs at koot.biz)
* All rights reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the Koot Organization nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================

  APDUSCANNERDLG.CPP

  License     : BSD-style (yep, just sell it!)
  Author      : Matthijs Koot (matthijs at koot.biz)
  Description : One big, chunky piece of implementation (MFC Dialog + 
                smartcard routines).

  History :
     2006-04-13, mrkoot: file created
     2006-04-16, mrkoot: refurbished
     2007-11-11, mrkoot: added extended error handling
     2007-12-29, mrkoot: added Chipknip.h and MPCOS.h

  Remarks :
    - NEEDS FIX: APDUScanner seems to slow down after scanning 
	  some large number of APDUs. I don't know what causes it (this software?
	  the Windows SmartCard SDK? or the smartcard that's being read?).
    - TODO: more finegrained definition of scanning range
    - TODO: test with a T=1 based card (probably OK though)
    - TODO: be graceful in card re-insertion during scan (resume after error)
	- TODON'T: add A38 Ki-extractor for GSM SIM cloning (would be 10 years overdue)

===============================================================================*/

#pragma once

#include "stdafx.h"
#include "APDUScanner.h"
#include "APDUScannerDlg.h"

#include <winscard.h>   // used for smartcard connectivity

#include "SmartCard.h"
#include "Chipknip.h"
#include "SimcardGSM.h"
#include "MPCOS.h"
#include "MPCOSFileScanner.h"
#include "ChipknipFileScanner.h"
#include "ChipknipTinker.h"

#include <iostream>  // read/write files 
#include <fstream>   // read/write files 
#include ".\apduscannerdlg.h"
using namespace std;


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
    CAboutDlg();

// Dialog Data
    enum { IDD = IDD_ABOUTBOX };

    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
    DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeTxtapdu();
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	ON_EN_CHANGE(IDC_TXTAPDU, OnEnChangeTxtapdu)
END_MESSAGE_MAP()


// CAPDUScannerDlg dialog



CAPDUScannerDlg::CAPDUScannerDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CAPDUScannerDlg::IDD, pParent)
{
	// this currently somehow seems to yield a debug assertion failure:
    /////m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
		
	// TODO: initialize pointers 
}

CAPDUScannerDlg::~CAPDUScannerDlg() {
	// TODO: clean up pointers
	if (m_ofsLog) m_ofsLog.close();
	if (m_ifsSettings) m_ifsSettings.close();
	if (m_pSmartCard) delete(m_pSmartCard);
	if (m_pdlgAPDUconsole) delete(m_pdlgAPDUconsole);
}

void CAPDUScannerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LOG, c_Log);
	DDX_Control(pDX, IDC_PCSC, c_ComboUSBReaders);
	DDX_Control(pDX, IDC_CHKFIXCLA, c_chkFixCLA);
	DDX_Control(pDX, IDC_CHKFIXINS, c_chkFixINS);
	DDX_Control(pDX, IDC_CHKFIXP1, c_chkFixP1);
	DDX_Control(pDX, IDC_CHKFIXP2, c_chkFixP2);
	DDX_Control(pDX, IDC_CHKFIXP3, c_chkFixP3);
	DDX_Control(pDX, IDC_CBCLA, c_cbCLA);
	DDX_Control(pDX, IDC_CBINS, c_cbINS);
	DDX_Control(pDX, IDC_CBP1, c_cbP1);
	DDX_Control(pDX, IDC_CBP2, c_cbP2);
	DDX_Control(pDX, IDC_CBP3, c_cbP3);
	DDX_Control(pDX, IDC_BTNGETATR, c_btnGetATR);
	DDX_Control(pDX, IDC_BTNSCAN, c_btnScan);
	DDX_Control(pDX, IDC_BTNPAUSE, c_btnPause);
	DDX_Control(pDX, IDC_BTNSTOP, c_btnStop);
	DDX_Control(pDX, IDC_TXTCURRENT, c_txtCurrentAPDU);
	DDX_Control(pDX, IDC_BTNRESET, c_btnReset);
	DDX_Control(pDX, IDC_BTNREADCHIPKNIP, c_btnReadChipknip);
	DDX_Control(pDX, IDC_BTNSAVE, c_btnSave);
	DDX_Control(pDX, IDC_CHKSCAND1, c_chkScanD1);
	DDX_Control(pDX, IDC_CHKSCAND2, c_chkScanD2);
	DDX_Control(pDX, IDC_CHKFIXD1, c_chkFixD1);
	DDX_Control(pDX, IDC_CHKFIXD2, c_chkFixD2);
	DDX_Control(pDX, IDC_CBD1, c_cbD1);
	DDX_Control(pDX, IDC_CBD2, c_cbD2);
	DDX_Control(pDX, IDC_WARNINGS, c_chkShowWarnings);
	DDX_Control(pDX, IDC_EXECERR, c_chkShowExecErrors);
	DDX_Control(pDX, IDC_CHECKERR, c_chkShowCheckErrors);
	DDX_Control(pDX, IDC_DISCONNECT, c_chkReconnect);
	DDX_Control(pDX, IDC_BTNREADSIM, c_btnReadSIM);
	DDX_Control(pDX, IDC_BTNFILESCANMPCOS, c_btnFileScanMPCOS);
	DDX_Control(pDX, IDC_BTNFILESCANCHIPKNIP, c_btnFileScanChipknip);
	DDX_Control(pDX, IDC_BTNFILESCANSIMCARDGSM, c_btnFileScanSimcardGSM);
	DDX_Control(pDX, IDC_BTNAPDUCONSOLE, c_btnAPDUConsole);	
	DDX_Control(pDX, IDC_PIN_CHIPKNIP, c_chkUsePIN_Chipknip);
	DDX_Control(pDX, IDC_PIN_GSMSIM, c_chkUsePIN_GSMSIM);
	DDX_Control(pDX, IDC_TXTPIN_CHIPKNIP, c_txtPIN_Chipknip);
	DDX_Control(pDX, IDC_TXTPIN_GSMSIM, c_txtPIN_GSMSIM);
}

BEGIN_MESSAGE_MAP(CAPDUScannerDlg, CDialog)
    ON_WM_SYSCOMMAND()
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    //}}AFX_MSG_MAP
    ON_BN_CLICKED(IDC_BTNGETATR, OnBnClickedBtngetatr)
	ON_BN_CLICKED(IDC_BTNSCAN, OnBnClickedBtnscan)
	ON_BN_CLICKED(IDC_BTNPAUSE, OnBnClickedBtnpause)
	ON_BN_CLICKED(IDC_BTNSTOP, OnBnClickedBtnstop)
	ON_BN_CLICKED(IDC_CHKFIXCLA, OnBnClickedChkfixcla)
	ON_BN_CLICKED(IDC_CHKFIXINS, OnBnClickedChkfixins)
	ON_BN_CLICKED(IDC_CHKFIXP1, OnBnClickedChkfixp1)
	ON_BN_CLICKED(IDC_CHKFIXP2, OnBnClickedChkfixp2)
	ON_BN_CLICKED(IDC_CHKFIXP3, OnBnClickedChkfixp3)
	ON_BN_CLICKED(IDC_BTNRESET, OnBnClickedBtnreset)
	ON_BN_CLICKED(IDC_BTNSAVE, OnBnClickedBtnsave)
	ON_BN_CLICKED(IDC_CHKFIXD1, OnBnClickedChkfixd1)
	ON_BN_CLICKED(IDC_CHKFIXD2, OnBnClickedChkfixd2)
	ON_BN_CLICKED(IDC_CHKSCAND1, OnBnClickedChkscand1)
	ON_BN_CLICKED(IDC_CHKSCAND2, OnBnClickedChkscand2)
	ON_CBN_SELCHANGE(IDC_CBCLA, OnCbnSelchangeCbcla)
	ON_CBN_SELCHANGE(IDC_CBINS, OnCbnSelchangeCbins)
	ON_CBN_SELCHANGE(IDC_CBP1, OnCbnSelchangeCbp1)
	ON_CBN_SELCHANGE(IDC_CBP2, OnCbnSelchangeCbp2)
	ON_CBN_SELCHANGE(IDC_CBP3, OnCbnSelchangeCbp3)
	ON_CBN_SELCHANGE(IDC_CBD1, OnCbnSelchangeCbd1)
	ON_CBN_SELCHANGE(IDC_CBD2, OnCbnSelchangeCbd2)
	ON_BN_CLICKED(IDC_BTNTEST, OnBnClickedBtntest)
	ON_BN_CLICKED(IDC_WARNINGS, OnBnClickedWarnings)
	ON_BN_CLICKED(IDC_EXECERR, OnBnClickedExecerr)
	ON_BN_CLICKED(IDC_CHECKERR, OnBnClickedCheckerr)
	ON_BN_CLICKED(IDC_DISCONNECT, OnBnClickedDisconnect)
	ON_CBN_SELCHANGE(IDC_PCSC, OnCbnSelchangePcsc)
	ON_BN_CLICKED(IDC_BTNREADSIM, OnBnClickedBtnreadsim)
	ON_BN_CLICKED(IDC_BTNREADCHIPKNIP, OnBnClickedBtnreadchipknip)
	ON_BN_CLICKED(IDC_BTNFILESCANMPCOS, OnBnClickedBtnfilescanmpcos)
	ON_BN_CLICKED(IDC_BTNFILESCANCHIPKNIP, OnBnClickedBtnfilescanchipknip)
	ON_BN_CLICKED(IDC_BTNFILESCANSIMCARDGSM, OnBnClickedBtnfilescansimcardgsm)
	ON_BN_CLICKED(IDC_BTNTEST2, OnBnClickedBtntest2)
	ON_BN_CLICKED(IDC_BTNAPDUCONSOLE, OnBnClickedBtnapduconsole)
	ON_BN_CLICKED(IDC_PIN_CHIPKNIP, OnBnClickedPinChipknip)
	ON_BN_CLICKED(IDC_PIN_GSMSIM, OnBnClickedPinGsmsim)
	ON_WM_KEYDOWN()
	ON_STN_CLICKED(IDC_LBLTITLE, OnStnClickedLbltitle)
END_MESSAGE_MAP()


// CAPDUScannerDlg message handlers

BOOL CAPDUScannerDlg::OnInitDialog()
{
	CDialog::OnInitDialog(); 

    // Add "About..." menu item to system menu.

    // IDM_ABOUTBOX must be in the system command range.
    ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
    ASSERT(IDM_ABOUTBOX < 0xF000);

    CMenu* pSysMenu = GetSystemMenu(false);
    if (pSysMenu != NULL)
    {
        CString strAboutMenu;
        strAboutMenu.LoadString(IDS_ABOUTBOX);
        if (!strAboutMenu.IsEmpty())
        {
            pSysMenu->AppendMenu(MF_SEPARATOR);
            pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
        }
    }

    // Set the icon for this dialog.  The framework does this automatically
    //  when the application's main window is not a dialog
    SetIcon(m_hIcon, true);         // Set big icon
    SetIcon(m_hIcon, false);        // Set small icon

	//m_hMutex = ::CreateMutex(NULL, false, _T("scannerMutex"));
	m_sOutputFile = "output.txt"; // yep, hardcoded (y)
	m_ofsLog.open(m_sOutputFile, ios::app); // returns void :-)

	m_pSmartCard = new CSmartCard();

	m_pSmartCard->m_iNumReaders = 0;
    WriteToLog("Searching for PC/SC devices...");	
	if (ListPCSCReaders()) WriteToLog(" done!", true);
	
	// add empty elements (i.e. "no fixed byte")
	c_cbCLA.AddString("");
	c_cbINS.AddString("");
	c_cbP1.AddString("");
	c_cbP2.AddString("");
	c_cbP3.AddString("");

	// fill comboboxes with 0x00-0xFF
	BYTE b=0;
	for (int i=0; i<=255; i++, b++)
	{
		c_cbCLA.AddString(ConvertBytesToHexString(1, &b, false));
		c_cbINS.AddString(ConvertBytesToHexString(1, &b, false));
		c_cbP1.AddString(ConvertBytesToHexString(1, &b, false));	
		c_cbP2.AddString(ConvertBytesToHexString(1, &b, false));
		c_cbP3.AddString(ConvertBytesToHexString(1, &b, false));
		c_cbD1.AddString(ConvertBytesToHexString(1, &b, false));
		c_cbD2.AddString(ConvertBytesToHexString(1, &b, false));
	}

	// set defaults (in case there is no settings file)
	CString sDefaults = ";CLA=n,0x00;INS=n,0x00;P1=n,0x00;P2=n,0x00;P3=n,0x00;D1=n,0x00;D2=n,0x00;ScanD1=n;ScanD2=n;ShowWarnings=y;ShowExecErrors=y;ShowCheckErrors=y;Reconnect=n;";
	sSettings = sDefaults.GetBuffer(); // will be changed if the settings file exists
	m_sSettingsFile = "settings.cfg"; // hardcoded stuff RULES!
	m_ifsSettings.open(m_sSettingsFile, ios::in|ios::binary|ios::ate); // this returns void, so there's return code to check here
	if (!m_ifsSettings)
	{ // file could not be opened; try in another way
		ofstream ofsSettings;
		ofsSettings.open(m_sSettingsFile, ios::trunc);
		if (!ofsSettings)
		{
			AfxMessageBox("ERROR: Could neither read nor create "+m_sSettingsFile+"!");
		}
		else
		{
			ofsSettings << sSettings << endl;
			ofsSettings.flush();
			ofsSettings.close();
			WriteToLog("APDUScanner settings: " + sSettings, false, false);
		}

		if (sSettings.Find(";ShowWarnings=y") >= 0)
			c_chkShowWarnings.SetCheck(BST_CHECKED);
		if (sSettings.Find(";ShowExecErrors=y") >= 0)
			c_chkShowExecErrors.SetCheck(BST_CHECKED);
		if (sSettings.Find(";ShowCheckErrors=y") >= 0)
			c_chkShowCheckErrors.SetCheck(BST_CHECKED);
		if (sSettings.Find(";Reconnect=y") >= 0)
			c_chkReconnect.SetCheck(BST_CHECKED);
		//LocalFree(ofsSettings);
		//ReleaseMutex(hMutex);
	}
	else
	{ // file existed, or was created
		if (m_ifsSettings.is_open())
		{
			// read settings file
			int iFileSize;
			char *pcSettingsData;
			iFileSize = m_ifsSettings.tellg();
			pcSettingsData = new char[iFileSize+1];

			m_ifsSettings.seekg (0, ios::beg);
			m_ifsSettings.read (pcSettingsData, iFileSize);
			m_ifsSettings.close();
		
			pcSettingsData[iFileSize]=0x00;
			sSettings = pcSettingsData;
			if (sDefaults.Compare(sSettings) != 0) // compare settingsfile with default settings
				c_btnReset.EnableWindow(true);

			//sSettings = sTmpSettings;
			WriteToLog("APDUScanner settings: " + sSettings, false, false);

			c_cbCLA.SelectString(0, sSettings.Mid(sSettings.Find(";CLA=")+9, 2));
			c_cbINS.SelectString(0, sSettings.Mid(sSettings.Find(";INS=")+9, 2));
			c_cbP1.SelectString(0, sSettings.Mid(sSettings.Find(";P1=")+8, 2));
			c_cbP2.SelectString(0, sSettings.Mid(sSettings.Find(";P2=")+8, 2));
			c_cbP3.SelectString(0, sSettings.Mid(sSettings.Find(";P3=")+8, 2));
			c_cbD1.SelectString(0, sSettings.Mid(sSettings.Find(";D1=")+8, 2));
			c_cbD2.SelectString(0, sSettings.Mid(sSettings.Find(";D2=")+8, 2));

			if (sSettings.Find(";CLA=y") >= 0)
			{
				c_chkFixCLA.SetCheck(BST_CHECKED);
				c_cbCLA.EnableWindow(true);
			}
			if (sSettings.Find(";INS=y") >= 0)
			{
				c_chkFixINS.SetCheck(BST_CHECKED);
				c_cbINS.EnableWindow(true);
			}
			if (sSettings.Find(";P1=y") >= 0)
			{
				c_chkFixP1.SetCheck(BST_CHECKED);
				c_cbP1.EnableWindow(true);
			}
			if (sSettings.Find(";P2=y") >= 0)
			{
				c_chkFixP2.SetCheck(BST_CHECKED);
				c_cbP2.EnableWindow(true);
			}
			if (sSettings.Find(";P3=y") >= 0)
			{
				c_chkFixP3.SetCheck(BST_CHECKED);
				c_cbP3.EnableWindow(true);
			}
			if (sSettings.Find(";ScanD1=y") >= 0)
			{
				c_chkScanD1.SetCheck(BST_CHECKED);
				c_chkFixD1.EnableWindow(true);
				if (sSettings.Find(";D1=y") >= 0)
				{
					c_chkFixD1.SetCheck(BST_CHECKED);
					c_cbD1.EnableWindow(true);
					c_cbD1.SelectString(0, sSettings.Mid(sSettings.Find(";D1=")+8, 2));
				}
			}
			if (sSettings.Find(";ScanD2=y") >= 0)
			{
				c_chkScanD2.SetCheck(BST_CHECKED);
				c_chkFixD2.EnableWindow(true);
				if (sSettings.Find(";D2=y") >= 0)
				{
					c_chkFixD2.SetCheck(BST_CHECKED);
					c_cbD2.EnableWindow(true);
					c_cbD2.SelectString(0, sSettings.Mid(sSettings.Find(";D2=")+8, 2));
				}
			}
			if (sSettings.Find(";ShowWarnings=y") >= 0)
				c_chkShowWarnings.SetCheck(BST_CHECKED);
			if (sSettings.Find(";ShowExecErrors=y") >= 0)
				c_chkShowExecErrors.SetCheck(BST_CHECKED);
			if (sSettings.Find(";ShowCheckErrors=y") >= 0)
				c_chkShowCheckErrors.SetCheck(BST_CHECKED);
			if (sSettings.Find(";Reconnect=y") >= 0)
				c_chkReconnect.SetCheck(BST_CHECKED);

			delete[] pcSettingsData;
		} // m_ifsSettings.is_open();
	}

	// set maxlength for PIN-controls to 8
	c_txtPIN_Chipknip.SetLimitText(8);
	c_txtPIN_GSMSIM.SetLimitText(8);
	

	// Show APDU console dialog 
	m_pdlgAPDUconsole = new CAPDUConsoleDlg(NULL, m_pSmartCard);
	m_pdlgAPDUconsole->Create(IDD_APDUCONSOLE_DIALOG, this);
	//m_pdlgAPDUconsole->ShowWindow(SW_SHOW);
	if (m_pdlgAPDUconsole == NULL)
	{	
		AfxMessageBox("Error on CAPDUConsoleDlg()");
		exit(-1);
	}


    return true;  // return true  unless you set the focus to a control
}

void CAPDUScannerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
    if ((nID & 0xFFF0) == IDM_ABOUTBOX)
    {
        CAboutDlg dlgAbout;
        dlgAbout.DoModal();
    }
    else
    {
        CDialog::OnSysCommand(nID, lParam);
    }
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CAPDUScannerDlg::OnPaint()
{
    if (IsIconic())
    {
        CPaintDC dc(this); // device context for painting

        SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

        // Center icon in client rectangle
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        // Draw the icon
        dc.DrawIcon(x, y, m_hIcon);
    }
    else
    {
        CDialog::OnPaint();
    }
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CAPDUScannerDlg::OnQueryDragIcon()
{
    return static_cast<HCURSOR>(m_hIcon);
}


/*---------------------------------------------------------------------
  Name   : ListPCSCReaders()
  Param  : -
  Pre    : -
  Post   : -
  Return : true on success, false on failure

  Description:
    Changes some GUI things to indicate that the keycard disabling
    override has been set (or not).
---------------------------------------------------------------------*/
BOOL CAPDUScannerDlg::ListPCSCReaders()
{
    long lReturn;

    // Establish the context.
	lReturn = SCardEstablishContext( SCARD_SCOPE_USER, NULL, NULL, &(m_pSmartCard->m_hSCardContext) );
    if ( lReturn != SCARD_S_SUCCESS )
	{
		m_pSmartCard->handleSCardError(lReturn, "SCardEstablishContext");
		//WriteToLog("\r\n  ...no readers found!");
		WriteToLog("\r\n-------> No smartcard readers were found! (Is it connected? Is the PC/SC driver installed?)");
		ToggleGUI(GUI_FOR_NOREADERSFOUND);
		AfxMessageBox("No smartcard readers found! Without a smartcard reader, this program is useless.");
        return false;
	}

    LPTSTR pmszReaders = NULL;
    LPTSTR pReader;
    DWORD cch = SCARD_AUTOALLOCATE;

    // Retrieve the list the reader groups.
    // hSC was set by a previous call to SCardEstablishContext.
    lReturn = SCardListReaders( m_pSmartCard->m_hSCardContext, NULL, (LPTSTR)&pmszReaders, &cch );

	if ( lReturn != SCARD_S_SUCCESS) 
    { 
		m_pSmartCard->handleSCardError(lReturn, "SCardListReaders");
		//WriteToLog("\r\n  ...no PC/SC readers available!");
		WriteToLog("\r\n-------> No PC/SC-compliant readers found! (Is the PC/SC driver installed?)");
		ToggleGUI(GUI_FOR_NOREADERSFOUND);
		AfxMessageBox("No PC/SC-compliant readers found! Without a PC/SC reader, this program is useless.");
		return false;
	}
	else
	{
        // Do something with the multi string of reader groups.
        // Here, we'll merely output the values.
        // A double-null terminates the list of values.

        pReader = pmszReaders;
        while ( '\0' != *pReader )
        {
            // Display the value.
            // printf("%S\n", pReaderGroup );
            // Advance to the next value.

			strncpy( m_cReadernames[m_pSmartCard->m_iNumReaders], pReader, 80 );
            pReader = pReader + strlen(pReader) + 1;
            c_ComboUSBReaders.AddString(m_cReadernames[m_pSmartCard->m_iNumReaders]);
            m_pSmartCard->m_iNumReaders++;

            if (m_pSmartCard->m_iNumReaders > 4) break;
        }

        c_ComboUSBReaders.EnableWindow(true);
        c_ComboUSBReaders.SetCurSel(0);
		c_ComboUSBReaders.GetLBText(c_ComboUSBReaders.GetCurSel(), m_pSmartCard->m_sSelectedReader);

		lReturn = SCardFreeMemory( m_pSmartCard->m_hSCardContext, pmszReaders );
  		if (lReturn != SCARD_S_SUCCESS)
		{  // not critical, so don't return false
			m_pSmartCard->handleSCardError(lReturn, "SCardFreeMemory");
	    }
    }

	lReturn = SCardReleaseContext( m_pSmartCard->m_hSCardContext );
  	if (lReturn != SCARD_S_SUCCESS)
	{ // not critical, so don't return false
		m_pSmartCard->handleSCardError(lReturn, "SCardReleaseContext");
	}

	return true;


}


/*---------------------------------------------------------------------
  Name   : WriteToLog()
  Param  : (LPCTSTR) pszMessage
  Pre    : -
  Post   : message added to log + edit control scrolled to new line
  Return : void

  Description:
    Adds message to log (GUI).
---------------------------------------------------------------------*/
void CAPDUScannerDlg::WriteToLog(LPCTSTR pszMessage, BOOL bSameLine, BOOL bShowOnGUI)
{
	if (bShowOnGUI)
	{
		CString sOld;
		c_Log.GetWindowText(sOld);	

		if (sOld.GetLength()!=0 && !bSameLine)
			sOld.Insert(sOld.GetLength(), "\r\n");
		sOld.Insert(sOld.GetLength(), pszMessage);
		
		int iLength = c_Log.GetLineCount();
		int iMaxLines = 200;
		if (iLength > iMaxLines)
		{
			int iStart = 0;
			int iEnd = 0;
			int iCount = 0;
			int iPos = 0;
			for (iCount=0; iCount<=100; iCount++)
				iEnd = sOld.Find("\r\n", iPos++);

			sOld.Delete(iStart, iEnd);
		}
	
		c_Log.SetWindowText(sOld);
		c_Log.LineScroll(c_Log.GetLineCount(),0);
	}

	// Append log entries to c:\\APDUscanner.log

	if (!m_ofsLog) // Always test file open
	{
		::OutputDebugString("ERROR: can't write to output file!");
		//ReleaseMutex(hMutex);
		return;
	}
	else
	{
		m_ofsLog << pszMessage << endl;
		m_ofsLog.flush();
	}

	//ReleaseMutex(hMutex);
}

/*---------------------------------------------------------------------
  Name   : ConvertBytesToHexString()
  Param  : int iLength
           BYTE * pbInput
           BOOL bDivider
  Pre    : -
  Post   : -
  Return : CString containing bytes in hexadecimal format or an
           error message if applicable.

  Description:
    Converts bytes from a given location in hexadecimal format to a
    string for display.
---------------------------------------------------------------------*/
CString CAPDUScannerDlg::ConvertBytesToHexString(int iLength, BYTE * pbInput, BOOL bDivider)
{
    if (iLength > 0)
    {
        if (pbInput != NULL)
        {
            CString szOutput;
            if (bDivider)
            {
                for (int iCount = 0; iCount < iLength; iCount++)
                    szOutput.AppendFormat("%02X ", *(BYTE *)(pbInput+iCount));
            }
            else
            {
                for (int iCount = 0; iCount < iLength; iCount++)
                    szOutput.AppendFormat("%02X", *(BYTE *)(pbInput+iCount));
            }
            return szOutput;
        }
        else
            return "ERROR: ConvertBytesToString(): pbInput shouldn't be NULL";
    }
    else
        return "ERROR: ConvertBytesToString(): iLength must be >0";

}



/*---------------------------------------------------------------------
  Name   : OnBnClickedBtngetatr()
  Param  : -
  Pre    : -
  Post   : -
  Return : void

  Description:
    Attempts to get the Answer-To-Reset (ATR) string from the
    currently inserted smartcard and adds it to c_Log.
---------------------------------------------------------------------*/
void CAPDUScannerDlg::OnBnClickedBtngetatr()
{
    BYTE bRawATR[60]; 
	DWORD dwATRlen=0;
    ZeroMemory( bRawATR, 60 );

	if (!m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen ))
    { 
        m_pSmartCard->CardDisconnect();
        return;
    }
    WriteToLog( "Answer-To-Reset: " );
    WriteToLog( ConvertBytesToHexString( dwATRlen, bRawATR, true ), true );

	m_pSmartCard->CardDisconnect();
}


/*---------------------------------------------------------------------
  Name   : OnBnClickedBtnscan()
  Param  : -
  Pre    : -
  Post   : -
  Return : void

  Description:
    Performs the actual APDU scan.
---------------------------------------------------------------------*/
void CAPDUScannerDlg::OnBnClickedBtnscan()
{
	char dateStr [9];
    char timeStr [9];
    _strdate(dateStr);
    _strtime(timeStr);

    WriteToLog("\r\n===========================================================");
    WriteToLog("Command APDU scan started on " + CString(dateStr) + " at " + CString(timeStr) + "\r\n");

	// start thread for command APDU scan
	m_pwtCommandScanner = AfxBeginThread (CCommandScanner::APDUScannerThread, 0);

	// disable GUI
	ToggleGUI(GUI_FOR_RUNNING_SCAN);
}


/*---------------------------------------------------------------------
  Name   : ToogleGUI()
  Param  : (in) const int iRequestedGUI (GUI_FOR_RUNNING_SCAN, GUI_DEFAULT, GUI_FOR_NOREADERSFOUND)
  Pre    : -
  Post   : -
  Return : void

  Description:
    Enables or disables GUI controls depending on iRequestedGUI.
---------------------------------------------------------------------*/
void CAPDUScannerDlg::ToggleGUI(const int iRequestedGUI)
{
	switch (iRequestedGUI)
	{
	case GUI_FOR_RUNNING_SCAN:
		{ // disable GUI controls
			// General controls
			c_btnGetATR.EnableWindow(false);
			c_btnScan.EnableWindow(false);

			// MPCOS controls
			c_btnFileScanMPCOS.EnableWindow(false);
			
			// Chipknip controls
			c_btnFileScanChipknip.EnableWindow(false);
			c_btnReadChipknip.EnableWindow(false);
			c_chkUsePIN_Chipknip.EnableWindow(false);
			c_txtPIN_Chipknip.EnableWindow(false);
			
			// GSIM SIM controls
			c_btnFileScanSimcardGSM.EnableWindow(false);
			c_btnReadSIM.EnableWindow(false);
			c_chkUsePIN_GSMSIM.EnableWindow(false);
			c_txtPIN_GSMSIM.EnableWindow(false);

			c_btnReset.EnableWindow(false);
			c_btnStop.EnableWindow(true);
			c_btnPause.EnableWindow(true);

			c_cbCLA.EnableWindow(false);
			c_cbINS.EnableWindow(false);
			c_cbP1.EnableWindow(false);
			c_cbP2.EnableWindow(false);
			c_cbP3.EnableWindow(false);			
			c_cbD1.EnableWindow(false);
			c_cbD2.EnableWindow(false);

			c_chkShowWarnings.EnableWindow(false);
			c_chkShowCheckErrors.EnableWindow(false);
			c_chkShowExecErrors.EnableWindow(false);

			c_chkReconnect.EnableWindow(false);
			
			c_chkFixCLA.EnableWindow(false);
			c_chkFixINS.EnableWindow(false);
			c_chkFixP1.EnableWindow(false);
			c_chkFixP2.EnableWindow(false);
			c_chkFixP3.EnableWindow(false);
			c_chkFixD1.EnableWindow(false);
			c_chkFixD2.EnableWindow(false);
			c_chkScanD1.EnableWindow(false);
			c_chkScanD2.EnableWindow(false);
			break;
		}
	case GUI_DEFAULT:
		{ // enable GUI
			// General controls
			c_btnGetATR.EnableWindow(true);
			c_btnScan.EnableWindow(true);

			// MPCOS controls
			c_btnFileScanMPCOS.EnableWindow(true);

			// Chipknip controls
			c_btnFileScanChipknip.EnableWindow(true);
			c_btnReadChipknip.EnableWindow(true);
			c_chkUsePIN_Chipknip.EnableWindow(true);
			if (c_chkUsePIN_Chipknip.GetCheck()==1)c_txtPIN_Chipknip.EnableWindow(true);

			// GSM SIM controls
			c_btnFileScanSimcardGSM.EnableWindow(true);
			c_btnReadSIM.EnableWindow(true);
			c_chkUsePIN_GSMSIM.EnableWindow(true);
			if (c_chkUsePIN_GSMSIM.GetCheck()==1) c_txtPIN_GSMSIM.EnableWindow(true);

			c_btnReset.EnableWindow(true);
			c_btnStop.EnableWindow(false);
			c_btnPause.EnableWindow(false);
			c_btnPause.SetWindowText("&Pause");

			if (c_chkFixCLA.GetCheck()==1) c_cbCLA.EnableWindow(true);
			if (c_chkFixINS.GetCheck()==1) c_cbINS.EnableWindow(true);
			if (c_chkFixP1.GetCheck()==1) c_cbP1.EnableWindow(true);
			if (c_chkFixP2.GetCheck()==1) c_cbP2.EnableWindow(true);
			if (c_chkFixP3.GetCheck()==1) c_cbP3.EnableWindow(true);			
			if (c_chkFixD1.GetCheck()==1) c_cbD1.EnableWindow(true);
			if (c_chkFixD2.GetCheck()==1) c_cbD2.EnableWindow(true);

			c_chkShowWarnings.EnableWindow(true);
			c_chkShowCheckErrors.EnableWindow(true);
			c_chkShowExecErrors.EnableWindow(true);

			c_chkReconnect.EnableWindow(true);

			c_chkFixCLA.EnableWindow(true);
			c_chkFixINS.EnableWindow(true);
			c_chkFixP1.EnableWindow(true);
			c_chkFixP2.EnableWindow(true);
			c_chkFixP3.EnableWindow(true);
			c_chkFixD1.EnableWindow(true);
			c_chkFixD2.EnableWindow(true);
			c_chkScanD1.EnableWindow(true);
			c_chkScanD2.EnableWindow(true);
			break;
		}
	case GUI_FOR_NOREADERSFOUND:
		{ // disable ALL controls that are useless without reader
			c_btnGetATR.EnableWindow(false);
			c_btnScan.EnableWindow(false);
			c_btnFileScanChipknip.EnableWindow(false);
			c_btnFileScanMPCOS.EnableWindow(false);
			c_btnFileScanSimcardGSM.EnableWindow(false);
			c_btnReadChipknip.EnableWindow(false);
			c_chkUsePIN_Chipknip.EnableWindow(false);
			c_txtPIN_Chipknip.EnableWindow(false);
			c_btnReadSIM.EnableWindow(false);
			c_chkUsePIN_GSMSIM.EnableWindow(false);
			c_txtPIN_GSMSIM.EnableWindow(false);
			break;
		}
	}

}

void CAPDUScannerDlg::OnBnClickedBtnpause()
{
	CString sCaption;
	DWORD ret;
	c_btnPause.GetWindowText(sCaption);

	char dateStr [9];
	char timeStr [9];
	_strdate(dateStr);
	_strtime(timeStr);

	CString sCurrentAPDU;
	c_txtCurrentAPDU.GetWindowText(sCurrentAPDU);
	if (sCaption.Compare("&Pause") == 0)
	{
		if (m_pwtCommandScanner)
		{ // pause APDU command scan
			ret = m_pwtCommandScanner->SuspendThread();
			m_bAPDUScannerThreadIsRunning = false;
			WriteToLog("------ Pausing APDU command scan at APDU: " + sCurrentAPDU + " (PAUSED ON " + CString(dateStr) + " AT " + CString(timeStr) + ")");
			c_btnPause.SetWindowText("&Continue");
		}
		else if (m_pwtFileScanner)
		{ // pause EF/DF scan
			ret = m_pwtFileScanner->SuspendThread();
			m_bFileScannerThreadIsRunning = false;
			WriteToLog("------ Pausing EF/DF scan at APDU: " + sCurrentAPDU + " (PAUSED ON " + CString(dateStr) + " AT " + CString(timeStr) + ")");
			c_btnPause.SetWindowText("&Continue");
		} 
		else if (m_pwtChipknipTinker)
		{ // pause TINKER attempts
			ret = m_pwtChipknipTinker->SuspendThread();
			m_bChipknipTinkerThreadIsRunning = false;
			WriteToLog("------ Pausing TINKER at APDU: " + sCurrentAPDU + " (PAUSED ON " + CString(dateStr) + " AT " + CString(timeStr) + ")");
			c_btnPause.SetWindowText("&Continue");
		} 
		else if (m_pwtDumpGSM)
		{ // pause GSM SIM dumping
			ret = m_pwtDumpGSM->SuspendThread();
			m_bGSMDumperThreadIsRunning = false;
			WriteToLog("------ Pausing GSM SIM dump (PAUSED ON " + CString(dateStr) + " AT " + CString(timeStr) + ")");
			c_btnPause.SetWindowText("&Continue");
		} 
	}
	else			
	{ 
		if (m_pwtCommandScanner)
		{ // resume command APDU scan
			ret = m_pwtCommandScanner->ResumeThread();
			m_bAPDUScannerThreadIsRunning = true;
			WriteToLog("\r\n------ Resuming scan at APDU: " + sCurrentAPDU + " (RESUMED ON " + CString(dateStr) + " AT " + CString(timeStr) + ")");
			c_btnPause.SetWindowText("&Pause");
		}
		else if (m_pwtFileScanner)
		{ // resume EF/DF scan
			ret = m_pwtFileScanner->ResumeThread();
			m_bFileScannerThreadIsRunning = true;
			WriteToLog("\r\n------ Resuming EF/DF scan at APDU: " + sCurrentAPDU + " (RESUMED ON " + CString(dateStr) + " AT " + CString(timeStr) + ")");
			c_btnPause.SetWindowText("&Pause");
		}
		else if (m_pwtChipknipTinker)
		{ // resume TINKER attempts
			ret = m_pwtChipknipTinker->ResumeThread();
			m_bChipknipTinkerThreadIsRunning = true;
			WriteToLog("\r\n------ Resuming TINKER at APDU: " + sCurrentAPDU + " (RESUMED ON " + CString(dateStr) + " AT " + CString(timeStr) + ")");
			c_btnPause.SetWindowText("&Pause");
		}
		else if (m_pwtDumpGSM)
		{ // resume GSM SIM dumping
			ret = m_pwtDumpGSM->ResumeThread();
			m_bGSMDumperThreadIsRunning = true;
			WriteToLog("------ Resuming GSM SIM dump (RESUMED ON " + CString(dateStr) + " AT " + CString(timeStr) + ")");
			c_btnPause.SetWindowText("&Pause");
		} 
	}

	if (ret == -1)
	{
		LPVOID lpMsgBuf;
		FormatMessage(
				FORMAT_MESSAGE_ALLOCATE_BUFFER |
				FORMAT_MESSAGE_FROM_SYSTEM |
				FORMAT_MESSAGE_IGNORE_INSERTS,
				NULL,
				GetLastError(),
				MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
				(LPTSTR) &lpMsgBuf,
				0,
				NULL
			);

		::MessageBox( NULL, (LPCTSTR)lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION );
		// Free the buffer.
		LocalFree(lpMsgBuf);
	}
}

void CAPDUScannerDlg::OnBnClickedBtnstop()
{
	if (m_pwtFileScanner)
	{
		// thread itself is expected to do TerminateThread once (m_bFileScannerThreadIsRunning==false)
		// so it can close its resources itself (e.g. move graceful to a CardDisconnect())
		m_bFileScannerThreadIsRunning = false;	
		m_pwtFileScanner = 0;
	}
	if (m_pwtCommandScanner)
	{
		// thread itself is expected to do TerminateThread once (m_bAPDUScannerThreadIsRunning==false)
		// so it can close its resources itself (e.g. move graceful to a CardDisconnect())
		m_bAPDUScannerThreadIsRunning = false; 
		m_pwtCommandScanner = 0;
	}
	if (m_pwtChipknipTinker)
	{
		// thread itself is expected to do TerminateThread once (m_bAPDUScannerThreadIsRunning==false)
		// so it can close its resources itself (e.g. move graceful to a CardDisconnect())
		m_bChipknipTinkerThreadIsRunning = false; 
		m_pwtChipknipTinker = 0;
	}
	if (m_pwtDumpGSM)
	{
		// thread itself is expected to do TerminateThread once (m_bAPDUScannerThreadIsRunning==false)
		// so it can close its resources itself (e.g. move graceful to a CardDisconnect())
		m_bGSMDumperThreadIsRunning = false; 
		m_pwtDumpGSM = 0;
	}

	// enable GUI
	ToggleGUI(GUI_DEFAULT);

	CString sCurrentAPDU;
	c_txtCurrentAPDU.GetWindowText(sCurrentAPDU);
	c_txtCurrentAPDU.SetWindowText("");

	char dateStr [9];
    char timeStr [9];
    _strdate(dateStr);
    _strtime(timeStr);

    WriteToLog("\r\nAborted on " + CString(dateStr) + " at " + CString(timeStr));
	WriteToLog("(Current APDU: " + sCurrentAPDU + ")");
    WriteToLog("===========================================================");
}

void CAPDUScannerDlg::OnBnClickedChkfixcla()
{
	if (c_chkFixCLA.GetCheck()==1)
    { /* FixCLA checkbox is checked */
		c_cbCLA.EnableWindow(true);
		sSettings.Replace(";CLA=n", ";CLA=y");
	}
    else
    { /* FixCLA checkbox is unchecked */
		c_cbCLA.EnableWindow(false);
		sSettings.Replace(";CLA=y", ";CLA=n");
    }
	c_btnReset.EnableWindow(true);
	c_btnSave.EnableWindow(true);
}

void CAPDUScannerDlg::OnBnClickedChkfixins()
{
	if (c_chkFixINS.GetCheck()==1)
    { /* FixINS checkbox is checked */
		c_cbINS.EnableWindow(true);
		sSettings.Replace(";INS=n", ";INS=y");
    }
    else
    { /* FixINS checkbox is unchecked */
		c_cbINS.EnableWindow(false);
		sSettings.Replace(";INS=y", ";INS=n");
    }
	c_btnReset.EnableWindow(true);
	c_btnSave.EnableWindow(true);
}

void CAPDUScannerDlg::OnBnClickedChkfixp1()
{
	if (c_chkFixP1.GetCheck()==1)
    { /* FixP1 checkbox is checked */
		c_cbP1.EnableWindow(true);
		sSettings.Replace(";P1=n", ";P1=y");
    }
    else
    { /* FixP1 checkbox is unchecked */
		c_cbP1.EnableWindow(false);
		sSettings.Replace(";P1=y", ";P1=n");
    }
	c_btnReset.EnableWindow(true);
	c_btnSave.EnableWindow(true);
}

void CAPDUScannerDlg::OnBnClickedChkfixp2()
{
	if (c_chkFixP2.GetCheck()==1)
    { /* FixP2 checkbox is checked */
		c_cbP2.EnableWindow(true);
		sSettings.Replace(";P2=n", ";P2=y");
    }
    else
    { /* FixP2 checkbox is unchecked */
		c_cbP2.EnableWindow(false);
		sSettings.Replace(";P2=y", ";P2=n");
    }
	c_btnReset.EnableWindow(true);
	c_btnSave.EnableWindow(true);
}

void CAPDUScannerDlg::OnBnClickedChkfixp3()
{
	if (c_chkFixP3.GetCheck()==1)
    { /* FixP3/Le checkbox is checked */
		c_cbP3.EnableWindow(true);
		sSettings.Replace(";P3=n", ";P3=y");
    }
    else
    { /* FixP3/Le checkbox is unchecked */
		c_cbP3.EnableWindow(false);
		sSettings.Replace(";P3=y", ";P3=n");
    }
	c_btnReset.EnableWindow(true);
	c_btnSave.EnableWindow(true);
}


void CAPDUScannerDlg::OnBnClickedChkfixd1()
{
	if (c_chkFixD1.GetCheck()==1)
    { /* FixD1 checkbox is checked */
		c_cbD1.EnableWindow(true);
		sSettings.Replace(";D1=n", ";D1=y");
    }
    else
    { /* FixD1 checkbox is unchecked */
		c_cbD1.EnableWindow(false);
		sSettings.Replace(";D1=y", ";D1=n");
    }
	c_btnReset.EnableWindow(true);
	c_btnSave.EnableWindow(true);
}

void CAPDUScannerDlg::OnBnClickedChkfixd2()
{
	if (c_chkFixD2.GetCheck()==1)
    { /* FixD2 checkbox is checked */
		c_cbD2.EnableWindow(true);
		sSettings.Replace(";D2=n", ";D2=y");
    }
    else
    { /* FixD2 checkbox is unchecked */
		c_cbD2.EnableWindow(false);
		sSettings.Replace(";D2=y", ";D2=n");
    }
	c_btnReset.EnableWindow(true);
	c_btnSave.EnableWindow(true);
}

void CAPDUScannerDlg::OnBnClickedChkscand1()
{
	if (c_chkScanD1.GetCheck()==1)
    { /* ScanD1 checkbox is checked */
		c_chkFixD1.EnableWindow(true);
		sSettings.Replace(";ScanD1=n", ";ScanD1=y");
    }
    else
    { /* ScanD1 checkbox is unchecked */
		c_chkFixD1.EnableWindow(false);
		c_cbD1.EnableWindow(false);
		sSettings.Replace(";ScanD1=y", ";ScanD1=n");
    }
	c_btnReset.EnableWindow(true);
	c_btnSave.EnableWindow(true);
}

void CAPDUScannerDlg::OnBnClickedChkscand2()
{
	if (c_chkScanD2.GetCheck()==1)
    { /* ScanD2 checkbox is checked */
		c_chkFixD2.EnableWindow(true);
		sSettings.Replace(";ScanD2=n", ";ScanD2=y");
    }
    else
    { /* ScanD2 checkbox is unchecked */
		c_chkFixD2.EnableWindow(false);
		c_cbD2.EnableWindow(false);
		sSettings.Replace(";ScanD2=y", ";ScanD2=n");
    }
	c_btnReset.EnableWindow(true);
	c_btnSave.EnableWindow(true);
}



void CAPDUScannerDlg::OnBnClickedBtnsave()
{
	ofstream ofsSettings;
	ofsSettings.open(m_sSettingsFile, ios::trunc);
	if (!ofsSettings)
	{
		AfxMessageBox("ERROR: Could neither read nor create settings.cfg!");
	}
	else
	{
		ofsSettings << sSettings << endl;
		ofsSettings.flush();
		ofsSettings.close();
	}
	c_btnSave.EnableWindow(false);
	LocalFree(ofsSettings);
}



void CAPDUScannerDlg::OnBnClickedBtnreset()
{
	c_chkFixCLA.SetCheck(BST_UNCHECKED);
	c_chkFixINS.SetCheck(BST_UNCHECKED);
	c_chkFixP1.SetCheck(BST_UNCHECKED);
	c_chkFixP2.SetCheck(BST_UNCHECKED);
	c_chkFixP3.SetCheck(BST_UNCHECKED);
	c_chkFixD1.SetCheck(BST_UNCHECKED);
	c_chkFixD2.SetCheck(BST_UNCHECKED);

	c_chkShowWarnings.SetCheck(BST_CHECKED);
	c_chkShowCheckErrors.SetCheck(BST_CHECKED);
	c_chkShowExecErrors.SetCheck(BST_CHECKED);

	c_chkReconnect.EnableWindow(false);

	c_chkScanD1.SetCheck(BST_UNCHECKED);
	c_chkScanD2.SetCheck(BST_UNCHECKED);

	c_cbCLA.EnableWindow(false);
	c_cbINS.EnableWindow(false);
	c_cbP1.EnableWindow(false);
	c_cbP2.EnableWindow(false);
	c_cbP3.EnableWindow(false);
	c_cbD1.EnableWindow(false);
	c_cbD2.EnableWindow(false);

	sSettings = ";CLA=n,0x00;INS=n,0x00;P1=n,0x00;P2=n,0x00;P3=n,0x00;D1=n,0x00;D2=n,0x00;ScanD1=n;ScanD2=n;ShowWarnings=y;ShowExecErrors=y;ShowCheckErrors=y;Reconnect=n;";

	c_btnSave.EnableWindow(true);	
	c_btnReset.EnableWindow(false);
}


void CAPDUScannerDlg::OnBnClickedBtnreadchipknip()
{
	/*
	  'Chipknip' is the Dutch name for the international 'Proton' purse system,
	  which is based on the proprietary EN-1546 standard. The current generation
	  of Chipknip chips is the BULL CC1000 series, obsoleting CC60 and CC80, but
	  with full backwards compatibility.

	  - CC60 is 'recognized' by ATR.TS=3F (inverse convention)
	  - CC1000 is 'recognized' by ATR.TS=3B (direct convention)

	*/
	
	// disable GUI
	ToggleGUI(GUI_FOR_RUNNING_SCAN);
	
	c_txtCurrentAPDU.SetWindowText("");

	char dateStr [9];
    char timeStr [9];
    _strdate(dateStr);
    _strtime(timeStr);

    WriteToLog("\r\n===========================================================");
    WriteToLog("Attempting to read Chipknip on " + CString(dateStr) + " at " + CString(timeStr) + "\r\n");


	CChipknip ckChipknip = CChipknip();

	c_ComboUSBReaders.GetLBText(c_ComboUSBReaders.GetCurSel(), ckChipknip.m_sSelectedReader);
	ckChipknip.m_iNumReaders = m_pSmartCard->m_iNumReaders;

    BYTE bRawATR[60];
	DWORD dwATRlen=0;
    ZeroMemory( bRawATR, 60 );

	if (!ckChipknip.PrepareCard( false, bRawATR, &dwATRlen ))
    {
        ckChipknip.CardDisconnect();
		return; 
    }

	/*int iATRln = 0;
	for (int i = 0; i < sizeof(bRawATR); i++)
		if ((bRawATR[i] & 0x90) && (bRawATR[i+1]==0x00))
		  break;
		else
		  iATRln++;*/

    WriteToLog( "Answer-To-Reset: " + ConvertBytesToHexString( dwATRlen, bRawATR, true ) + "\r\n\r\n", true );
	
	// get all interesting stuff
	ckChipknip.DumpInfo();
		
	// disconnect card
	ckChipknip.CardDisconnect();

	// enable GUI
	ToggleGUI(GUI_DEFAULT);
}


void CAPDUScannerDlg::OnCbnSelchangeCbcla()
{
	CString sNEW;
	c_cbCLA.GetWindowText(sNEW);
	CString sOldSetting = sSettings.Mid(sSettings.Find(";CLA="), 11);
	CString sNewSetting = sOldSetting.Mid(0, sOldSetting.GetLength()-2);
	sNewSetting.Append(sNEW);
	sSettings.Replace(sOldSetting, sNewSetting);
}

void CAPDUScannerDlg::OnCbnSelchangeCbins()
{
	CString sNEW;
	c_cbINS.GetWindowText(sNEW);
	CString sOldSetting = sSettings.Mid(sSettings.Find(";INS="), 11);
	CString sNewSetting = sOldSetting.Mid(0, sOldSetting.GetLength()-2);
	sNewSetting.Append(sNEW);
	sSettings.Replace(sOldSetting, sNewSetting);
}

void CAPDUScannerDlg::OnCbnSelchangeCbp1()
{
	CString sNEW;
	c_cbP1.GetWindowText(sNEW);
	CString sOldSetting = sSettings.Mid(sSettings.Find(";P1="), 10);
	CString sNewSetting = sOldSetting.Mid(0, sOldSetting.GetLength()-2);
	sNewSetting.Append(sNEW);
	sSettings.Replace(sOldSetting, sNewSetting);
}

void CAPDUScannerDlg::OnCbnSelchangeCbp2()
{
	CString sNEW;
	c_cbP2.GetWindowText(sNEW);
	CString sOldSetting = sSettings.Mid(sSettings.Find(";P2="), 10);
	CString sNewSetting = sOldSetting.Mid(0, sOldSetting.GetLength()-2);
	sNewSetting.Append(sNEW);
	sSettings.Replace(sOldSetting, sNewSetting);
}

void CAPDUScannerDlg::OnCbnSelchangeCbp3()
{
	CString sNEW;
	c_cbP3.GetWindowText(sNEW);
	CString sOldSetting = sSettings.Mid(sSettings.Find(";P3="), 10);
	CString sNewSetting = sOldSetting.Mid(0, sOldSetting.GetLength()-2);
	sNewSetting.Append(sNEW);
	sSettings.Replace(sOldSetting, sNewSetting);
}

void CAPDUScannerDlg::OnCbnSelchangeCbd1()
{
	CString sNEW;
	c_cbD1.GetWindowText(sNEW);
	CString sOldSetting = sSettings.Mid(sSettings.Find(";D1="), 10);
	CString sNewSetting = sOldSetting.Mid(0, sOldSetting.GetLength()-2);
	sNewSetting.Append(sNEW);
	sSettings.Replace(sOldSetting, sNewSetting);
}

void CAPDUScannerDlg::OnCbnSelchangeCbd2()
{
	CString sNEW;
	c_cbD2.GetWindowText(sNEW);
	CString sOldSetting = sSettings.Mid(sSettings.Find(";D2="), 10);
	CString sNewSetting = sOldSetting.Mid(0, sOldSetting.GetLength()-2);
	sNewSetting.Append(sNEW);
	sSettings.Replace(sOldSetting, sNewSetting);
}

void CAPDUScannerDlg::OnBnClickedBtnfilescan()
{
	char dateStr [9];
    char timeStr [9];
    _strdate(dateStr);
    _strtime(timeStr);

    WriteToLog("\r\n===========================================================");
    WriteToLog("EF/DF filesystem scan started on " + CString(dateStr) + " at " + CString(timeStr) + "\r\n");

	// start thread for MF/DF/EFs scan
	m_pwtFileScanner = AfxBeginThread (CMPCOSFileScanner::FileScannerThread, 0);
	//m_pwtFileScanner = AfxBeginThread (CChipknipFileScanner::FileScannerThread, 0);

	// disable GUI
	ToggleGUI(GUI_FOR_RUNNING_SCAN);
}



void CAPDUScannerDlg::OnBnClickedBtntest()
{
	char dateStr [9];
    char timeStr [9];
    _strdate(dateStr);
    _strtime(timeStr);

	WriteToLog("\r\n===========================================================");
    WriteToLog("Attempting to TINKER with Chipknip on " + CString(dateStr) + " at " + CString(timeStr) + "\r\n");

	// start thread for command APDU scan
	m_pwtChipknipTinker = AfxBeginThread (CChipknipTinker::ChipknipTinkerThread, 0);

	// disable GUI
	ToggleGUI(GUI_FOR_RUNNING_SCAN);
}


void CAPDUScannerDlg::OnBnClickedWarnings()
{
	if (c_chkShowWarnings.GetCheck()==1)
    { /* checked */
		sSettings.Replace(";ShowWarnings=n", ";ShowWarnings=y");
    }
    else
    { /* unchecked */
		sSettings.Replace(";ShowWarnings=y", ";ShowWarnings=n");
    }
	c_btnReset.EnableWindow(true);
	c_btnSave.EnableWindow(true);
}

void CAPDUScannerDlg::OnBnClickedExecerr()
{
	if (c_chkShowExecErrors.GetCheck()==1)
    { /* checked */
		sSettings.Replace(";ShowExecErrors=n", ";ShowExecErrors=y");
    }
    else
    { /* unchecked */
		sSettings.Replace(";ShowExecErrors=y", ";ShowExecErrors=n");
    }
	c_btnReset.EnableWindow(true);
	c_btnSave.EnableWindow(true);
}

void CAPDUScannerDlg::OnBnClickedCheckerr()
{
	if (c_chkShowCheckErrors.GetCheck()==1)
    { /* checked */
		sSettings.Replace(";ShowCheckErrors=n", ";ShowCheckErrors=y");
    }
    else
    { /* unchecked */
		sSettings.Replace(";ShowCheckErrors=y", ";ShowCheckErrors=n");
    }
	c_btnReset.EnableWindow(true);
	c_btnSave.EnableWindow(true);
}

void CAPDUScannerDlg::OnBnClickedDisconnect()
{
	if (c_chkReconnect.GetCheck()==1)
    { /* checked */
		sSettings.Replace(";Reconnect=n", ";Reconnect=y");
    }
    else
    { /* unchecked */
		sSettings.Replace(";Reconnect=y", ";Reconnect=n");
    }
	c_btnReset.EnableWindow(true);
	c_btnSave.EnableWindow(true);
}

void CAPDUScannerDlg::OnCbnSelchangePcsc()
{
  c_ComboUSBReaders.GetLBText(c_ComboUSBReaders.GetCurSel(), m_pSmartCard->m_sSelectedReader);
}

void CAPDUScannerDlg::OnBnClickedBtnreadsim()
{
	/* TO BE DONE --> UNFINISHED
	  Here we're going to access a GSM SIM-card and try to read as much
	  information from it as possible.
	*/

	char dateStr [9];
    char timeStr [9];
    _strdate(dateStr);
    _strtime(timeStr);

    WriteToLog("\r\n===========================================================");
    WriteToLog("Starting GSM SIM dump on " + CString(dateStr) + " at " + CString(timeStr) + "\r\n");

	// start thread for dumping
	m_pwtDumpGSM = AfxBeginThread (CSimcardGSM::DumperThread, 0);

	// disable GUI
	ToggleGUI(GUI_FOR_RUNNING_SCAN);
}


void CAPDUScannerDlg::OnBnClickedBtnfilescanmpcos()
{
	char dateStr [9];
    char timeStr [9];
    _strdate(dateStr);
    _strtime(timeStr);

    WriteToLog("\r\n===========================================================");
    WriteToLog("MPCOS EF/DF filesystem scan started on " + CString(dateStr) + " at " + CString(timeStr) + "\r\n");

	// start thread for MF/DF/EFs scan
	m_pwtFileScanner = AfxBeginThread (CMPCOSFileScanner::FileScannerThread, 0);

	// disable GUI
	ToggleGUI(GUI_FOR_RUNNING_SCAN);
}

void CAPDUScannerDlg::OnBnClickedBtnfilescanchipknip()
{
	char dateStr [9];
    char timeStr [9];
    _strdate(dateStr);
    _strtime(timeStr);

    WriteToLog("\r\n===========================================================");
    WriteToLog("Starting Chipknip EF/DF filesystem scan on " + CString(dateStr) + " at " + CString(timeStr) + "\r\n");

	// start thread for MF/DF/EFs scan
	m_pwtFileScanner = AfxBeginThread (CChipknipFileScanner::FileScannerThread, 0);

	// disable GUI
	ToggleGUI(GUI_FOR_RUNNING_SCAN);
}


void CAPDUScannerDlg::OnBnClickedBtnfilescansimcardgsm()
{

	char dateStr [9];
    char timeStr [9];
    _strdate(dateStr);
    _strtime(timeStr);

    WriteToLog("\r\n===========================================================");
    WriteToLog("Starting Chipknip EF/DF filesystem scan on " + CString(dateStr) + " at " + CString(timeStr) + "\r\n");

	// start thread for MF/DF/EFs scan
	m_pwtFileScanner = AfxBeginThread (CMPCOSFileScanner::FileScannerThread, 0);
	//m_pwtFileScanner = AfxBeginThread (CChipknipFileScanner::FileScannerThread, 0);

	// disable GUI
	ToggleGUI(GUI_FOR_RUNNING_SCAN);
}

void CAPDUScannerDlg::OnBnClickedBtntest2()
{
  // 1  2  4  8  16 32 64 128
  // 
  byte b1 = 0x00; // 0000 0000
  byte b2 = 0x14; // 0010 1000
  
  byte b3 = b2 << 4 | b2 >> 4;

  ::OutputDebugString(ConvertByteToBinaryString(b1)+"\r\n");
  ::OutputDebugString(ConvertByteToBinaryString(b2)+"\r\n");
  ::OutputDebugString(ConvertByteToBinaryString(b3)+"\r\n");

  byte b4 = b2 << 8;
  ::OutputDebugString(ConvertByteToBinaryString(b4)+"\r\n");
}

void CAPDUScannerDlg::OnBnClickedBtnapduconsole()
{	
	m_pdlgAPDUconsole->ShowWindow(SW_SHOW);
}

void CAboutDlg::OnEnChangeTxtapdu()
{
}

void CAPDUScannerDlg::OnBnClickedPinChipknip()
{
	if (c_chkUsePIN_Chipknip.GetCheck()==1)
    { /* "Use PIN" checkbox is checked for Chipknip */
		c_txtPIN_Chipknip.EnableWindow(true);
		c_txtPIN_Chipknip.SetFocus();
	}
    else
    { /* unchecked */
		c_txtPIN_Chipknip.EnableWindow(false);
    }
}

void CAPDUScannerDlg::OnBnClickedPinGsmsim()
{
	if (c_chkUsePIN_GSMSIM.GetCheck()==1)
    { /* "Use PIN" checkbox is checked for GSM SIM */
		c_txtPIN_GSMSIM.EnableWindow(true);
		c_txtPIN_GSMSIM.SetFocus();
	}
    else
    { /* unchecked */
		c_txtPIN_GSMSIM.EnableWindow(false);
    }
}


BOOL CAPDUScannerDlg::PreTranslateMessage( MSG* pMsg )
{
	// make Ctrl+A select all
	if ( pMsg->message == WM_KEYDOWN && 
		(pMsg->wParam == 'A' && (GetKeyState(VK_CONTROL) & 0x8000 ))
		)
	{	
		((CEdit *)this->GetFocus())->SetSel(0, -1, true);
		//AfxMessageBox("Control+A");
	}

	// prevent that pressing Enter in a CEdit terminates APDUScanner
	if ( pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN )
	{
		
		int idCtrl = this->GetFocus()->GetDlgCtrlID();
		if (( idCtrl == IDC_TXTPIN_GSMSIM ) || ( idCtrl == IDC_TXTPIN_CHIPKNIP ))
			return true;
	}
	return CDialog::PreTranslateMessage( pMsg );
}



void CAPDUScannerDlg::OnStnClickedLbltitle()
{
	// TODO: Add your control notification handler code here
}
