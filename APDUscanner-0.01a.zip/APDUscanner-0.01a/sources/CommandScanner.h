#pragma once

#include "APDUScanner.h"
#include "APDUScannerDlg.h"
#include "smartcard.h"

static byte intToByte(int iNumber)
{
  if(iNumber <= 255)
  {
    if(iNumber > 127)
	{
      byte bRet = (byte)(-(-iNumber) & 0xff);
	  return bRet;
	} else return (byte)iNumber;
  } else return 0;
}


class CCommandScanner
{
public:
	CCommandScanner(void);
	~CCommandScanner(void);

    static UINT APDUScannerThread(LPVOID param);

};
