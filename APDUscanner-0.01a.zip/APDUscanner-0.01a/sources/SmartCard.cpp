/*
* Copyright (c) 2006, Matthijs Koot (matthijs at koot.biz)
* All rights reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the Koot Organization nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================

  SMARTCARD.CPP

  License     : BSD-style (yep, just sell it!)
  Author      : Matthijs Koot (matthijs at koot.biz)
  Description : This CSmartCard class defines behavior that is relevant to
                all (or at least, multiple) ISO-7816 cards.

  History :
     2007-12-28, mrkoot: file created

  Remarks :
    - none

===============================================================================*/

#include "StdAfx.h"

#include "APDUScanner.h"
#include "APDUScannerDlg.h"

#include ".\smartcard.h"


CSmartCard::CSmartCard(void)
{
}

CSmartCard::~CSmartCard(void)
{
	CardDisconnect();
}

/*---------------------------------------------------------------------
  Name   : PrepareCard()
  Param  : BOOL bVerboseLog
           BYTE *pbRawATR
  Pre    : -
  Post   : newCard is set
           newContext is set
  Return : true  --> success
           false --> failure

  Description:
    Attempts to create a card context, get a handle to the inserted
	card and read the current card's ATR.
---------------------------------------------------------------------*/
//BOOL CSmartCard::PrepareCard( BOOL bVerboseLog, BYTE *pbRawATR )
BOOL CSmartCard::PrepareCard( BOOL bVerboseLog, BYTE *pbRawATR, DWORD *pdwATRlen)
{
    /*
    step 1) check available card readers
    step 2) set a card context
    step 3) set the current PC/SC reader and context
    step 4) check for card presence
    step 5) send Reset signal to card to get it's ATR bytestring
    */

    // 1. check available card readers

		//CString s = (CAPDUScannerDlg)theApp.;
		//int i = theApp.dlg.m_iNumReaders;
		if (m_iNumReaders < 1)
		{
			AfxMessageBox("No PC/SC card readers available.");
			return false;
		}


    // 2. create smartcard context

		long lReturn = SCardEstablishContext( SCARD_SCOPE_USER, NULL, NULL, &m_hSCardContext );

		if (lReturn != SCARD_S_SUCCESS)
		{
			theApp.dlg.WriteToLog("ERROR: Card context could not be established.");
			return false;
		}

    // 3. set the current PC/SC reader

		//CComboBox *pc_ComboUSBReaders = &(theApp.dlg.c_ComboUSBReaders);
		//pc_ComboUSBReaders->GetLBText(pc_ComboUSBReaders->GetCurSel(), m_sSelectedReader);

    // 4. check for card presence

		char* cReaderName = m_sSelectedReader.GetBuffer(0);
		char ReaderName[80];
		strncpy( ReaderName, cReaderName, 80 );

		SCARD_READERSTATE hReaderState;
		hReaderState.szReader = ReaderName;
		hReaderState.dwCurrentState = SCARD_STATE_UNAWARE;

		lReturn = SCardGetStatusChange( m_hSCardContext, 0, &hReaderState, 1 );
		if (lReturn != SCARD_S_SUCCESS) 
		{ // first error
			handleSCardError(lReturn, "SCardGetStatusChange");
			return false;
		}
		if (hReaderState.dwEventState & SCARD_STATE_PRESENT) 
		{ // card is present
			BYTE localbuf[60];

			if (pbRawATR == NULL) pbRawATR = localbuf; //new BYTE[60];
			ZeroMemory( pbRawATR, 60 );
			DWORD n = 60;
			char errmsg[160];
			errmsg[0] = 0;

			// 5. send Reset signal to card to get it's ATR bytestring

			BOOL bRet = CardPowerUp(pbRawATR, &n, pdwATRlen);

			if (bRet)
			{
				// TBD: parse the ATR?
				return true;
			}
			else
			{ // card power-up failed 
				// TBD: log error?
				return false;
			}
		}
		else
		{// No card was present in the reader
			theApp.dlg.WriteToLog("ERROR: No smartcard found in reader [" + m_sSelectedReader + "]");
			return false;
		}
}



/*---------------------------------------------------------------------
  Name   : CardPowerUp()
  Param  : BYTE *atr            // buffer to store the received
                                // Answer-To-Reset (ATR) bytestring
           LPDWORD n            // bytestring length
  Pre    : -
  Post   : -
  Return : BOOL true --> success
           BOOL false --> failure

  Description:
    Connects to smartcard and fills Answer-To-Reset buffer.
---------------------------------------------------------------------*/
//BOOL CSmartCard::CardPowerUp( BYTE *pbATR, LPDWORD n ) 
BOOL CSmartCard::CardPowerUp( BYTE *pbATR, LPDWORD n, DWORD *pdwATRln ) 
{
    long lReturn;
	lReturn = SCardConnect( m_hSCardContext, m_sSelectedReader, SCARD_SHARE_EXCLUSIVE, SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_T1,
		&m_hSCardHandle, &m_dwProtocolT );

    if (lReturn != SCARD_S_SUCCESS)
    { // Error
		handleSCardError(lReturn, "SCardConnect");
		return false;
    }

    /* determine which protocol to use (T=0 or T=1) */
    if (m_dwProtocolT == SCARD_PROTOCOL_T0)
    { // this card (only?) supports T=0		
		m_dwProtocol = SCARD_PROTOCOL_T0;
    }
    else if (m_dwProtocolT == SCARD_PROTOCOL_T1)
    { // this card (only?) supports T=1
		m_dwProtocol = SCARD_PROTOCOL_T1;
    }

    char ReaderNameList[200];
    DWORD s = sizeof(ReaderNameList);
    BYTE ATR[60];
    DWORD dwState, dwProt, dwATRLen = sizeof(ATR);

	lReturn = SCardStatus( m_hSCardHandle, ReaderNameList, &s, &dwState, &dwProt, ATR, &dwATRLen );

	memcpy(pdwATRln, &dwATRLen, sizeof(DWORD));

	if (lReturn != SCARD_S_SUCCESS)
	{ // error
		handleSCardError(lReturn, "SCardStatus");
		return false;
	} 
	else 
	{
        if (dwState == SCARD_SPECIFIC)
        {
            if (n)
            {
                if (pbATR) memcpy( pbATR, ATR, (dwATRLen > *n) ? *n : dwATRLen );
                *n = dwATRLen;
            }
            return true;
        }
    }
    return true;
}

long CSmartCard::CardDisconnect()
{
	long lReturn = SCardDisconnect( m_hSCardHandle, SCARD_UNPOWER_CARD );

	/*
	if (lReturn != SCARD_S_SUCCESS)
	{
		CString s;
		s.Format("%d", lReturn);
		WriteToLog("ERROR: In CardDisconnect(): SCardDisconnect() failed with code " + s);
	}*/

	return lReturn;
}

void CSmartCard::handleSCardError(long lError, CString sFunction)
{
	switch(lError)
	{
		case SCARD_E_BAD_SEEK:
			{
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with SCARD_E_BAD_SEEK"); 
				break;
			}
		case SCARD_E_CANCELLED:
			{
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with SCARD_E_CANCELLED"); 
				break;
			}
		case SCARD_E_COMM_DATA_LOST:
			{
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with SCARD_E_COMM_DATA_LOST"); 
				break;
			}
		case SCARD_E_FILE_NOT_FOUND:
			{
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with SCARD_E_FILE_NOT_FOUND"); 
				break;
			}
		case SCARD_E_DIR_NOT_FOUND:
			{
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with SCARD_E_DIR_NOT_FOUND"); 
				break;
			}
		case SCARD_E_INVALID_HANDLE:
			{
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with SCARD_E_INVALID_HANDLE"); 
				break;
			}
		case SCARD_E_INSUFFICIENT_BUFFER:
			{
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with SCARD_E_INSUFFICIENT_BUFFER"); 
				break;
			}
		case SCARD_E_INVALID_PARAMETER:
			{
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with SCARD_E_INVALID_PARAMETER"); 
				break;
			}
		case SCARD_E_TIMEOUT:
			{
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with SCARD_E_TIMEOUT"); 
				break;
			}
		case SCARD_E_NO_READERS_AVAILABLE:
			{
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with SCARD_E_NO_READERS_AVAILABLE"); 
				break;
			}
		case SCARD_E_SHARING_VIOLATION:
			{
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with SCARD_E_SHARING_VIOLATION"); 
				break;
			}
		case SCARD_E_READER_UNAVAILABLE:
			{
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with SCARD_E_READER_UNAVAILABLE"); 
				break;
			}
		case SCARD_W_UNRESPONSIVE_CARD:
			{
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with SCARD_W_UNRESPONSIVE_CARD"); 
				break;
			}
		default:
			{	
				CString sCode;
				sCode.Format("0x%x", lError);
				theApp.dlg.WriteToLog("   ERROR: " + sFunction + "() failed with an unhandled error code " + sCode); 
				
				break;
			}
	}

	CardDisconnect();
}


/*---------------------------------------------------------------------
  Name   : ResponseIsOK()
  Param  : BYTE bSW1
           BYTE bSW2
  Pre    : -
  Post   : -
  Return : (BOOL) true if command APDU execution succeeded.
           (BOOL) false if command APDU execution failed.

  Description:
    Analyzes response APDU for success/failure and writes stuff
	to logfile.
---------------------------------------------------------------------*/

BOOL CSmartCard::ResponseIsOK(BYTE bSW1, BYTE bSW2, BOOL bWriteLog)
{
	CString sSW12;
	sSW12.Format("%02x%02x", bSW1, bSW2);
	BOOL bShowSuccesses    = true;  // hardcoded is probably OK... right? :-)
	BOOL bShowUnhandled    = true;  // hardcoded is probably OK... right? :-)
	BOOL bShowWarnings     = (theApp.dlg.c_chkShowWarnings.GetCheck()==1)    ?true:false;
	BOOL bShowExecErrors   = (theApp.dlg.c_chkShowExecErrors.GetCheck()==1)  ?true:false;
	BOOL bShowCheckErrors  = (theApp.dlg.c_chkShowCheckErrors.GetCheck()==1) ?true:false;
	switch(bSW1)
	{
		// ------ NORMAL RESPONSES -------
		case 0x90: // status OK, but no further information
			{	
				if (bWriteLog) theApp.dlg.WriteToLog(" --> [STATUS OK (" + sSW12 + "): command APDU was successfully executed]", false, bShowSuccesses); 
				return true;
			}

		case 0x9f: // Chipknip?
			{	
				if (bWriteLog) theApp.dlg.WriteToLog(" --> [STATUS OK (" + sSW12 + "): command APDU was successfully executed]", false, bShowSuccesses); 
				return true;
			}

		case 0x61: // SW2 indicates the number of response bytes still available
			{			
				CString sSW2;
				sSW2.Format("0x%02x (=%d)", bSW2, bSW2);
				if (bWriteLog) theApp.dlg.WriteToLog(" --> [STATUS OK (" + sSW12 + "): there are still " + sSW2 + " more bytes available (now try GET RESPONSE!)]", false, bShowSuccesses);
				return true;
			}

		// ------ WARNING RESPONSES -------
		case 0x62: // State of non-volatile memory unchanged
			{	
				switch(bSW2)
				{
					case 0x00:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [WARNING (" + sSW12 + "): State of non-volatile memory unchanged (SW2 indicates: no further information)]", false, bShowWarnings); 
							return true;
						}
					case 0x81:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [WARNING (" + sSW12 + "): State of non-volatile memory unchanged (SW2 indicates: part of returned data may be corrupted)]", false, bShowWarnings); 
							return true;
						}
					case 0x82:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [WARNING (" + sSW12 + "): State of non-volatile memory unchanged (SW2 indicates: end of file/record reached before reading Le bytes)]", false, bShowWarnings); 
							return true;
						}
					case 0x83:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [WARNING (" + sSW12 + "): State of non-volatile memory unchanged (SW2 indicates: selected file invalidated)]", false, bShowWarnings); 
							return true;
						}
					case 0x84:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [WARNING (" + sSW12 + "): State of non-volatile memory unchanged (SW2 indicates: FCI not formatted according to 1.1.5)]", false, bShowWarnings); 
							return true;
						}
					default:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [WARNING (" + sSW12 + "): State of non-volatile memory unchanged (SW2 indicates: unknown value! Cool!)]", false, bShowWarnings); 
							return true;
						}
				}
			}

		case 0x63: // State of non-volatile memory changed
			{	
				switch(bSW2)
				{
					case 0x00:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [WARNING (" + sSW12 + "): State of non-volatile memory changed (SW2 indicates: no information given)]", false, bShowWarnings); 
							return true;
						}
					case 0x81:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [WARNING (" + sSW12 + "): State of non-volatile memory changed (SW2 indicates: file filled up by the last write)]", false, bShowWarnings); 
							return true;
						}
				}

				if (bSW2 & 0xC0)
				{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [WARNING (" + sSW12 + "): State of non-volatile memory changed (SW2 indicates: Counter provided by 'X' (valued from 0 to 15))]", false, bShowWarnings); 
							return true;
				}
				else
				{
					if (bWriteLog) theApp.dlg.WriteToLog(" --> [WARNING (" + sSW12 + "): State of non-volatile memory changed (SW2 indicates: unknown value! Cool!)]", false, bShowWarnings); 
					return true;
				}



			}

			
		// ------ EXECUTION ERROR RESPONSES -------

		case 0x64: // State of non-volatile memory changed
			{	
				switch(bSW2)
				{
					case 0x00:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [EXECUTION ERROR: State of non-volatile memory unchanged (SW2 indicates: no information given]", false, bShowExecErrors); 
							return false;
						}
					default:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [EXECUTION ERROR (" + sSW12 + "):  State of non-volatile memory unchanged (SW2 indicates: unknown value! Cool!)]", false, bShowExecErrors); 
							return false;
						}
				}
			}

		case 0x65: // State of non-volatile memory changed
			{	
				switch(bSW2)
				{
					case 0x00:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [EXECUTION ERROR (" + sSW12 + "): State of non-volatile memory changed (SW2 indicates: no information given)]", false, bShowExecErrors); 
							return false;
						}
					case 0x81:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [EXECUTION ERROR (" + sSW12 + "): State of non-volatile memory changed (SW2 indicates: memory failure)]", false, bShowExecErrors); 
							return false;
						}
					default:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [EXECUTION ERROR (" + sSW12 + "): State of non-volatile memory changed (SW2 indicates: unknown value! Cool!)]", false, bShowExecErrors); 
							return false;
						}
				}
			}

		// ------ CHECKING ERROR RESPONSES -------


		case 0x67: // Wrong length
			{	
				if (bWriteLog) theApp.dlg.WriteToLog("   CHECKING ERROR: Wrong length (change P3/Lc)]", false, bShowCheckErrors); 
				return false;
			}

		case 0x68: // Functions in CLA not supported
			{	
				switch(bSW2)
				{
					case 0x00:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Functions in CLA not supported (SW2 indicates: no information given)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x81:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Functions in CLA not supported (SW2 indicates: logical channel not supported)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x82:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Functions in CLA not supported (SW2 indicates: secure messaging not supported)]", false, bShowCheckErrors); 
							return false;
						}
					default:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Functions in CLA not supported (SW2 indicates: unknown value! Cool!)]", false, bShowCheckErrors); 
							return false;
						}
				}
			}

		case 0x69: // Command not allowed
			{	
				switch(bSW2)
				{
					case 0x00:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Command not allowed (SW2 indicates: no information given)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x81:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Command not allowed (SW2 indicates: command incompatible with file structure)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x82:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Command not allowed (SW2 indicates: security status not satisfied)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x83:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Command not allowed (SW2 indicates: authentication method blocked)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x84:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Command not allowed (SW2 indicates: referenced data invalidated)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x85:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Command not allowed (SW2 indicates: conditions of use not satisfied)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x86:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Command not allowed (SW2 indicates: command not allowed (no current EF))]", false, bShowCheckErrors); 
							return false;
						}
					case 0x87:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Command not allowed (SW2 indicates: expected SM data objects missing)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x88:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Command not allowed (SW2 indicates: SM data objects incorrect)]", false, bShowCheckErrors); 
							return false;
						}
					default:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Command not allowed (SW2 indicates: unknown value! Cool!)]", false, bShowCheckErrors); 
							return false;
						}
				}
			}

		case 0x6A: // Wrong parameter(s) P1-P2
			{	
				switch(bSW2)
				{
					case 0x00:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Wrong parameter(s) P1-P2 (SW2 indicates: no information given)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x81:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Wrong parameter(s) P1-P2 (SW2 indicates: function not supported)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x82:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Wrong parameter(s) P1-P2 (SW2 indicates: file not found)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x83:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Wrong parameter(s) P1-P2 (SW2 indicates: record not found)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x84:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Wrong parameter(s) P1-P2 (SW2 indicates: not enough memory space in the file)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x85:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Wrong parameter(s) P1-P2 (SW2 indicates: Lc inconsistent with TLV structure)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x86:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Wrong parameter(s) P1-P2 (SW2 indicates: incorrect parameters P1-P2)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x87:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Wrong parameter(s) P1-P2 (SW2 indicates: Lc inconsistent with P1-P2)]", false, bShowCheckErrors); 
							return false;
						}
					case 0x88:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Wrong parameter(s) P1-P2 (SW2 indicates: referenced data not found)]", false, bShowCheckErrors); 
							return false;
						}
					default:
						{
							if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Wrong parameter(s) P1-P2 (SW2 indicates: unknown value! Cool!)]", false, bShowCheckErrors); 
							return false;
						}
				}
			}

		case 0x6B: // Wrong parameter(s) P1-P2
			{	
				if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Wrong parameter(s) P1-P2]", false, bShowCheckErrors); 
				return false;
			}

		case 0x6C: // Wrong length Le: SW2 indicates the exact length 
			{	
				if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Wrong length Le: SW2 indicates the exact length]", false, bShowCheckErrors); 
				return false;
			}

		case 0x6D: // Wrong length Le: SW2 indicates the exact length 
			{	
				if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Instruction code not supported or invalid]", false, bShowCheckErrors); 
				return false;
			}

		case 0x6E: // Class not supported
			{	
				if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): Class not supported]", false, bShowCheckErrors); 
				return false;
			}

		case 0x6F: // No precise diagnosis
			{	
				if (bWriteLog) theApp.dlg.WriteToLog(" --> [CHECKING ERROR (" + sSW12 + "): No precise diagnosis]", false, bShowCheckErrors); 
				return false;
			}

		// ------ (UNHANDLED RESPONSES) -------
		default:
			{
				if (bWriteLog) theApp.dlg.WriteToLog(" --> [ERROR (" + sSW12 + "): unexpected, unhandled response APDU!]", false, bShowUnhandled); 
				return false;
			}
	}

}

