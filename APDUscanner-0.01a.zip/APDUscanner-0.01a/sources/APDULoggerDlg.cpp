// APDULoggerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "APDUScanner.h"
#include "APDULoggerDlg.h"
#include ".\apduloggerdlg.h"
#include "scbase.h"


// CAPDULoggerDlg dialog

IMPLEMENT_DYNAMIC(CAPDULoggerDlg, CDialog)
CAPDULoggerDlg::CAPDULoggerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAPDULoggerDlg::IDD, pParent)
{
}

CAPDULoggerDlg::~CAPDULoggerDlg()
{
}

void CAPDULoggerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BTNCONNECT, c_btnConnect);
}


BEGIN_MESSAGE_MAP(CAPDULoggerDlg, CDialog)
	ON_BN_CLICKED(IDC_BTNCONNECT, OnBnClickedBtnconnect)
END_MESSAGE_MAP()


// CAPDULoggerDlg message handlers

void CAPDULoggerDlg::OnBnClickedBtnconnect()
{
	//CSCBase(dlg->resetEvent,dlg->readEvent);
	// TODO: Add your control notification handler code here
}
