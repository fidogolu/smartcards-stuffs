#pragma once

#include "APDUScanner.h"
#include "APDUScannerDlg.h"

#include "smartcard.h"

class CSimcardGSM : public CSmartCard
{
public:
	CSimcardGSM(void);
	~CSimcardGSM(void);
	void SELECT(byte *pbStatusSW12, byte bFileID[2], bool bSuppressOutput=false);
	void GET_RESPONSE(byte *pbStatusSW12, byte *pbResponse, byte bReadLn, bool bSuppressOutput=false);
	void READ_BINARY(byte *pbStatusSW12, byte *pbResponse, byte bReadLn, byte bOffsetMSB, byte bOffsetLSB, bool bSuppressOutput=false);
	void READ_RECORD(byte *pbStatusSW12, byte *pbResponse, byte bReadLn, byte bRecordNr, byte bMode, bool bSuppressOutput=false);
	void UPDATE_BINARY(byte *pbStatusSW12, byte *pbNewData, BYTE bWriteLn, byte bOffsetMSB, byte bOffsetLSB, bool bSuppressOutput=false);
	void UPDATE_RECORD(byte *pbStatusSW12, byte *pbNewData, BYTE bWriteLn, byte bRecordNr, byte bMode, bool bSuppressOutput=false);
	void VERIFY_CHV(byte *pbStatusSW12, byte bCHVno, byte bPINcode[8], bool bSuppressOutput=false);
	void UNBLOCK_CHV(byte *pbStatusSW12, byte bCHVno, byte bUnblockCHV[8], byte bNewCHV[8], bool bSuppressOutput=false);
	void ENABLE_CHV(byte *pbStatusSW12, byte bNewCHV1[8], bool bSuppressOutput=false);
	void DISABLE_CHV(byte *pbStatusSW12, byte bCurrentCHV1[8], bool bSuppressOutput=false);

	// void DumpInfo();
	// void DumpInfo_ReadSelectedFile();	
	static void DumpInfo();
	static void DumpInfo_ReadSelectedFile(byte *pbResponse, byte bResponseLn); //(byte bStructureType, int iFileSize)
	static void DumpInfo_ReadAndDecodeSMS(byte *pbResponse, byte bResponseLn);
	static void DumpInfo_ReadAndDecodeADN(byte *pbResponse, byte bResponseLn);
	static CString DumpInfo_DecodeCHVStatusByte(byte bStatusByte);
	static UINT DumperThread(LPVOID param);
};
