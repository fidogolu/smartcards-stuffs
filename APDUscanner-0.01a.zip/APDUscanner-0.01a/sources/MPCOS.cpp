/*
* Copyright (c) 2006, Matthijs Koot (matthijs at koot.biz)
* All rights reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the Koot Organization nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================

  MPCOS.CPP

  License     : BSD-style (yep, just sell it!)
  Author      : Matthijs Koot (matthijs at koot.biz)
  Description : This CMPCOS class defines behavior for MPCOS-based cards.

  History :
     2007-12-29, mrkoot: file created
     2007-12-30, mrkoot: added CREATE_FILE

  Remarks :
    - none

===============================================================================*/

#pragma once
#include "StdAfx.h"

#include "APDUScanner.h"
#include "APDUScannerDlg.h"

#include "mpcos.h"


CMPCOS::CMPCOS(void)
{
}

CMPCOS::~CMPCOS(void)
{
}

void CMPCOS::SELECT_FILE(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bType, byte bFileID[2], bool bResponse, bool bSuppressOutput)
{
  //-------
  // SELECT_FILE command APDU (MPCOS-based cards):
  //
  // CLA  = 0x00 (fixed)
  // INS  = 0xA4 
  // P1   = 0x00 --> Implicitly selects the Master File (MF) or an Elementary File (EF) using the Short File Identifier
  //        0x01 --> Selects a Dedicated File (DF) when the MF is selected
  //        0x02 --> Selects an EF under the currently selected DF
  //        0x03 --> Select the parent DF to the currently selected EF or MF if already at DF level
  //        0x04 --> Selects a DF by its name (this is the name held in the DF body)
  // P2   = 0x00 (no response), 0x0c (response)
  // P3   = 0x00 
  // Data = File ID (2 bytes)
  //
  // Known File IDs:
  //   - MPCOS MF is at 0x3F00
  //   - MPCOS keyfile is at 0x3F01
  //	
  // Preconditions: 
  //   1. none
  //-------
	
	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = 0x00; // CLA = instruction class field 
	cmd.bIns = 0xA4; // INS = instruction code 
	cmd.bP1  = bType; // P1  = parameter 1 
	cmd.bP2  = bResponse?0x00:0x0c; // P2  = parameter 2 
	cmd.bP3  = 0x02; // P3  = Le (expected size of IO transfer)
	memcpy(bSend, &cmd, sizeof(cmd));

	bSend[5] = bFileID[0];
	bSend[6] = bFileID[1];

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND) + cmd.bP3; // CLA/INS/P1/P2/P3 is followed by <cmd.bP3> extra command bytes */
	DWORD dwRecvLength = 2;	// we'll only receive 2 status bytes, e.g. 0x9000

	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{		
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response data = (n/a)");

	// At this point, bRecv should contain 0x9... (=status OK)
	// If the high nibble equals "6", it's likely that an error occured

	// copy response APDU to buffer
	memcpy(pbResponseAPDU, &bRecv, dwExpectedResponseLn);

	/*if (!(bRecv[0] & 0x60)) //0x60 = "6" as left nibble would indicate a failure
	{
		theApp.dlg.WriteToLog("!!! ERROR)");
  		// disconnect card
		CardDisconnect();
		return;
	}*/
}




void CMPCOS::SELECT_FILE(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, char* pcFileName, bool bResponse, bool bSuppressOutput)
{
  //-------
  // SELECT_FILE command APDU (MPCOS-based cards):
  //
  // CLA  = 0x00 (fixed)
  // INS  = 0xA4 
  // P1   = 0x00 --> Implicitly selects the Master File (MF) or an Elementary File (EF) using the Short File Identifier
  //        0x01 --> Selects a Dedicated File (DF) when the MF is selected
  //        0x02 --> Selects an EF under the currently selected DF
  //        0x03 --> Select the parent DF to the currently selected EF or MF if already at DF level
  //        0x04 --> Selects a DF by its name (this is the name held in the DF body)
  // P2   = 0x00 (no response), 0x0c (response)
  // P3   = 0x00 
  // Data = File ID (2 bytes)
  //
  // Known File IDs:
  //   - MPCOS MF is at 0x3F00
  //   - MPCOS keyfile is at 0x3F01
  //	
  // Preconditions: 
  //   1. none
  //-------
	
	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = 0x00; // CLA = instruction class field 
	cmd.bIns = 0xA4; // INS = instruction code 
	cmd.bP1  = 0x04; // P1  = parameter 1 
	cmd.bP2  = bResponse?0x00:0x0c; // P2  = parameter 2 
	cmd.bP3  = (byte)strlen(pcFileName); // P3  = Le (expected size of IO transfer)
	memcpy(bSend, &cmd, sizeof(cmd));

	//if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(cmd.bP3, bSend, true) + "}");

	memcpy(bSend+5, pcFileName, strlen(pcFileName));

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND) + cmd.bP3; // CLA/INS/P1/P2/P3 is followed by <cmd.bP3> extra command bytes */
	DWORD dwRecvLength = 2;	// we'll only receive 2 status bytes, e.g. 0x9000

	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{		
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response data = (n/a)");

	// At this point, bRecv should contain 0x9... (=status OK)
	// If the high nibble equals "6", it's likely that an error occured

	// copy response APDU to buffer
	memcpy(pbResponseAPDU, &bRecv, dwExpectedResponseLn);

	/*if (!(bRecv[0] & 0x60)) //0x60 = "6" as left nibble would indicate a failure
	{
		theApp.dlg.WriteToLog("!!! ERROR)");
  		// disconnect card
		CardDisconnect();
		return;
	}*/
}




void CMPCOS::READ_RECORD(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bRecordNr, byte bRefControl, byte pLcRecv, bool bSuppressOutput)
{
  //-------
  // READ_RECORD command APDU (MPCOS-based cards):
  //
  // CLA = 
  // INS = 
  // P1  = 
  // P2  = 
  // P3  = 
  //
  // Preconditions: 
  //   1. 
  //-------

  // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3}  
}


void CMPCOS::READ_DATA(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bOffsetMSB, byte bOffsetLSB, byte bLcRecv, bool bSuppressOutput)
{ 
  //-------
  // READ_DATA command APDU (MPCOS-based cards):
  //
  // CLA = 0x00 (normal), 0x04 (secure)
  // INS = 0xB0 
  // P1  = MSB of relative address in EF (offset), e.g. 0x00
  // P2  = LSB of relative address in EF (offset), e.g. 0x00
  // P3  = number of bytes to read (size of IO transfer, Lc)
  //
  // Preconditions: 
  //   1. some EF must have been selected (SELECT_EF)
  //-------

  // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3}  

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd2;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd2.bCla = 0x00; // CLA = instruction class field
	cmd2.bIns = 0xB0; // INS = instruction code
	cmd2.bP1  = bOffsetMSB; // P1  = parameter 1 
	cmd2.bP2  = bOffsetLSB; // P2  = parameter 2
	cmd2.bP3  = bLcRecv; // P3  = Le (expected size of IO transfer)
	memcpy(bSend, &cmd2, sizeof(cmd2));

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND);
	DWORD dwRecvLength = cmd2.bP3 + 2; // Lc + 2 status bytes

	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) 
	{
		theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
		theApp.dlg.WriteToLog("  Response data (hex) = {" + theApp.dlg.ConvertBytesToHexString(dwRecvLength-2, &bRecv[0], true) + "}");
		CString sContents;
		for (UINT i=0; i < (dwRecvLength - 2); i++)
		if (bRecv[i] != 0x00)
			sContents.AppendChar(bRecv[i]);
		theApp.dlg.WriteToLog("  Response data (ASCII) = {" + sContents + "}");
	}
	
	// copy response APDU to buffer
	memcpy(pbResponseAPDU, &bRecv, dwExpectedResponseLn);
}

void CMPCOS::UPDATE_BINARY(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bOffsetMSB, byte bOffsetLSB, byte bLcSend, byte *pbNewData, byte *pbKats=NULL, bool bSuppressOutput)
{
	// TBD
	theApp.dlg.WriteToLog("I'm sorry, CMPCOS::UPDATE_BINARY() has not yet been implemented!");
}

void CMPCOS::SELECT_FILE_KEY(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, BYTE bKn, BYTE bKf, byte *pbRandom, bool bSuppressOutput)
{
  //-------
  // SELECT_FILE_KEY command APDU (MPCOS-based cards):
  //
  // CLA = 0x80
  // INS = 0x28 
  // P1  = Kn 
  // P2  = Kf
  // P3  = 0x08
  // Data = 8 bytes
  //
  //-------

  // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3} 

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd2;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd2.bCla = 0x80; // CLA = instruction class field
	cmd2.bIns = 0x28; // INS = instruction code
	cmd2.bP1  = bKn; // P1  = parameter 1 
	cmd2.bP2  = bKf; // P2  = parameter 2
	cmd2.bP3  = 8; // P3  = Le (expected size of IO transfer)

	memcpy(bSend, &cmd2, sizeof(cmd2));
	memcpy(bSend + sizeof(cmd2), pbRandom, 8 );

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND) + 0x08;
	DWORD dwRecvLength = 2; // Only 2 status bytes
	
	//theApp.dlg.WriteToLog("  bLc= {" + theApp.dlg.ConvertBytesToHexString(1, &bLc, true) + "}");
	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) 
	{
		theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
		theApp.dlg.WriteToLog("  Response data = n/a");
	}

	// copy response APDU to buffer
	memcpy(pbResponseAPDU, &bRecv, dwExpectedResponseLn);
}

void CMPCOS::CREATE_FILE(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, BYTE bFileType, BYTE bNameLn, BYTE *pbName, BYTE *pbKey, bool bSuppressOutput)
{
	// TBD
	theApp.dlg.WriteToLog("I'm sorry, CMPCOS::CREATE_FILE() has not yet been implemented!");
}

void CMPCOS::GET_RESPONSE(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, BYTE bReadLn, bool bSuppressOutput)
{
  //-------
  // GET_RESPONSE command APDU (MPCOS-based cards):
  //
  // CLA = 0x00
  // INS = 0xC0 
  // P1  = 0x00
  // P2  = 0x00
  // P3  = number of bytes to read (as indicated by a previous command)
  //
  //-------

  // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3} 

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd2;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd2.bCla = 0x00; // CLA = instruction class field
	cmd2.bIns = 0xC0; // INS = instruction code
	cmd2.bP1  = 0x00; // P1  = parameter 1 
	cmd2.bP2  = 0x00; // P2  = parameter 2
	cmd2.bP3  = bReadLn; // P3  = Le (expected size of IO transfer)

	memcpy(bSend, &cmd2, sizeof(cmd2));
	
	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND);
	DWORD dwRecvLength = bReadLn + 2; // contents + 2 status bytes
	
	//theApp.dlg.WriteToLog("  bLc= {" + theApp.dlg.ConvertBytesToHexString(1, &bLc, true) + "}");
	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) 
	{
		theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
		theApp.dlg.WriteToLog("  Response data = n/a");
	}
	
	// copy response APDU to buffer
	memcpy(pbResponseAPDU, &bRecv, dwExpectedResponseLn);
}





