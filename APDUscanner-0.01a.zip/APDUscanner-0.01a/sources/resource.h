//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by APDUScanner.rc
//
#define IDR_MAINFRAME                   2
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_APDUSCANNER_DIALOG          102
#define IDD_APDUCONSOLE_DIALOG          103
#define IDD_APDULOGGER_DIALOG           133
#define IDC_PCSC                        1001
#define IDC_LOG                         1002
#define IDC_PIN_CHIPKNIP                1003
#define IDC_BTNSCAN                     1004
#define IDC_BTNSTOP                     1005
#define IDC_TXTPIN_CHIPKNIP             1007
#define IDC_BTNSENDAPDU                 1008
#define IDC_BTNFILESCANMPCOS            1009
#define IDC_BTNFILESCANCHIPKNIP         1010
#define IDC_BTNFILESCANSIMCARDGSM       1011
#define IDC_CHKFIXF1                    1012
#define IDC_CBD1                        1013
#define IDC_CBP3                        1014
#define IDC_DISCONNECT                  1015
#define IDC_TXTAPDU3                    1016
#define IDC_CBP1                        1017
#define IDC_CBINS                       1018
#define IDC_PIN_GSMSIM                  1019
#define IDC_LBLTITLE                    1021
#define IDC_BTNGETATR                   1022
#define IDC_BTNPAUSE                    1023
#define IDC_TXTCURRENT                  1024
#define IDC_BTNREADCHIPKNIP             1025
#define IDC_BTNREADSIM                  1026
#define IDC_CHKFIXCLA                   1027
#define IDC_CBCLA                       1028
#define IDC_CHKFIXD1                    1029
#define IDC_CHKFIXINS                   1030
#define IDC_BTNTEST                     1031
#define IDC_CHKFIXP1                    1032
#define IDC_BTNSAVE                     1033
#define IDC_CHKFIXP2                    1034
#define IDC_BTNRESET                    1035
#define IDC_CHKFIXP3                    1036
#define IDC_BTNTEST2                    1037
#define IDC_TXTAPDU                     1038
#define IDC_TXTPIN_GSMSIM               1039
#define IDC_BTNRECONNECT                1040
#define IDC_TXTAPDU2                    1041
#define IDC_BTNSENDAPDU2                1042
#define IDC_CBP2                        1043
#define IDC_BTNSENDAPDU3                1044
#define IDC_BTNAPDUCONSOLE              1045
#define IDC_LOGGER                      1046
#define IDC_SERIALSTRING                1047
#define IDC_BUTTON1                     1048
#define IDC_BTNCONNECT                  1049
#define IDC_CHKSCAND1                   1050
#define IDC_CHKSCAND2                   1051
#define IDC_CHKFIXD2                    1052
#define IDC_CBD2                        1053
#define IDC_WARNINGS                    1055
#define IDC_EXECERR                     1056
#define IDC_CHECKERR                    1057
#define IDC_CHECKERR2                   1058

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1050
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
