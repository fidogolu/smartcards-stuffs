#pragma once

#include "APDUScanner.h"
#include "APDUScannerDlg.h"

#include <winscard.h>   // used for smartcard connectivity

struct SW12
{
	BYTE bSW1;
	BYTE bSW2;
};

class CSmartCard
{
public:
	CSmartCard(void);
	~CSmartCard(void);

	long CardDisconnect();
    //BOOL CardPowerUp(BYTE *atr, LPDWORD n);
	BOOL CardPowerUp( BYTE *pbATR, LPDWORD n, DWORD *dwATRln );
	//BOOL PrepareCard( BOOL bVerboseLog, BYTE *pbRawATR);
	BOOL PrepareCard( BOOL bVerboseLog, BYTE *pbRawATR, DWORD *pdwATRlen);
	void handleSCardError(long lError, CString sFunction);
	BOOL ResponseIsOK(BYTE bSW1, BYTE bSW2, BOOL bWriteLog=true);

	int m_iNumReaders;                  // 0=no PC/SC readers found
	CString m_sSelectedReader;

	DWORD m_dwProtocol;
	SCARDCONTEXT m_hSCardContext;
	SCARDHANDLE m_hSCardHandle;
	DWORD m_dwProtocolT;

};
