// APDUconsoleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "APDUScanner.h"
#include "APDUconsoleDlg.h"
#include ".\apduconsoledlg.h"


//WARNING: you must replace 'A' with 'a' if you want CHAR_TO_HEX_DIGIT
// to work with lowercase (but it won't work for uppercase then; 
// you must choose one case to work with)
#define CHAR_TO_HEX_DIGIT(c)  (((c) >= '0' && (c) <= '9') ? (c) - '0' : (c) - 'A' + 10)

// CAPDUConsoleDlg dialog

IMPLEMENT_DYNAMIC(CAPDUConsoleDlg, CDialog)
CAPDUConsoleDlg::CAPDUConsoleDlg(CWnd* pParent /*=NULL*/, CSmartCard *m_pSmartCardMAIN )
	: CDialog(CAPDUConsoleDlg::IDD, pParent)
{	
	m_pSmartCard = m_pSmartCardMAIN;
}

CAPDUConsoleDlg::~CAPDUConsoleDlg()
{
}


void CAPDUConsoleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BTNSENDAPDU, c_btnSendAPDU);
	DDX_Control(pDX, IDC_TXTAPDU, c_txtSendAPDU);
	DDX_Control(pDX, IDC_LOG, c_txtOutput);
	DDX_Control(pDX, IDC_BTNSENDAPDU2, c_btnSendAPDU2);
	DDX_Control(pDX, IDC_BTNSENDAPDU3, c_btnSendAPDU3);
	DDX_Control(pDX, IDC_TXTAPDU2, c_txtSendAPDU2);
	DDX_Control(pDX, IDC_TXTAPDU3, c_txtSendAPDU3);
}


BEGIN_MESSAGE_MAP(CAPDUConsoleDlg, CDialog)
	ON_BN_CLICKED(IDC_BTNSENDAPDU, OnBnClickedBtnsendapdu)
	ON_BN_CLICKED(IDCANCEL, OnBnClickedCancel)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_EN_CHANGE(IDC_TXTAPDU, OnEnChangeTxtapdu)
	ON_WM_SHOWWINDOW()
	ON_BN_CLICKED(IDC_BTNRECONNECT, OnBnClickedBtnreconnect)
	ON_BN_CLICKED(IDC_BTNSENDAPDU2, OnBnClickedBtnsendapdu2)
	ON_BN_CLICKED(IDC_BTNSENDAPDU3, OnBnClickedBtnsendapdu3)
	ON_EN_CHANGE(IDC_TXTAPDU2, OnEnChangeTxtapdu2)
	ON_EN_CHANGE(IDC_TXTAPDU3, OnEnChangeTxtapdu3)
	ON_EN_SETFOCUS(IDC_TXTAPDU, OnEnSetfocusTxtapdu)
	ON_EN_SETFOCUS(IDC_TXTAPDU2, OnEnSetfocusTxtapdu2)
	ON_EN_SETFOCUS(IDC_TXTAPDU3, OnEnSetfocusTxtapdu3)
END_MESSAGE_MAP()


// CAPDUConsoleDlg message handlers

void CAPDUConsoleDlg::OnBnClickedBtnsendapdu()
{	
	CString sAPDU;
	c_txtSendAPDU.GetWindowText(sAPDU);
	SendAPDU(sAPDU);
}

void CAPDUConsoleDlg::SendAPDU(CString sCommandAPDU, byte *pbSW12)
{
	SCARD_IO_REQUEST ioRecvPci;							// create IO buffer
	ioRecvPci.dwProtocol = SCARD_PROTOCOL_T0;			// fixed 
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	DWORD dwSendLength = 0;			// size of the command APDU
	DWORD dwRecvLength = 0;			// size of the response APDU

	long lReturn;				// some Smartcard SDK return code

	SCARD_T0_COMMAND cmd;

	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));


	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = (  CHAR_TO_HEX_DIGIT(sCommandAPDU[0]) << 4)	/* low nibble */
				+ CHAR_TO_HEX_DIGIT(sCommandAPDU[1]) ;		/* high nibble */
	cmd.bIns = (  CHAR_TO_HEX_DIGIT(sCommandAPDU[3]) << 4)	/* low nibble */
				+ CHAR_TO_HEX_DIGIT(sCommandAPDU[4]) ;		/* high nibble */
	cmd.bP1  = (  CHAR_TO_HEX_DIGIT(sCommandAPDU[6]) << 4)	/* low nibble */
				+ CHAR_TO_HEX_DIGIT(sCommandAPDU[7]) ;		/* high nibble */
	cmd.bP2  = (  CHAR_TO_HEX_DIGIT(sCommandAPDU[9]) << 4)	/* low nibble */
				+ CHAR_TO_HEX_DIGIT(sCommandAPDU[10]) ;		/* high nibble */
	cmd.bP3  = (  CHAR_TO_HEX_DIGIT(sCommandAPDU[12]) << 4)	/* low nibble */
				+ CHAR_TO_HEX_DIGIT(sCommandAPDU[13]) ;		/* high nibble */

	memcpy(bSend, &cmd, sizeof(cmd));

	int iDataLn = (sCommandAPDU.GetLength() - 14) / 3;

	
	for (int i=0; i<iDataLn; i++)
	{
		bSend[5+i] = (  CHAR_TO_HEX_DIGIT(sCommandAPDU[15+(i*3)]) << 4)	/* low nibble */
					+ CHAR_TO_HEX_DIGIT(sCommandAPDU[15+(i*3)+1]) ;		/* high nibble */
	}

	dwSendLength = sizeof(SCARD_T0_COMMAND) + iDataLn;
	dwRecvLength = cmd.bP3 + 2; //256;

	WriteToConsole("Command APDU={" + CAPDUScannerDlg::ConvertBytesToHexString(dwSendLength, pbSend, true) + "}");
	lReturn = SCardTransmit( m_pSmartCard->m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	CString sResponseAPDU = CAPDUScannerDlg::ConvertBytesToHexString(dwRecvLength, pbRecv, true);
	if (lReturn != SCARD_S_SUCCESS)
	{		
		m_pSmartCard->handleSCardError(lReturn, "SCardTransmit");
		WriteToConsole("Response APDU= ERROR OCCURRED (see main dialog)");
	}
	else
	{
		//WriteToConsole("Response APDU={" + CAPDUScannerDlg::ConvertBytesToHexString(dwRecvLength, pbRecv, true) + "}");
		WriteToConsole("Response APDU={" + sResponseAPDU + "}");
		
		if (dwRecvLength > 2)
		{
			CString sContents;
			for (UINT i=0; i < (dwRecvLength - 2); i++)
			if (bRecv[i] != 0x00)
				sContents.AppendChar(bRecv[i]);
			WriteToConsole("Response data (ASCII) = {" + sContents + "}");
		}
	}

	// Return the SW12 status bytes
	if (pbSW12)
	  memcpy(pbSW12, &bRecv[dwRecvLength - 2], 2);
}


void CAPDUConsoleDlg::WriteToConsole( LPCTSTR pszMessage, BOOL bSameLine )
{
	CString sOld;
	c_txtOutput.GetWindowText(sOld);	

	if (sOld.GetLength()!=0 && !bSameLine)
		sOld.Insert(sOld.GetLength(), "\r\n");
	sOld.Insert(sOld.GetLength(), pszMessage);
	
	int iLength = c_txtOutput.GetLineCount();
	int iMaxLines = 200;
	if (iLength > iMaxLines)
	{
		int iStart = 0,	iEnd = 0;
		int iCount = 0;
		int iPos = 0;
		for (iCount=0; iCount<=100; iCount++)
			iEnd = sOld.Find("\r\n", iPos++);

		sOld.Delete(iStart, iEnd);
	}

	c_txtOutput.SetWindowText(sOld);
	c_txtOutput.LineScroll(c_txtOutput.GetLineCount(),0);
}

void CAPDUConsoleDlg::OnBnClickedCancel()
{
    m_pSmartCard->CardDisconnect();
	OnCancel();
}

void CAPDUConsoleDlg::OnBnClickedOk()
{
    m_pSmartCard->CardDisconnect();
	OnOK();
}

void CAPDUConsoleDlg::OnEnChangeTxtapdu()
{
	if (c_txtSendAPDU.GetWindowTextLength() > 0)
		c_btnSendAPDU.EnableWindow(true);
	else
		c_btnSendAPDU.EnableWindow(false);
}

void CAPDUConsoleDlg::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CDialog::OnShowWindow(bShow, nStatus);

	BYTE bRawATR[60];
	DWORD dwATRlen=0;
    ZeroMemory( bRawATR, 60 );
	if (!m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen ))
		WriteToConsole("-------> Error: could not prepare card (try reinsert card, or restart APDUscanner?)");
	else
	{
		WriteToConsole("-------> Succesfully (re)connected!");
		WriteToConsole( "Answer-To-Reset: " );
		WriteToConsole( CAPDUScannerDlg::ConvertBytesToHexString( dwATRlen, bRawATR, true ), true );
	}

	c_txtSendAPDU.SetFocus();
}

void CAPDUConsoleDlg::OnBnClickedBtnreconnect()
{
	if (!m_pSmartCard->CardDisconnect())
		WriteToConsole("-------> Warning: could not disconnect (perhaps the card was disconnected already)");

	BYTE bRawATR[60];
	DWORD dwATRlen=0;
    ZeroMemory( bRawATR, 60 );
	if (!m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen ))
		WriteToConsole("-------> Error: could not prepare card (try reinsert card, or restart APDUscanner?)");
	else
	{
		WriteToConsole("-------> Succesfully (re)connected!");
		WriteToConsole( "Answer-To-Reset: " );
		WriteToConsole( CAPDUScannerDlg::ConvertBytesToHexString( dwATRlen, bRawATR, true ), true );
	}


}

void CAPDUConsoleDlg::OnBnClickedBtnsendapdu2()
{
	CString sAPDU2;
	c_txtSendAPDU2.GetWindowText(sAPDU2);
	SendAPDU(sAPDU2);
}

void CAPDUConsoleDlg::OnBnClickedBtnsendapdu3()
{
	CString sAPDU3;
	c_txtSendAPDU3.GetWindowText(sAPDU3);
	SendAPDU(sAPDU3);
}

void CAPDUConsoleDlg::OnEnChangeTxtapdu2()
{
	if (c_txtSendAPDU2.GetWindowTextLength() > 0)
		c_btnSendAPDU2.EnableWindow(true);
	else
		c_btnSendAPDU2.EnableWindow(false);
}

void CAPDUConsoleDlg::OnEnChangeTxtapdu3()
{
	if (c_txtSendAPDU3.GetWindowTextLength() > 0)
		c_btnSendAPDU3.EnableWindow(true);
	else
		c_btnSendAPDU3.EnableWindow(false);
}

void CAPDUConsoleDlg::OnEnSetfocusTxtapdu()
{
	SendMessage( DM_SETDEFID, IDC_BTNSENDAPDU, 0);
}

void CAPDUConsoleDlg::OnEnSetfocusTxtapdu2()
{
	SendMessage( DM_SETDEFID, IDC_BTNSENDAPDU2, 0);
}

void CAPDUConsoleDlg::OnEnSetfocusTxtapdu3()
{
	SendMessage( DM_SETDEFID, IDC_BTNSENDAPDU3, 0);
}
