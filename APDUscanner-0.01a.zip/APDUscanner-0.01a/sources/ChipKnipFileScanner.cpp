/*
* Copyright (c) 2006, Matthijs Koot (matthijs at koot.biz)
* All rights reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the Koot Organization nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================

  CHIPKNIPFILESCANNER.CPP

  License     : BSD-style (yep, just sell it!)
  Author      : Matthijs Koot (matthijs at koot.biz)
  Description : This CChipknipFileScanner class defines behavior for scanning
                Chipknip (Proton) cards for MF/DF/EFs.

  History :
     2007-12-29, mrkoot: file created

  Remarks :
    - none

===============================================================================*/
#include "StdAfx.h"
#include ".\chipknipfilescanner.h"

CChipknipFileScanner::CChipknipFileScanner(void)
{
}

CChipknipFileScanner::~CChipknipFileScanner(void)
{
}


/*---------------------------------------------------------------------
  Name   : FileScannerThread()
  Param  : (LPVOID) param
  Pre    : -
  Post   : -
  Return : 0

  Description:
    This is the actual code for EF/DF scanning.
---------------------------------------------------------------------*/
UINT CChipknipFileScanner::FileScannerThread(LPVOID param)  // defines what our threads actually do
{
//    THREADSTRUCT *ts = (THREADSTRUCT*)param;
    theApp.dlg.m_bFileScannerThreadIsRunning = true;

    BYTE bRawATR[60];
	DWORD dwATRlen = 0;
    ZeroMemory( bRawATR, 60 );

	if (!theApp.dlg.m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen ))
    {
        theApp.dlg.m_pSmartCard->CardDisconnect();
		theApp.dlg.OnBnClickedBtnstop();
		TerminateThread(GetCurrentThread(), -1);
        return -1; // never reached due to TerminateThread
    }
    theApp.dlg.WriteToLog( "Answer-To-Reset: " + theApp.dlg.ConvertBytesToHexString( dwATRlen, bRawATR, true ) + "\r\n", true );
	
	// Scan through all possible D1/D2 values to find files
	// TODO: this SHOULD take MF-DF-EF hierarchy into account (currently doesn't)
	//       (e.g. scan for DF
	int iMSB=0,iLSB=0;
	for (iMSB = 0; iMSB <= 255; iMSB++)
	{	
		for (iLSB = 0; iLSB <= 255; iLSB++)
		{
			if (theApp.dlg.m_bFileScannerThreadIsRunning == false)
			{
				theApp.dlg.m_pSmartCard->CardDisconnect();
				TerminateThread(GetCurrentThread(), 0);
			}
		
			char dateStr [9];
			char timeStr [9];
			_strdate(dateStr);
			_strtime(timeStr);

			// Attempt SELECT_EF
			BYTE bC_ICC_FILE_ID[2] = {intToByte(iMSB), intToByte(iLSB)}; 
			BYTE bResponseAPDU[2];
			ZeroMemory(bResponseAPDU, sizeof(bResponseAPDU));
			BYTE *pbResponseAPDU = bResponseAPDU;

			theApp.dlg.c_txtCurrentAPDU.SetWindowText("Attempting to select file at 0x" + theApp.dlg.ConvertBytesToHexString(2, bC_ICC_FILE_ID, false) + " ... ");
			//theApp.dlg.WriteToLog("Attempting to select file at " + theApp.dlg.ConvertBytesToHexString(2, bC_ICC_FILE_ID, false) + " ... ");
			((CChipknip*)theApp.dlg.m_pSmartCard)->SELECT_EF(pbResponseAPDU, sizeof(bResponseAPDU), bC_ICC_FILE_ID, false, true);

			if ((bResponseAPDU[0] & 0x90) && !(bResponseAPDU[1] & 0x08))
			{ // Attempt READ_DATA

				theApp.dlg.WriteToLog("-- FILE FOUND AT 0x" + theApp.dlg.ConvertBytesToHexString(2, bC_ICC_FILE_ID, false) + "! (on " + CString(dateStr) + " at " + CString(timeStr) + ")");

                const BYTE bLc2 = 255; // read as much bytes as possible
				BYTE bResponseAPDU2[bLc2 + 2];
				ZeroMemory(bResponseAPDU2, sizeof(bResponseAPDU2));
				BYTE *pbResponseAPDU2 = bResponseAPDU2;

				theApp.dlg.WriteToLog("Reading data... ");		
				((CChipknip*)theApp.dlg.m_pSmartCard)->READ_DATA(pbResponseAPDU2, sizeof(bResponseAPDU2), 0x00, 0x00, bLc2);

				byte bOffsetMSB = 0x00;
				byte bOffsetLSB = 0x00;
				while (bResponseAPDU2[0] == 0x61)
				{
					bOffsetLSB += bResponseAPDU2[1]; // THIS MUST BE FIXED (will overflow)
					theApp.dlg.WriteToLog("Reading more data... ");	
					((CChipknip*)theApp.dlg.m_pSmartCard)->READ_DATA(pbResponseAPDU2, sizeof(bResponseAPDU2), bOffsetMSB, bOffsetLSB, bResponseAPDU2[1]); 
				}
			}
			else if ((bResponseAPDU[0] & 0x90) && (bResponseAPDU[1] & 0x08))
			{ // File not found 
				//theApp.dlg.WriteToLog("file not found.", true);
			}
			else if ((bResponseAPDU[0] == 0x00) && (bResponseAPDU[1] == 0x00))
			{ // Fuckup, reconnect
				//theApp.dlg.WriteToLog("file not found.", true);
				//theApp.dlg.m_pSmartCard->CardDisconnect();
				//theApp.dlg.m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen );
			}
			else
				theApp.dlg.WriteToLog("-- Unknown response for SELECT_EF(0x" + theApp.dlg.ConvertBytesToHexString(2, bC_ICC_FILE_ID, false) + ") on " + CString(dateStr) + " at " + CString(timeStr) + ": " + theApp.dlg.ConvertBytesToHexString(2, bResponseAPDU, false), false);

					
			if (theApp.dlg.c_chkReconnect.GetCheck()==1)
			{
				theApp.dlg.m_pSmartCard->CardDisconnect();
				theApp.dlg.m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen );
			}

		}
	}



    /*------
    clean up */

	theApp.dlg.m_pSmartCard->CardDisconnect();

	char dateStr [9];
    char timeStr [9];
    _strdate(dateStr);
    _strtime(timeStr);

    theApp.dlg.WriteToLog("------ Chipknip EF/DF scan completed on " + CString(dateStr) + " at " + CString(timeStr));
    theApp.dlg.WriteToLog("===========================================================");

	theApp.dlg.m_bFileScannerThreadIsRunning = false;

	// enable GUI
	theApp.dlg.ToggleGUI(false);

	CString sCurrentAPDU;
	theApp.dlg.c_txtCurrentAPDU.GetWindowText(sCurrentAPDU);
	theApp.dlg.c_txtCurrentAPDU.SetWindowText("");

	AfxEndThread(0);
    return 0;
}
