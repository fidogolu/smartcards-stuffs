#pragma once

#include "APDUScanner.h"
#include "APDUScannerDlg.h"

#include "SmartCard.h"

class CChipknip : public CSmartCard
{
public:
	CChipknip(void);
	~CChipknip(void);

	void DumpInfo();
	CString AnalyzePUR_TX_TYPE( BYTE bPUR_TX_TYPE );
	CString AnalyzePUR_TX_ERR( BYTE bPUR_TX_ERR );
	CString AnalyzeBalance( CString sBalance, CString sCurrency );
	CString AnalyzePUR_STATE (BYTE bPUR_STATE);

	// TB commands
	void SELECT_EF(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bFileID[2], bool bNext, bool bSuppressOutput=false);
	void READ_RECORD(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bRecordNr, byte bRefControl, byte pLn, bool bSuppressOutput=false);
	void READ_DATA(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bOffsetMSB, byte bOffsetLSB, byte bLc, bool bSuppressOutput=false);
	
	// EMV commands
    //void SELECT_MF(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bFileID[2]);

	// IEP commands
	void UPDATE_DATA(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bOffsetMSB, byte bOffsetLSB, byte bLc, byte *pbNewData, bool bSuppressOutput=false);
	void READ_TRACE(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, int iTraceCmd, byte bLc, CString *psPUR_CURCY, bool bSuppressOutput=false);
    void LOOK_UP_BALANCE(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bFileID[2], CString *psPUR_CURCY);
};
