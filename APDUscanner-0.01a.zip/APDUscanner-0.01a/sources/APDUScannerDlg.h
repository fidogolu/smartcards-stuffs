/*
* Copyright (c) 2006, Matthijs Koot (matthijs at koot.biz)
* All rights reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the Koot Organization nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================

  APDUSCANNERDLG.H

  License     : BSD-style (yep, just sell it!)
  Author      : Matthijs Koot (matthijs at koot.biz)
  Description : CAPDUScannerDlg specification.

  History :
     2006-04-13, mrkoot: file created
     2006-04-16, mrkoot: refurbished
	 2007-12-29, mrkoot: include ChipknipTinker.h

  Remarks :
    - none

*/

#pragma once
#include "afxwin.h"
#include "afxcmn.h"
#include "SmartCard.h"
#include "CommandScanner.h"
#include "MPCOSFileScanner.h"
#include "ChipknipFileScanner.h"
#include "ChipknipTinker.h"
#include "SimcardGSM.h"

#include <math.h>

#include "APDUconsoleDlg.h"

#include <iostream>  // read/write files
#include <fstream>   // read/write files
using namespace std;


static byte intToByte(int iNumber);

// Answer-To-Reset specification.
// See ISO7816 chapter 2.3.4
// See http://www.cozmanova.com/smartcard/atr.html
//
struct AnswerToReset 
{
    BYTE TS;        // mandatory; an initial character
    BYTE T0;        // mandatory; a formal character
    BYTE TA[5];     // optional interface character
    BYTE TB[5];     // optional interface character
    BYTE TC[5];     // optional interface character
    BYTE TD[5];     // optional interface character
    BYTE T[33];     // historical characters

    AnswerToReset( BYTE *pbRaw ) 
	{
        memset( this, 0, sizeof(AnswerToReset) );
        if (!pbRaw) return;
        TS = pbRaw[0];
        T0 = pbRaw[1];
        T[0] = T0 & 0x0F;

		// TBD: dissect other ATR-bytes
	}
};

// mask[] helper
static const long mask[] =
{
    0x00000001, 0x00000002, 0x00000004, 0x00000008,
    0x00000010, 0x00000020, 0x00000040, 0x00000080,
    0x00000100, 0x00000200, 0x00000400, 0x00000800,
    0x00001000, 0x00002000, 0x00004000, 0x00008000,
    0x00010000, 0x00020000, 0x00040000, 0x00080000,
    0x00100000, 0x00200000, 0x00400000, 0x00800000,
    0x01000000, 0x02000000, 0x04000000, 0x08000000,
    0x10000000, 0x20000000, 0x40000000, 0x80000000,
};

static CString ConvertByteToBinaryString(BYTE b)
{
	CString sBinary;
	for (int i=7; i>=0; i--)
		sBinary.AppendFormat("%c", (b & mask[i])?'1':'0');
	return sBinary;
};

static CString ConvertByteToBinaryString(BYTE* pbArray, int iLen)
{
	CString sBinary;
	if (!pbArray) return "Silly nullpointer!";

	for (int i=0; i<iLen; i++)
	{
		if (i > 0)
			sBinary.Append(" " + ConvertByteToBinaryString(pbArray[i]));
		else
  			sBinary.Append(ConvertByteToBinaryString(pbArray[i]));
	}
	return sBinary;
};


// CAPDUScannerDlg dialog
class CAPDUScannerDlg : public CDialog
{
// Construction
public:
    CAPDUScannerDlg(CWnd* pParent = NULL);   // standard constructor
    ~CAPDUScannerDlg();

// Dialog Data
	enum { IDD = IDD_APDUSCANNER_DIALOG };

    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
    HICON m_hIcon;

    // Generated message map functions
    virtual BOOL OnInitDialog();
    afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
    afx_msg void OnPaint();
    afx_msg HCURSOR OnQueryDragIcon();
    DECLARE_MESSAGE_MAP()
	BOOL PreTranslateMessage( MSG* pMsg );
public:
    BOOL ListPCSCReaders();
    void WriteToLog(LPCTSTR pszMessage, BOOL bSameLine=false, BOOL bShowOnGUI=true);
    static CString ConvertBytesToHexString(int iLength, BYTE * pbInput, BOOL bDivider=false);

	void ToggleGUI(const int iRequestedGUI);

    char m_cReadernames[4][80];         // array of reader names

	
	static const int GUI_DEFAULT = 0;
	static const int GUI_FOR_RUNNING_SCAN = 1;
	static const int GUI_FOR_NOREADERSFOUND = 2;

	CString m_sSettingsFile;
	CString m_sOutputFile;

	CSmartCard *m_pSmartCard;
	CAPDUConsoleDlg *m_pdlgAPDUconsole;

	ofstream m_ofsLog;
	ifstream m_ifsSettings;

	HANDLE m_hMutex;
	BOOL m_bAPDUScannerThreadIsRunning;
	BOOL m_bFileScannerThreadIsRunning;
	BOOL m_bChipknipTinkerThreadIsRunning;
	BOOL m_bGSMDumperThreadIsRunning;
	CWinThread *m_pwtCommandScanner;
	CWinThread *m_pwtFileScanner;
	CWinThread *m_pwtChipknipTinker;
	CWinThread *m_pwtDumpGSM;


	// Usage of saFixedBytes:
	// saFixedBytes["CLA"]["fixed"]=0x01 --> YES
	// saFixedBytes["CLA"]["fixed"]=0x00 --> NO  
	// saFixedBytes["CLA"]["value"]=0xBC --> MRU value

	CString sSettings; 

    //CLabel c_LblTitle;
    CEdit c_Log;
    CComboBox c_ComboUSBReaders;
    afx_msg void OnBnClickedBtngetatr();
	afx_msg void OnBnClickedBtnscan();
	afx_msg void OnBnClickedBtnpause();
	afx_msg void OnBnClickedBtnstop();
	CButton c_chkFixCLA;
	CButton c_chkFixINS;
	CButton c_chkFixP1;
	CButton c_chkFixP2;
	CButton c_chkFixP3;
	CButton c_btnGetATR;
	CButton c_btnScan;
	CButton c_btnPause;
	CButton c_btnStop;
	CEdit c_txtCurrentAPDU;
	CButton c_btnReset;
	CComboBox c_cbCLA;
	CComboBox c_cbINS;
	CComboBox c_cbP1;
	CComboBox c_cbP2;
	CComboBox c_cbP3;
	afx_msg void OnBnClickedChkfixcla();
	afx_msg void OnBnClickedChkfixins();
	afx_msg void OnBnClickedChkfixp1();
	afx_msg void OnBnClickedChkfixp2();
	afx_msg void OnBnClickedChkfixp3();
	afx_msg void OnBnClickedBtnreset();
	CButton c_btnReadChipknip;
	//afx_msg void OnBnClickedBtnchipknip();
	CButton c_btnSave;
	afx_msg void OnBnClickedBtnsave();
	CButton c_chkScanD1;
	CButton c_chkScanD2;
	CButton c_chkFixD1;
	CButton c_chkFixD2;
	CComboBox c_cbD1;
	CComboBox c_cbD2;
	afx_msg void OnBnClickedChkfixd1();
	afx_msg void OnBnClickedChkfixd2();
	afx_msg void OnBnClickedChkscand1();
	afx_msg void OnBnClickedChkscand2();
	afx_msg void OnCbnSelchangeCbcla();
	afx_msg void OnCbnSelchangeCbins();
	afx_msg void OnCbnSelchangeCbp1();
	afx_msg void OnCbnSelchangeCbp2();
	afx_msg void OnCbnSelchangeCbp3();
	afx_msg void OnCbnSelchangeCbd1();
	afx_msg void OnCbnSelchangeCbd2();
	afx_msg void OnBnClickedBtnfilescan();
	afx_msg void OnBnClickedBtntest();
	CButton c_chkShowWarnings;
	CButton c_chkShowExecErrors;
	CButton c_chkShowCheckErrors;
	afx_msg void OnBnClickedWarnings();
	afx_msg void OnBnClickedExecerr();
	afx_msg void OnBnClickedCheckerr();
	CButton c_chkReconnect;
	afx_msg void OnBnClickedDisconnect();
	afx_msg void OnCbnSelchangePcsc();
	CButton c_btnReadSIM;
	afx_msg void OnBnClickedBtnreadsim();
	afx_msg void OnBnClickedBtnreadchipknip();
	CButton c_btnFileScanMPCOS;
	CButton c_btnFileScanChipknip;
	CButton c_btnFileScanSimcardGSM;
	afx_msg void OnBnClickedBtnfilescanmpcos();
	afx_msg void OnBnClickedBtnfilescanchipknip();
	afx_msg void OnBnClickedBtnfilescansimcardgsm();
	afx_msg void OnBnClickedBtntest2();
	CButton c_btnSendAPDU;
	afx_msg void OnBnClickedBtnapduconsole();
	CButton c_btnAPDUConsole;
	CButton c_chkUsePIN_Chipknip;
	CButton c_chkUsePIN_GSMSIM;
	CEdit c_txtPIN_Chipknip;
	CEdit c_txtPIN_GSMSIM;
	afx_msg void OnBnClickedPinChipknip();
	afx_msg void OnBnClickedPinGsmsim();
	afx_msg void OnStnClickedLbltitle();
};

