
/*

NOTE: this file is borrowed from:
http://www.jstic.com/cypher/3Mac/index.htm

More specifically, from these ZIP-file:
http://www.jstic.com/cypher/3Mac/maclog_source.zip

The source is published with this comment:
"Do whatever you want with this source code, in any case 
I'm not reponsible for what you do with it"

*/


#if !defined(__SCBASE__)
#define __SCBASE__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CSCBase {
public:
	CSCBase(HANDLE,HANDLE);
	~CSCBase();
	DWORD Read(LPVOID,DWORD);
	DWORD Write(LPVOID,DWORD);

	int  Open(const char*);
	void SetConfig(const char*);
	void Close();
	void Disable();

	BYTE adapt(BYTE);
protected:
	HANDLE	stopEvent,hCom,thread,readyEvent,commEvent,stopCommEvent;
	HANDLE	resetEvent,readEvent,event1,event2;
	OVERLAPPED	overl,overl2,overl3;
	DWORD	dwEvtMask;


	static DWORD WINAPI LocalThread(LPVOID param);
	virtual void HandleReset();
	virtual void HandleRead();
};

#endif
