/*
* Copyright (c) 2006, Matthijs Koot (matthijs at koot.biz)
* All rights reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the Koot Organization nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================

  CHIPKNIP.CPP

  License     : BSD-style (yep, just sell it!)
  Author      : Matthijs Koot (matthijs at koot.biz)
  Description : This CChipknip class defines behavior for the Dutch 
                Proton-based payment card 'Chipknip'.

  History :
     2007-12-28, mrkoot: file created
     2008-05-24, mrkoot: removed obsolete WriteToLog() calls from SELECT_EF

  Remarks :
    - none

===============================================================================*/

#include "StdAfx.h"

#include "APDUScanner.h"
#include "APDUScannerDlg.h"

#include ".\chipknip.h"


// different trace operations (see READ_TRACE())
const int first_TX_TF   = 1;
const int first_TX_CBF  = 2;
const int first_TX_ITF  = 3;
const int next_TX_TF    = 4;
const int next_TX_CBF   = 5;
const int next_TX_ITF   = 6;

CChipknip::CChipknip(void)
{
}

CChipknip::~CChipknip(void)
{
}



void CChipknip::SELECT_EF(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bFileID[2], bool bNext, bool bSuppressOutput)
{
  //-------
  // SELECT_EF command APDU (Chipknip cards):
  //
  // CLA  = 0xBC ( %C_ICC_CLA_TB)
  // INS  = 0xA4 (%C_ICC_INS_SEL_EF / %C_ICC_INS_SEL_PSE)
  // P1   = 0x00 (%C_ICC_P1_NONE)
  // P2   = 0x00 (%C_ICC_P2_FIRST), 0x02 (%C_ICC_P2_NEXT)
  // P3   = 0x02 (%C_ICC_P3_SEL_EF)
  // Data = File ID (2 bytes)
  //
  // Known File IDs: 
  //   0x17FF (Fabrication file, %C_ICC_FILE_ID_FAB)
  //   0x2901 (purse file, %C_ICC_FILE_ID_PURSE)
  //	
  // Preconditions: 
  //   1. none
  //-------
	
	// Command APDU:  {CLA}  {INS} {P1}  {P2}  {P3} 
	//BYTE bcAPDU1[] = { 0xBC, 0xA4, 0x00, 0x00, 0x02, bFileID[0], bFileID[1] };	

	//
	// TODO:
	// At this point, we could inspect the ATR bytes to see if it matches a Chipknip. 
	// Unfortunately, I don't know how to recognize a Chipknip WITHOUT risking 
	// false-negatives: the ATR string has been varying in the past.
	//

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd.bCla = 0xBC; // CLA = instruction class field (ICC_CLA_TB)
	cmd.bIns = 0xA4; // INS = instruction code (ICC_INS_SEL_EF)
	cmd.bP1  = 0x00; // P1  = parameter 1 (ICC_P1_NONE)
	cmd.bP2  = 0x00; // P2  = parameter 2 (ICC_P2_FIRST)
	cmd.bP3  = 0x02; // P3  = Le (expected size of IO transfer) (ICC_P3_SEL_EF)	
	memcpy(bSend, &cmd, sizeof(cmd));

	bSend[5] = bFileID[0];
	bSend[6] = bFileID[1];

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND) + cmd.bP3; // CLA/INS/P1/P2/P3 is followed by <cmd.bP3> extra command bytes */
	DWORD dwRecvLength = 2;	// we'll only receive 2 status bytes, e.g. 0x9000

	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{		
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Response data = (n/a)");

	// At this point, bRecv should contain 0x9... (=status OK)
	// If the high nibble equals "6", it's likely that an error occured

	// copy response APDU to buffer
	memcpy(pbResponseAPDU, &bRecv, dwExpectedResponseLn);


	/*if (bRecv[0] & 0x60) //0x60 = "6" as left nibble, this would indicate a failure
	{
		//theApp.dlg.WriteToLog("!!! ERROR - See that response APDU? The IEP fabrication file could not be selected! (is this really a Chipknip card?)");
		theApp.dlg.WriteToLog("!!! Error - file not found");
  		// disconnect card
		CardDisconnect();
		return;
	}*/
}

void CChipknip::LOOK_UP_BALANCE(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bFileID[2], CString *psPUR_CURCY)
{
  //-------
  // LOOK_UP_BALANCE command APDU:
  //
  // CLA  = 0xE1 (%C_ICC_CLA_IEP)
  // INS  = 0xB4 (%C_ICC_INS_IEP_BAL)
  // P1   = 0x00 (%C_ICC_P1_NONE)
  // P2   = 0x01 (%C_ICC_P2_CURR), 0x03 (%C_ICC_P2_PREV)
  // P3   = 0x05 (%C_ICC_P3_CURR)
  // ??? Data = File ID (2 bytes)???
  //
  // Known Purse File IDs: 
  //   0x2901 (purse file, %C_ICC_FILE_ID_PURSE)
  //	
  // Preconditions: 
  //   1. none
  //-------


	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	DWORD dwSendLength = 0;			// size of the command APDU
	DWORD dwRecvLength = 0;			// size of the response APDU

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd3;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd3.bCla = 0xE1; // CLA = instruction class field
	cmd3.bIns = 0xB4; // INS = instruction code
	cmd3.bP1  = 0x00; // P1  = parameter 1 
	cmd3.bP2  = 0x01; // P2  = parameter 2
	cmd3.bP3  = 0x05; // P3  = Le (expected size of IO transfer)
	memcpy(bSend, &cmd3, sizeof(cmd3));

	// IEP purse file = 0x2901
	bSend[5] = bFileID[0];
	bSend[6] = bFileID[1];

	dwSendLength = sizeof(SCARD_T0_COMMAND); // CLA/INS/P1/P2/P3 is followed by <cmd.bP3> extra command bytes
	dwRecvLength = 7;	// 3 bytes balance + 2 bytes currency  + 2 bytes status

	theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
	theApp.dlg.WriteToLog("  Response data = {" + theApp.dlg.ConvertBytesToHexString(dwRecvLength-2, &bRecv[0], true) + "}");
	theApp.dlg.WriteToLog("    Purse currency = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[3], true) + "}");

	psPUR_CURCY->Append(theApp.dlg.ConvertBytesToHexString(2, &bRecv[3]));
	theApp.dlg.WriteToLog("    Purse balance  = {" + theApp.dlg.ConvertBytesToHexString(3, bRecv, true) + "} (current balance is " + AnalyzeBalance(theApp.dlg.ConvertBytesToHexString(3, bRecv), psPUR_CURCY->GetString()) + ")");
	
	// copy response APDU to buffer
	memcpy(pbResponseAPDU, &bRecv, dwExpectedResponseLn);
}

void CChipknip::READ_RECORD(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bRecordNr, byte bRefControl, byte pLn, bool bSuppressOutput)
{
  //-------
  // READ_RECORD command APDU:
  //
  // CLA = 0x00 (%C_ICC_CLA_EMV)
  // INS = 0xB2 (%C_ICC_INS_READ_REC)
  // P1  = record number
  // P2  = reference control
  // P3  = 0x00 || "maximum possible length"
  //
  // Preconditions: 
  //   1. some EF must have been selected (SELECT_EF)
  //-------

  // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3}  
}


void CChipknip::READ_DATA(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bOffsetMSB, byte bOffsetLSB, byte bLc, bool bSuppressOutput)
{ 
  //-------
  // READ_DATA command APDU:
  //
  // CLA = 0xBC (%C_ICC_CLA_TB)
  // INS = 0xB0 (%C_ICC_INS_READ_DATA)
  // P1  = MSB of relative address in EF (offset), e.g. 0x00
  // P2  = LSB of relative address in EF (offset), e.g. 0x00
  // P3  = number of bytes to read (size of IO transfer, Lc)
  //
  // Preconditions: 
  //   1. some EF must have been selected (SELECT_EF)
  //-------

  // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3}  

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd2;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd2.bCla = 0xBC; // CLA = instruction class field
	cmd2.bIns = 0xB0; // INS = instruction code
	cmd2.bP1  = bOffsetMSB; // P1  = parameter 1 
	cmd2.bP2  = bOffsetLSB; // P2  = parameter 2
	cmd2.bP3  = bLc; // P3  = Le (expected size of IO transfer)
	memcpy(bSend, &cmd2, sizeof(cmd2));

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND);
	DWORD dwRecvLength = cmd2.bP3 + 2; // Lc + 2 status bytes

	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) 
	{
		theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
		theApp.dlg.WriteToLog("  Response data (hex) = {" + theApp.dlg.ConvertBytesToHexString(dwRecvLength-2, &bRecv[0], true) + "}");
		CString sContents;
		for (UINT i=0; i < (dwRecvLength - 2); i++)
		if (bRecv[i] != 0x00)
			sContents.AppendChar(bRecv[i]);
		theApp.dlg.WriteToLog("  Response data (ASCII) = {" + sContents + "}");
	}
	
	// copy response APDU to buffer
	memcpy(pbResponseAPDU, &bRecv, dwExpectedResponseLn);
}

void CChipknip::UPDATE_DATA(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, byte bOffsetMSB, byte bOffsetLSB, byte bLc, byte *pbNewData, bool bSuppressOutput)
{
  //-------
  // UPDATE_DATA command APDU:
  //
  // CLA = 0xBC (%C_ICC_CLA_TB)
  // INS = 0xD6 (%C_ICC_INS_UPD_DATA)
  // P1  = MSB of first word to be updated || relative address in Working File (of type 0x25)
  // P2  = LSB of first word to be updated || relative address in Working File (of type 0x25)
  // P3  = number of bytes to be updated (0x04 - 0x24) (1-9 words)
  // Data = (new) data to be stored (P3 bytes) (4 to 36 bytes)
  //
  // Preconditions: 
  //   1. some WF of type 25 must have been selected (SELECT_EF)
  //   2. update conditions (if any) in field UPC must have been met
  //   3. The bit UP must be 0.
  //-------

  // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3}  


	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd2;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd2.bCla = 0xBC; // CLA = instruction class field
	cmd2.bIns = 0xD6; // INS = instruction code
	cmd2.bP1  = bOffsetMSB; // P1  = parameter 1 
	cmd2.bP2  = bOffsetLSB; // P2  = parameter 2
	cmd2.bP3  = bLc; // P3  = Le (expected size of IO transfer)

	memcpy(bSend, &cmd2, sizeof(cmd2));
	memcpy(pbSend + sizeof(SCARD_T0_COMMAND), pbNewData, bLc);	
	
	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND) + bLc;
	DWORD dwRecvLength = 2; // Only 2 status bytes
	
	//theApp.dlg.WriteToLog("  bLc= {" + theApp.dlg.ConvertBytesToHexString(1, &bLc, true) + "}");
	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) 
	{
		theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
		theApp.dlg.WriteToLog("  Response data (hex) = {" + theApp.dlg.ConvertBytesToHexString(dwRecvLength-2, &bRecv[0], true) + "}");
		CString sContents;
		for (UINT i=0; i < (dwRecvLength - 2); i++)
		if (bRecv[i] != 0x00)
			sContents.AppendChar(bRecv[i]);
		theApp.dlg.WriteToLog("  Response data (ASCII) = {" + sContents + "}");
	}
	
	// copy response APDU to buffer
	memcpy(pbResponseAPDU, &bRecv, dwExpectedResponseLn);
}


void CChipknip::READ_TRACE(byte *pbResponseAPDU, DWORD dwExpectedResponseLn, int iTraceCmd, byte bLc, CString *psPUR_CURCY, bool bSuppressOutput)
{ 
	//-------
	// READ_TRACE command APDU:
	//
	// CLA = 0xE1 (%C_ICC_CLA_IEP)
	// INS = 0xB6 (%C_ICC_INS_READ_TRACE)
	// P1,P2,P3 = 0x00, 0x01, 0x24 --> first TX_TF
	// P1,P2,P3 = 0x01, 0x01, 0x24 --> first TX_CBF
	// P1,P2,P3 = 0x02, 0x01, 0x0B --> first TX_ITF 
	//
	// NOTES: 
	//    SW = 90 08 -> ICC_SW12_MISS
	//    SW = 6B 00 -> ICC_SW12_BADP1P2
	//
	//    P2 = 0x01 -> current
	//    P2 = 0x03 -> previous
	//
	//    P1,P2,P3 = 0x00, 0x01, 0x24 --> first TX_TF
	//    P1,P2,P3 = 0x01, 0x01, 0x24 --> first TX_CBF
	//    P1,P2,P3 = 0x02, 0x01, 0x0B --> first TX_ITF 
	//
	//    P1,P2,P3 = 0x00, 0x03, 0x24 --> next TX_TF
	//    P1,P2,P3 = 0x01, 0x03, 0x24 --> next TX_CBF
	//    P1,P2,P3 = 0x02, 0x03, 0x0B --> next TX_ITF
	//
	// Preconditions: 
	//   1. 
	//-------

    // Command APDU:   {CLA}  {INS} {P1}  {P2}  {P3}  

	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256+2];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	long lReturn = 0;				// some Smartcard SDK return code

	SCARD_IO_REQUEST ioRecvPci;                        // create IO buffer
	ioRecvPci.dwProtocol = m_dwProtocol;	           // T=0 or T=1
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);  // fixed 

	SCARD_T0_COMMAND cmd6;

	// clear buffers
	ZeroMemory(bRecv, sizeof(bRecv));
	ZeroMemory(bSend, sizeof(bSend));

	// build APDU (in the SCARD_T0_COMMAND struct)
	cmd6.bCla = 0xE1; // CLA = instruction class field
	cmd6.bIns = 0xB6; // INS = instruction code


	switch (iTraceCmd)
	{
	//    P1,P2,P3 = 0x00, 0x01, 0x24 --> first TX_TF
	//    P1,P2,P3 = 0x01, 0x01, 0x24 --> first TX_CBF
	//    P1,P2,P3 = 0x02, 0x01, 0x0B --> first TX_ITF 
	//
	//    P1,P2,P3 = 0x00, 0x03, 0x24 --> next TX_TF
	//    P1,P2,P3 = 0x01, 0x03, 0x24 --> next TX_CBF
	//    P1,P2,P3 = 0x02, 0x03, 0x0B --> next TX_ITF

		case first_TX_TF: 
			cmd6.bP1  = 0x00;
			cmd6.bP2  = 0x01;
			cmd6.bP3  = 0x24; // 0x24 = 36 = 9 words per record
			break;
		case first_TX_CBF: 
			cmd6.bP1  = 0x01;
			cmd6.bP2  = 0x01;
			cmd6.bP3  = 0x24;
			break;
		case first_TX_ITF: 
			cmd6.bP1  = 0x02;
			cmd6.bP2  = 0x01;
			cmd6.bP3  = 0x0B;
			break;
		case next_TX_TF: 
			cmd6.bP1  = 0x00;
			cmd6.bP2  = 0x03;
			cmd6.bP3  = 0x24;
			break;
		case next_TX_CBF: 
			cmd6.bP1  = 0x01;
			cmd6.bP2  = 0x03;
			cmd6.bP3  = 0x24;
			break;
		case next_TX_ITF: 
			cmd6.bP1  = 0x02;
			cmd6.bP2  = 0x03;
			cmd6.bP3  = 0x0B;
			break;
	}
		
	memcpy(bSend, &cmd6, sizeof(cmd6));

	DWORD dwSendLength = sizeof(SCARD_T0_COMMAND);
	DWORD dwRecvLength = cmd6.bP3 + 2;	// 8 bytes purse ID + 2 status bytes

	if (!bSuppressOutput) theApp.dlg.WriteToLog("  Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}");
	lReturn = SCardTransmit(m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );
	if (lReturn != SCARD_S_SUCCESS)
	{
		handleSCardError(lReturn, "SCardTransmit");
		return;
	}
	if (!bSuppressOutput) 
	{
		theApp.dlg.WriteToLog("  Response code = {" + theApp.dlg.ConvertBytesToHexString(2, &bRecv[dwRecvLength-2], true) + "}");
		theApp.dlg.WriteToLog("  Response data = {" + theApp.dlg.ConvertBytesToHexString(dwRecvLength-2, &bRecv[0], true) + "}");
	}

	// IEP File Header: bRecv[0-3]
	// IEP Operating Parameters: bRecv[3+]
	//theApp.dlg.WriteToLog("    IEP File Header = {" + theApp.dlg.ConvertBytesToHexString(2*sizeof(WORD), bRecv, true) + "}");
	if (!bSuppressOutput) 
	{
		theApp.dlg.WriteToLog("    Trace record  = { " + theApp.dlg.ConvertBytesToHexString(bLc, &bRecv[0], true) + "}");
		theApp.dlg.WriteToLog("        * PUR_TX_TYPE    = { " + theApp.dlg.ConvertBytesToHexString(1, &bRecv[0], true) + "} (" + AnalyzePUR_TX_TYPE(bRecv[0]) + ")");
		theApp.dlg.WriteToLog("        * PUR_TX_ERR     = { " + theApp.dlg.ConvertBytesToHexString(1, &bRecv[1], true) + "} (" + AnalyzePUR_TX_ERR(bRecv[1]) + ")");
		theApp.dlg.WriteToLog("        * PUR_BAL        = { " + theApp.dlg.ConvertBytesToHexString(3, &bRecv[2], true) + "} (balance is " + AnalyzeBalance(theApp.dlg.ConvertBytesToHexString(3, &bRecv[2]), psPUR_CURCY->GetString()) + ")");
		theApp.dlg.WriteToLog("        * CHECKSUM       = { " + theApp.dlg.ConvertBytesToHexString(1, &bRecv[5], true) + "}");
		theApp.dlg.WriteToLog("        * IEP_TX_AMT_TOT = { " + theApp.dlg.ConvertBytesToHexString(3, &bRecv[6], true) + "} (amount transferred is " + AnalyzeBalance(theApp.dlg.ConvertBytesToHexString(3, &bRecv[6]), psPUR_CURCY->GetString()) + ")");
		theApp.dlg.WriteToLog("        * PUR_CURCY      = { " + theApp.dlg.ConvertBytesToHexString(2, &bRecv[9], true) + "}");
		theApp.dlg.WriteToLog("        * SAM_ID         = { " + theApp.dlg.ConvertBytesToHexString(4, &bRecv[11], true) + "}");
		theApp.dlg.WriteToLog("        * SAM_STAN       = { " + theApp.dlg.ConvertBytesToHexString(4, &bRecv[15], true) + "}");
		theApp.dlg.WriteToLog("        * CHECKSUM       = { " + theApp.dlg.ConvertBytesToHexString(1, &bRecv[19], true) + "}");
		theApp.dlg.WriteToLog("        * PUR_STAN       = { " + theApp.dlg.ConvertBytesToHexString(2, &bRecv[20], true) + "}");
		theApp.dlg.WriteToLog("        * CHECKSUM       = { " + theApp.dlg.ConvertBytesToHexString(1, &bRecv[22], true) + "}");
		theApp.dlg.WriteToLog("        * GEN_CHECKSUM   = { " + theApp.dlg.ConvertBytesToHexString(1, &bRecv[23], true) + "}");
		theApp.dlg.WriteToLog("        * PUR_TX_LOG     = { " + theApp.dlg.ConvertBytesToHexString(12, &bRecv[24], true) + "}");
	}

	// copy response APDU to buffer
	memcpy(pbResponseAPDU, &bRecv, dwExpectedResponseLn);
}



void CChipknip::DumpInfo()
{
	//
	// TODO:
	// At this point, we could inspect the ATR bytes to see if it matches a Chipknip. 
	// Unfortunately, I don't know how to recognize a Chipknip WITHOUT risking 
	// false-negatives: the ATR string has been varying in the past.
	//

    //===================================
	// Next: select IEP fabrication file
    //===================================

	{
		BYTE bC_ICC_FILE_ID_FAB[2] = {0x17, 0xFF}; 
		BYTE bResponseAPDU[2];
		ZeroMemory(bResponseAPDU, sizeof(bResponseAPDU));
		BYTE *pbResponseAPDU = bResponseAPDU;

		theApp.dlg.WriteToLog("Selecting IEP fabrication file... ");
		SELECT_EF(pbResponseAPDU, sizeof(bResponseAPDU), bC_ICC_FILE_ID_FAB, false);
	}


    //=================================
	// Next: read IEP fabrication file
    //=================================

	{
		const BYTE bLc = 51 * 4; // IEP fabrication contains 51 WORDS (max.)
		BYTE bResponseAPDU[bLc + 2];
		ZeroMemory(bResponseAPDU, sizeof(bResponseAPDU));
		BYTE *pbResponseAPDU = bResponseAPDU;

		theApp.dlg.WriteToLog("Reading IEP fabrication file... ");		
		READ_DATA(pbResponseAPDU, sizeof(bResponseAPDU), 0x00, 0x00, bLc); // fabrication file is 51 words long
	}

    //================================
	// Next: look up purse balance
    //================================
	CString *psPUR_CURCY = new CString();
	{
		BYTE bC_ICC_FILE_ID_PURSE[2] = {0x29, 0x01}; 
		BYTE bResponseAPDU[2];
		ZeroMemory(bResponseAPDU, sizeof(bResponseAPDU));
		BYTE *pbResponseAPDU = bResponseAPDU;

		theApp.dlg.WriteToLog("Looking up the balance... ");
		LOOK_UP_BALANCE(pbResponseAPDU, sizeof(bResponseAPDU), bC_ICC_FILE_ID_PURSE, psPUR_CURCY);
	}
	

    //===================================
	// Next: select IEP purse file
    //===================================

	{
		BYTE bC_ICC_FILE_ID_FAB[2] = {0x29, 0x01}; 
		BYTE bResponseAPDU[2];
		ZeroMemory(bResponseAPDU, sizeof(bResponseAPDU));
		BYTE *pbResponseAPDU = bResponseAPDU;

		theApp.dlg.WriteToLog("Selecting IEP purse file... ");
		SELECT_EF(pbResponseAPDU, sizeof(bResponseAPDU), bC_ICC_FILE_ID_FAB, false);
	}


    //=================================
	// Next: read IEP purse file
    //=================================

	{
		const BYTE bLc = 35 * 4; // IEP purse contains 35 WORDS (max.) = 140 bytes
		BYTE bResponseAPDU[bLc + 2];
		ZeroMemory(bResponseAPDU, sizeof(bResponseAPDU));
		BYTE *pbResponseAPDU = bResponseAPDU;

		theApp.dlg.WriteToLog("Reading IEP purse file... ");		
		READ_DATA(pbResponseAPDU, sizeof(bResponseAPDU), 0x00, 0x00, bLc); // fabrication file is 51 words long

		// IEP File Header: bRecv[0-3]
		// IEP Operating Parameters: bRecv[3+]
		//theApp.dlg.WriteToLog("    IEP File Header = {" + theApp.dlg.ConvertBytesToHexString(2*sizeof(WORD), bRecv, true) + "}");
		theApp.dlg.WriteToLog("    IEP Operating Parameters  = { " + theApp.dlg.ConvertBytesToHexString(bLc, &bResponseAPDU[0], true) + "}");
		theApp.dlg.WriteToLog("        ----- Fixed parameters: -----");
		theApp.dlg.WriteToLog("        * Issuer identity  = { " + theApp.dlg.ConvertBytesToHexString(3, &bResponseAPDU[0], true) + "} (fixed value for Interpay)");
		theApp.dlg.WriteToLog("        * IEP identity     = { " + theApp.dlg.ConvertBytesToHexString(5, &bResponseAPDU[3], true) + "} (left 3 digits are BANK_ID, the rest is a sequence generated during personalization)");
		theApp.dlg.WriteToLog("        * Currency unit    = { " + theApp.dlg.ConvertBytesToHexString(2, &bResponseAPDU[8], true) + "}");
		theApp.dlg.WriteToLog("        * Checksum (fixed) = { " + theApp.dlg.ConvertBytesToHexString(1, &bResponseAPDU[11], true) + "}");
		theApp.dlg.WriteToLog("        ----- Modifiable parameters: -----");
		theApp.dlg.WriteToLog("        * Status of IEP    = { " + theApp.dlg.ConvertBytesToHexString(1, &bResponseAPDU[12], true) + "} (" + AnalyzePUR_STATE(bResponseAPDU[12]) + ")");
		theApp.dlg.WriteToLog("        * Version of keys  = { " + theApp.dlg.ConvertBytesToHexString(1, &bResponseAPDU[13], true) + "}");
		theApp.dlg.WriteToLog("        * Maximum balance  = { " + theApp.dlg.ConvertBytesToHexString(3, &bResponseAPDU[16], true) + "} (=" + AnalyzeBalance(theApp.dlg.ConvertBytesToHexString(3, &bResponseAPDU[16]), psPUR_CURCY->GetString()) + ")");
		theApp.dlg.WriteToLog("        * Debit behind PIN = { " + theApp.dlg.ConvertBytesToHexString(3, &bResponseAPDU[20], true) + "}");
		theApp.dlg.WriteToLog("        * Maximum debit    = { " + theApp.dlg.ConvertBytesToHexString(3, &bResponseAPDU[24], true) + "} (max. balance is " + AnalyzeBalance(theApp.dlg.ConvertBytesToHexString(3, &bResponseAPDU[24]), psPUR_CURCY->GetString()) + ")");

		CString sExpiration;
		sExpiration.Append(theApp.dlg.ConvertBytesToHexString(1, &bResponseAPDU[30]) 
			               + "-" + theApp.dlg.ConvertBytesToHexString(1, &bResponseAPDU[29]) 
			               + "-20" + theApp.dlg.ConvertBytesToHexString(1, &bResponseAPDU[28]) );

		theApp.dlg.WriteToLog("        * Expiration date  = { " + theApp.dlg.ConvertBytesToHexString(3, &bResponseAPDU[28], true) + "} (expires at " + sExpiration + ")");
		theApp.dlg.WriteToLog("        * Activation date  = { " + theApp.dlg.ConvertBytesToHexString(3, &bResponseAPDU[32], true) + "}");
		theApp.dlg.WriteToLog("        * Deactiv. date    = { " + theApp.dlg.ConvertBytesToHexString(3, &bResponseAPDU[36], true) + "}");
		theApp.dlg.WriteToLog("        * Checksum (mod.)  = { " + theApp.dlg.ConvertBytesToHexString(1, &bResponseAPDU[39], true) + "} (checksum of modifiable parameters)");
	
		// PUR_ID_AC_PUB is an interesting target for h4x0ring
		theApp.dlg.WriteToLog("        * RSA certificate  = { " + theApp.dlg.ConvertBytesToHexString(64, &bResponseAPDU[40], true) + "} (PUR_ID_AC_PUB, typically as issued by Interpay and proving this card genuine (or not:-))");

		// bytes 104-106: unknown (67 33 02; )
		theApp.dlg.WriteToLog("        * B104-106 (unknown) = { " + theApp.dlg.ConvertBytesToHexString(3, &bResponseAPDU[104], true) + "}");
		
		// bank account number at 106-109
		theApp.dlg.WriteToLog("        * Bank account nr = { " + theApp.dlg.ConvertBytesToHexString(5, &bResponseAPDU[107], true) + "} (account nr=" + theApp.dlg.ConvertBytesToHexString(5, &bResponseAPDU[107], false)+")");

		theApp.dlg.WriteToLog("        * PUR_ISO2_TRACK = { " + theApp.dlg.ConvertBytesToHexString(11, &bResponseAPDU[112], true) + "}");
		CString sPUR_ISO2_TRACK = ConvertByteToBinaryString(&bResponseAPDU[112], 11);
		theApp.dlg.WriteToLog("           - " + sPUR_ISO2_TRACK);
		//theApp.dlg.WriteToLog("          * Bank account = { " + theApp.dlg.ConvertBytesToHexString(11, &bRecv[112], true) + "}");
	}

    //=================================
	// Next: read trace record #1
    //=================================

	{
		const BYTE bLc = 9*4; // Trace contains 9 WORDS (max.)
		BYTE bResponseAPDU[bLc + 2];
		ZeroMemory(bResponseAPDU, sizeof(bResponseAPDU));
		BYTE *pbResponseAPDU = bResponseAPDU;

		theApp.dlg.WriteToLog("Reading first transaction... ");
		READ_TRACE(pbResponseAPDU, sizeof(bResponseAPDU), first_TX_TF, bLc, psPUR_CURCY); // fabrication file is 51 words long
	}

	//=================================
	// Next: read other trace records
    //=================================

	{
		const BYTE bLc = 9*4; // Trace contains 9 WORDS (max.)
		BYTE bResponseAPDU[bLc + 2];
		ZeroMemory(bResponseAPDU, sizeof(bResponseAPDU));
		BYTE *pbResponseAPDU = bResponseAPDU;

		int j=2;
		while (bResponseAPDU[0] != 0x1F)
		{
			theApp.dlg.WriteToLog("Reading next record... ");
			READ_TRACE(pbResponseAPDU, sizeof(bResponseAPDU), next_TX_TF, bLc, psPUR_CURCY); // fabrication file is 51 words long
		}
	}
}



CString CChipknip::AnalyzePUR_TX_ERR( BYTE bPUR_TX_ERR )
{
	CString sPUR_TX_ERR = theApp.dlg.ConvertBytesToHexString(2, &bPUR_TX_ERR);
	if (sPUR_TX_ERR.Mid(2,1).Compare("0") == 0)
		return "Transaction succeeded";
	if (sPUR_TX_ERR.Mid(2,1).Compare("1") == 0)
		return "Transaction not validated";
	if (sPUR_TX_ERR.Mid(2,1).Compare("2") == 0)
		return "Authentication incorrect";
	if (sPUR_TX_ERR.Mid(2,1).Compare("3") == 0)
		return "Integrity failure";
	else if (bPUR_TX_ERR == 0x04)
		return "Authentication missing";

	return "unknown PUR_TX_ERR";
}

CString CChipknip::AnalyzePUR_TX_TYPE( BYTE bPUR_TX_TYPE )
{
	// last 5 bits are meaningful; first 3 bits are meaningless authentication leftovers
	if ( (bPUR_TX_TYPE & 0x80) && 
			(bPUR_TX_TYPE & 0x40) && 
			(bPUR_TX_TYPE & 0x20) && 
			(bPUR_TX_TYPE & 0x10) && 
			(bPUR_TX_TYPE & 0x08) )
		return "Default type (virgin trace)";
	else if ( 
			!(bPUR_TX_TYPE & 0x80) && 
			(bPUR_TX_TYPE & 0x40) && 
			!(bPUR_TX_TYPE & 0x20) && 
			(bPUR_TX_TYPE & 0x10) && 
			!(bPUR_TX_TYPE & 0x08) )
		return "Update key loading";
	else if ( 
			!(bPUR_TX_TYPE & 0x80) && 
			!(bPUR_TX_TYPE & 0x40) && 
			!(bPUR_TX_TYPE & 0x20) && 
			(bPUR_TX_TYPE & 0x10) && 
			!(bPUR_TX_TYPE & 0x08) )
		return "Update parameter";
	else if ( 
			!(bPUR_TX_TYPE & 0x80) && 
			(bPUR_TX_TYPE & 0x40) && 
			(bPUR_TX_TYPE & 0x20) && 
			!(bPUR_TX_TYPE & 0x10) && 
			!(bPUR_TX_TYPE & 0x08) )
		return "Token type payment terminated";
	else if ( 
			!(bPUR_TX_TYPE & 0x80) && 
			!(bPUR_TX_TYPE & 0x40) && 
			(bPUR_TX_TYPE & 0x20) && 
			!(bPUR_TX_TYPE & 0x10) && 
			!(bPUR_TX_TYPE & 0x08) )
		return "Single debit";
	else if ( 
			!(bPUR_TX_TYPE & 0x80) && 
			(bPUR_TX_TYPE & 0x40) && 
			!(bPUR_TX_TYPE & 0x20) && 
			!(bPUR_TX_TYPE & 0x10) && 
			!(bPUR_TX_TYPE & 0x08) )
		return "First token type payment";
	else if ( 
			!(bPUR_TX_TYPE & 0x80) && 
			!(bPUR_TX_TYPE & 0x40) && 
			!(bPUR_TX_TYPE & 0x20) && 
			!(bPUR_TX_TYPE & 0x10) && 
			!(bPUR_TX_TYPE & 0x08) )
		return "Token type payment";

	return "unknown PUR_TX_TYPE";
}

CString CChipknip::AnalyzeBalance( CString sBalance, CString sCurrency )
{
	CString sReturn;
	char *pcBalance = (char *) (LPCTSTR) sBalance;
    char *pcFoobar = 0;
    long lBalance = strtol(pcBalance, &pcFoobar, 16);
	sReturn.Format("%.2f", lBalance / 100.00);

	if (sCurrency.Compare("0978")==0) // 0x0978 == EURO
		sReturn.Insert(0, "EUR ");

	return sReturn;
}

CString CChipknip::AnalyzePUR_STATE (BYTE bPUR_STATE)
{
	if (bPUR_STATE == 0x00) 
		return "IEP inactive and unlocked";
	else if (bPUR_STATE == 0x01) 
		return "IEP active and unlocked";
	else if (bPUR_STATE == 0x02) 
		return "IEP inactive and locked";
	else if (bPUR_STATE == 0x03) 
		return "IEP active and locked";

	return "unknown PUR_STATE";
}


