
/*

NOTE: this file is borrowed from:
http://www.jstic.com/cypher/3Mac/index.htm

More specifically, from these ZIP-file:
http://www.jstic.com/cypher/3Mac/maclog_source.zip

The source is published with this comment:
"Do whatever you want with this source code, in any case 
I'm not reponsible for what you do with it"

*/

#include "stdafx.h"
#include "scbase.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CSCBase::CSCBase(HANDLE h1,HANDLE h2)
{
	hCom=INVALID_HANDLE_VALUE;
	// create events
	resetEvent = h1; 
	readEvent = h2;
	
	DWORD threadid;
	//start de thread
	stopCommEvent=CreateEvent(NULL,TRUE,FALSE,NULL);
	readyEvent=CreateEvent(NULL,TRUE,FALSE,NULL);
	stopEvent=CreateEvent(NULL,TRUE,FALSE,NULL);
	commEvent=CreateEvent(NULL,TRUE,FALSE,NULL);
	event1=CreateEvent(NULL,TRUE,FALSE,NULL);
	event2=CreateEvent(NULL,TRUE,FALSE,NULL);
	memset(&overl,0x00,sizeof(OVERLAPPED));
	memset(&overl2,0x00,sizeof(OVERLAPPED));
	memset(&overl3,0x00,sizeof(OVERLAPPED));
	overl.hEvent=commEvent;
	overl2.hEvent=event1;
	overl3.hEvent=event2;
	SetEvent(stopCommEvent);
	thread=CreateThread(NULL,NULL,LocalThread,(void*)this,0,&threadid);
}
CSCBase::~CSCBase()
{
	Close();
	SetEvent(stopEvent);
	WaitForSingleObject(thread,INFINITE);
	CloseHandle(stopEvent);
	CloseHandle(readyEvent);
	CloseHandle(commEvent);
	CloseHandle(stopCommEvent);
	CloseHandle(event1);
	CloseHandle(event2);
}
BYTE CSCBase::adapt(BYTE b)
{
	int i;
	BYTE y,mask,mask2,res;

	y=~b;
	mask=0x01;
	mask2=0x80;
	res=0;
	for(i=0;i<8;i++)
	{
	  if (y & mask)
			res|=mask2;
	  mask<<=1;
	  mask2>>=1;
	}
	return res;
}
DWORD CSCBase::LocalThread(LPVOID param)
{
	CSCBase*	scbase = (CSCBase*)param;
	DWORD		wobject,wobject2;
	HANDLE		wevents[3] = {NULL,NULL,NULL};
	
	wevents[0]=scbase->stopEvent;
	wevents[1]=scbase->stopCommEvent;
	wevents[2]=scbase->commEvent;

	while ((wobject=WaitForMultipleObjects(3,wevents,FALSE,INFINITE))!=WAIT_FAILED)
	{
		if (wobject==WAIT_OBJECT_0)
		{
			return 0;
		} 
		else if (wobject==WAIT_OBJECT_0+1)
		{
			ResetEvent(scbase->stopCommEvent);
			SetEvent(scbase->readyEvent);
			wobject2=WaitForMultipleObjects(2,wevents,FALSE,INFINITE);
			if (wobject2==WAIT_OBJECT_0)
				return 0;
			ResetEvent(scbase->stopCommEvent);
		}
		else if (wobject==WAIT_OBJECT_0+2)
		{
			ResetEvent(wevents[2]);
			if (scbase->hCom!=INVALID_HANDLE_VALUE)
			{
				if (scbase->dwEvtMask & EV_RLSD)
				{
					scbase->HandleReset();
				} 
				else if (scbase->dwEvtMask & EV_RXCHAR)
				{
					scbase->HandleRead();
				}
				WaitCommEvent(scbase->hCom,&scbase->dwEvtMask,&scbase->overl);
			}
		}
	}
	return 0;
}
void CSCBase::HandleReset()
{
	SetEvent(resetEvent);
}
void CSCBase::HandleRead()
{
	BOOL	tt;
	DWORD	err;
	tt=SetEvent(readEvent);
	err=GetLastError();
}
DWORD CSCBase::Read(LPVOID buf,DWORD bytes_to_read)
{
	DWORD bytes_read;

	ReadFile(hCom,buf,bytes_to_read,&bytes_read,&overl2);
	GetOverlappedResult(hCom,&overl2,&bytes_read,TRUE);
	return bytes_read;
}
DWORD CSCBase::Write(LPVOID buf,DWORD bytes_to_write)
{
	DWORD bytes_written;
		
	WriteFile(hCom,buf,bytes_to_write,&bytes_written,&overl3);
	
	GetOverlappedResult(hCom,&overl3,&bytes_written,TRUE);
	
	return bytes_written;
}
void CSCBase::SetConfig(const char *serconfig)
{
	DCB		dcb;
	BOOL	fSuccess;
	DWORD	dwError;
	
	if (hCom==INVALID_HANDLE_VALUE)
		return;
	fSuccess = GetCommState(hCom, &dcb);
	if (!fSuccess) 
	{
		AfxMessageBox("GetCommState failed",MB_OK);
		CloseHandle(hCom);
		return;
	}
	fSuccess = BuildCommDCB(serconfig,&dcb);
	if (!fSuccess) 
	{
		AfxMessageBox("BuildCommDCB failed",MB_OK);
		CloseHandle(hCom);
		return;
	}
	fSuccess = SetCommState(hCom, &dcb);
	if (!fSuccess) 
	{
		dwError=GetLastError();
		AfxMessageBox("SetCommState failed",MB_OK);
		CloseHandle(hCom);
		return;
	}
	
	WaitCommEvent(hCom,&dwEvtMask,&overl);
	SetEvent(stopCommEvent);
}
void CSCBase::Disable()
{
	SetEvent(stopCommEvent);
	WaitForSingleObject(readyEvent,INFINITE);
	ResetEvent(readyEvent);
}
void CSCBase::Close()
{
	if (hCom==INVALID_HANDLE_VALUE)
		return;

	SetEvent(stopCommEvent);
	WaitForSingleObject(readyEvent,INFINITE);
	ResetEvent(readyEvent);
	CloseHandle(hCom);
	hCom=INVALID_HANDLE_VALUE;
}
int CSCBase::Open(const char *serconfig)
{
	COMMTIMEOUTS	timeouts;
	char			string[16];
	BOOL			fSuccess;

	if (hCom!=INVALID_HANDLE_VALUE)
		Close();

	memcpy(string,serconfig,4);
	string[4]=0x00;
	hCom = CreateFile(string,GENERIC_READ | GENERIC_WRITE,
					   0, NULL,OPEN_EXISTING,FILE_FLAG_OVERLAPPED,NULL);
	if (hCom == INVALID_HANDLE_VALUE)
	{    
		AfxMessageBox("Could not open COM port!",MB_OK);
		return 0;
	}
	fSuccess = SetupComm(hCom,1024,1024);
	if (!fSuccess) 
	{
		AfxMessageBox("SetupComm failed",MB_OK);
		CloseHandle(hCom);
		return 0;
	}
	fSuccess = GetCommTimeouts(hCom,&timeouts);
	if (!fSuccess) 
	{
		AfxMessageBox("GetCommTimeouts failed",MB_OK);
		CloseHandle(hCom);
		return 0;
	}
	timeouts.ReadIntervalTimeout=MAXDWORD;
	fSuccess = SetCommTimeouts(hCom,&timeouts);
	if (!fSuccess) 
	{
		AfxMessageBox("SetCommTimeouts failed",MB_OK);
		CloseHandle(hCom);
		return 0;
	}
	fSuccess = SetCommMask(hCom,EV_RXCHAR|EV_RLSD);
	if (!fSuccess) 
	{
		AfxMessageBox("SetCommMask failed",MB_OK);
		CloseHandle(hCom);
		return 0;
	}
	return 1;
}
