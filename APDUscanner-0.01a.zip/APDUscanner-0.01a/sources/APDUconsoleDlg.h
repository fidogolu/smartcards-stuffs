#pragma once
#include "afxwin.h"
#include "smartcard.h"

// CAPDUConsoleDlg dialog

class CAPDUConsoleDlg : public CDialog
{
	DECLARE_DYNAMIC(CAPDUConsoleDlg)

public:
	//CAPDUConsoleDlg(CWnd* pParent = NULL);   // standard constructor
	CAPDUConsoleDlg(CWnd* pParent, CSmartCard *m_pSmartCardMAIN );
	virtual ~CAPDUConsoleDlg();
	
	CSmartCard *m_pSmartCard;

// Dialog Data
	enum { IDD = IDD_APDUCONSOLE_DIALOG};

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CButton c_btnSendAPDU;
	afx_msg void OnBnClickedBtnsendapdu();
	CEdit c_txtSendAPDU;
	CEdit c_txtOutput;
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedOk();
	void WriteToConsole(LPCTSTR pszMessage, BOOL bSameLine=false);
	void SendAPDU(CString sCommandAPDU, byte *pbSW12=NULL);
	afx_msg void OnEnChangeTxtapdu();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnBnClickedBtnreconnect();
	CButton c_btnSendAPDU2;
	CButton c_btnSendAPDU3;
	CEdit c_txtSendAPDU2;
	CEdit c_txtSendAPDU3;
	afx_msg void OnBnClickedBtnsendapdu2();
	afx_msg void OnBnClickedBtnsendapdu3();
	afx_msg void OnEnChangeTxtapdu2();
	afx_msg void OnEnChangeTxtapdu3();
	afx_msg void OnEnSetfocusTxtapdu();
	afx_msg void OnEnSetfocusTxtapdu2();
	afx_msg void OnEnSetfocusTxtapdu3();
};
