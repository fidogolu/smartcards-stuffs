/*
* Copyright (c) 2006, Matthijs Koot (matthijs at koot.biz)
* All rights reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the Koot Organization nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================

  COMMANDSCANNER.CPP

  License     : BSD-style (yep, just sell it!)
  Author      : Matthijs Koot (matthijs at koot.biz)
  Description : This CCommandScanner class implements the command scanner,
                which sends command APDUs to the card to see how the card
				responds. It basically does a sequential brute-force by
				trying all possible CLA/INS/P1/P2/P3 combinations (and
				D1/D2 combinations if selected).

  History :
     2007-12-28, mrkoot: file created

  Remarks :
    - none

===============================================================================*/


#include "StdAfx.h"

#include "APDUScanner.h"
#include "APDUScannerDlg.h"

#include "smartcard.h"
#include "commandscanner.h"

#define CHAR_TO_HEX_DIGIT(c)  (((c) >= '0' && (c) <= '9') ? (c) - '0' : (c) - 'A' + 10) 


CCommandScanner::CCommandScanner(void)
{
}

CCommandScanner::~CCommandScanner(void)
{
}


/*---------------------------------------------------------------------
  Name   : APDUScannerThread()
  Param  : (LPVOID) param
  Pre    : -
  Post   : -
  Return : 0

  Description:
    This is the actual code for brute force command APDU trials.
---------------------------------------------------------------------*/
UINT CCommandScanner::APDUScannerThread(LPVOID param)  // defines what our threads actually do
{
	theApp.dlg.m_bAPDUScannerThreadIsRunning = true;

    BYTE bRawATR[60];
	DWORD dwATRlen=0;
    ZeroMemory( bRawATR, 60 );

	// if APDU console is visible, try to use the already activated card
	if (!theApp.dlg.m_pdlgAPDUconsole->IsWindowVisible())
	{ // only prepare the card, if it APDU console is visible, use its
		if (!theApp.dlg.m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen ))
		{
			theApp.dlg.m_pSmartCard->CardDisconnect();
			theApp.dlg.OnBnClickedBtnstop();
			TerminateThread(GetCurrentThread(), -1);
			return -1; // never reached due to TerminateThread
		}
	}
    //theApp.dlg.WriteToLog( "Answer-To-Reset: " + theApp.dlg.ConvertBytesToHexString( dwATRlen 60, bRawATR, true ) + "\r\n", true );	
	theApp.dlg.WriteToLog( "Answer-To-Reset: " + theApp.dlg.ConvertBytesToHexString( dwATRlen, bRawATR, true ) + "\r\n", true );	

	SCARD_IO_REQUEST ioRecvPci;							// create IO buffer
	ioRecvPci.dwProtocol = SCARD_PROTOCOL_T0;			// fixed 
	ioRecvPci.cbPciLength = sizeof(SCARD_IO_REQUEST);

	SCARD_T0_COMMAND cmd;			// APDU struct (well, Microsoft didn't provide it for nothing)
	BYTE bSend[128+5];				// command APDU buffer (may contain more bytes than the SCARD_T0_COMMAND struct can provide for)
	BYTE bRecv[256];				// response APDU buffer
	LPBYTE pbSend = bSend;			// pointer to APDU command buffer
	LPBYTE pbRecv = bRecv;			// pointer to APDU response buffer

	DWORD dwSendLength = 0;			// size of the command APDU
	DWORD dwRecvLength = 0;			// size of the response APDU

	long lReturn;				// some Smartcard SDK return code

	//BYTE bCla=0x00, bIns=0x00, bP1=0x00, bP2=0x00, bP3=0x00;

	// default APDU sequence ranges
	BYTE bCla_MIN = 0x00;
	BYTE bCla_MAX = 0xFF;
	
	BYTE bIns_MIN = 0x00;
	BYTE bIns_MAX = 0xFF;

	BYTE bP1_MIN = 0x00;
	BYTE bP1_MAX = 0xFF;

	BYTE bP2_MIN = 0x00;
	BYTE bP2_MAX = 0xFF;
	
	BYTE bP3_MIN = 0x00;
	BYTE bP3_MAX = 0xFF;


//----------
	BYTE bD1_MIN = 0x00;
	BYTE bD1_MAX = 0xFF;

	BYTE bD2_MIN = 0x00;
	BYTE bD2_MAX = 0xFF;
//----------


	// Fix the CLA byte?
	if (theApp.dlg.c_chkFixCLA.GetCheck()==1)
	{
		CString sCLA;
		theApp.dlg.c_cbCLA.GetWindowText(sCLA);

		if (sCLA.Compare("") != 0)
  			bCla_MIN = bCla_MAX = (CHAR_TO_HEX_DIGIT(sCLA.GetAt(0)) << 4) // low nibble
								 + CHAR_TO_HEX_DIGIT(sCLA.GetAt(1)) ;     // high nibble
	}

	// Fix the INS byte?
	if (theApp.dlg.c_chkFixINS.GetCheck()==1)
	{
		CString sINS;
		theApp.dlg.c_cbINS.GetWindowText(sINS);
		
		if (sINS.Compare("") != 0)
			bIns_MIN = bIns_MAX = (CHAR_TO_HEX_DIGIT(sINS.GetAt(0)) << 4) // low nibble
								 + CHAR_TO_HEX_DIGIT(sINS.GetAt(1)) ;     // high nibble
	}

	// --- Fixed P1 value?
	if (theApp.dlg.c_chkFixP1.GetCheck()==1)
	{
		CString sP1;
		theApp.dlg.c_cbP1.GetWindowText(sP1);
		
		if (sP1.Compare("") != 0)
			bP1_MIN = bP1_MAX = (CHAR_TO_HEX_DIGIT(sP1.GetAt(0)) << 4) // low nibble
							   + CHAR_TO_HEX_DIGIT(sP1.GetAt(1)) ;     // high nibble
	}

	// --- Fixed P2 value?
	if (theApp.dlg.c_chkFixP2.GetCheck()==1)
	{
		CString sP2;
		theApp.dlg.c_cbP2.GetWindowText(sP2);
		
		if (sP2.Compare("") != 0)
			bP2_MIN = bP2_MAX = (CHAR_TO_HEX_DIGIT(sP2.GetAt(0)) << 4) // low nibble
				               + CHAR_TO_HEX_DIGIT(sP2.GetAt(1)) ;     // high nibble
	}
	
	// --- Fixed P3/Le value?
	if (theApp.dlg.c_chkFixP3.GetCheck()==1)
	{
		CString sP3;
		theApp.dlg.c_cbP3.GetWindowText(sP3);
		
		if (sP3.Compare("") != 0)
			bP3_MIN = bP3_MAX = (CHAR_TO_HEX_DIGIT(sP3.GetAt(0)) << 4) // low nibble
                               + CHAR_TO_HEX_DIGIT(sP3.GetAt(1)) ;     // high nibble
	}



//----------
	// --- Fixed D1 value?
	if (theApp.dlg.c_chkScanD1.GetCheck()==1)		
	{
		if (theApp.dlg.c_chkFixD1.GetCheck()==1)
		{ // fix D1
			CString sD1;
			theApp.dlg.c_cbD1.GetWindowText(sD1);
			
			if (sD1.Compare("") != 0)
				bD1_MIN = bD1_MAX = (CHAR_TO_HEX_DIGIT(sD1.GetAt(0)) << 4) // low nibble
								+ CHAR_TO_HEX_DIGIT(sD1.GetAt(1)) ;     // high nibble
		}
	} else // don't scan D1
		bD1_MIN = bD1_MAX = 0x00;
	
	// --- Fixed D2 value?
	if (theApp.dlg.c_chkScanD2.GetCheck()==1)		
	{
		if (theApp.dlg.c_chkFixD2.GetCheck()==1)
		{ // fix D2
			CString sD2;
			theApp.dlg.c_cbD2.GetWindowText(sD2);
			
			if (sD2.Compare("") != 0)
				bD2_MIN = bD2_MAX = (CHAR_TO_HEX_DIGIT(sD2.GetAt(0)) << 4) // low nibble
								+ CHAR_TO_HEX_DIGIT(sD2.GetAt(1)) ;     // high nibble
		}
	} else // don't scan D2
			bD2_MIN = bD2_MAX = 0x00;
//----------



	// Perform sequential APDU scan
	int iCla=0,iIns=0,iP1=0,iP2=0,iP3=0,iD1=0,iD2=0;

	// !!!! TBD: FixD1 and FixD2 don't work for 0x00
	for (iD2 = bD2_MIN; iD2 <= bD2_MAX; iD2++)
	{
		BYTE bD2 = intToByte(iD2);
		//::OutputDebugString("D2\r\n");

		for (iD1 = bD1_MIN; iD1 <= bD1_MAX; iD1++)
		{
			BYTE bD1 = intToByte(iD1);
			//::OutputDebugString("D2 D1\r\n");

			for (iP3 = bP3_MIN; iP3 <= bP3_MAX; iP3++)
			{  // CLA (...)
				BYTE bP3 = intToByte(iP3);
				//::OutputDebugString("D2 D1 P3\r\n");

				for (iP2 = bP2_MIN; iP2 <= bP2_MAX; iP2++)
				{ // CLA INS (...)
					BYTE bP2 = intToByte(iP2);
					//::OutputDebugString("D2 D1 P3 P2\r\n");
			  
					for (iP1 = bP1_MIN; iP1 <= bP1_MAX; iP1++)
					{ // CLA INS P1 (...)
						BYTE bP1 = intToByte(iP1);
						//::OutputDebugString("D2 D1 P3 P2 P1\r\n");

						for (iIns = bIns_MIN; iIns <= bIns_MAX; iIns++)
						{ // CLA INS P1 P2 (...)
							BYTE bINS = intToByte(iIns);
							//::OutputDebugString("D2 D1 P3 P2 P1 INS\r\n");

							for (iCla = bCla_MIN; iCla <= bCla_MAX; iCla++)
							{ // CLA INS P1 P2 P3(...)
								BYTE bCLA = intToByte(iCla);
								//::OutputDebugString("D2 D1 P3 P2 P1 INS CLA\r\n");

								if (theApp.dlg.m_bAPDUScannerThreadIsRunning == false)
								{
									theApp.dlg.m_pSmartCard->CardDisconnect();
									TerminateThread(GetCurrentThread(), 0);
								}

								//WaitForSingleObject(theApp.dlg.hMutex, INFINITE);

								// clear buffers
								ZeroMemory(bRecv, sizeof(bRecv));
								ZeroMemory(bSend, sizeof(bSend));

								// build APDU (in the SCARD_T0_COMMAND struct)
								cmd.bCla = bCLA;	// CLA = instruction class field
								cmd.bIns = bINS;	// INS = instruction code
								cmd.bP1  = bP1;	    // P1  = parameter 1 
								cmd.bP2  = bP2;	    // P2  = parameter 2
								cmd.bP3  = bP3;	    // P3  = Le (expected size of IO transfer)
								memcpy(bSend, &cmd, sizeof(cmd));

								// TBD: fix buggy logic
								//      (i.e. when only ScanP2/FixP2 is checked)
								//if ((bP3 != 0x02) && (bD1 == 0x00) && (bD2 == 0x00))
								if ((bD1 == 0x00) && (bD2 == 0x00) &&
									(theApp.dlg.c_chkScanD1.GetCheck()!=1) && 
									(theApp.dlg.c_chkScanD2.GetCheck()!=1))
								{
									dwSendLength = sizeof(SCARD_T0_COMMAND);
									//dwSendLength = sizeof(SCARD_T0_COMMAND) + cmd.bP3;
								}
								else
								{
									dwSendLength = sizeof(SCARD_T0_COMMAND) + 2;
									bSend[5]=bD1;
									bSend[6]=bD2;
								}

								dwRecvLength = 256;	// Great Expectations! :-)

								lReturn = SCardTransmit( theApp.dlg.m_pSmartCard->m_hSCardHandle, SCARD_PCI_T0, pbSend, dwSendLength, &ioRecvPci, pbRecv, &dwRecvLength );

								// At this point, bRecv should contain 0x9... (=status OK)
								// If the high nibble equals "6", it's likely that an error occured
								CString sLastAPDU = "Command APDU = {" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + 
									"}, Response APDU = " + theApp.dlg.ConvertBytesToHexString(dwRecvLength, &bRecv[0], true);
				
								theApp.dlg.c_txtCurrentAPDU.SetWindowText(sLastAPDU);

								
								if ((theApp.dlg.m_pSmartCard->ResponseIsOK(bRecv[0], bRecv[1], false) || bRecv[0]!=0x6b)
									//&& ((bRecv[0] != 0x9F) ||(bRecv[1] != 0x08))
									&& ((bRecv[0] != 0x94) ||(bRecv[1] != 0x04))
									&& ((bRecv[0] != 0x00) ||(bRecv[1] != 0x00)))
								{
									
									//theApp.dlg.WriteToLog("!!! VERBOSE: command-APDU={" + theApp.dlg.ConvertBytesToHexString(dwSendLength, bSend, true) + "}, response-APDU={" + theApp.dlg.ConvertBytesToHexString(128, bRecv, true) + "}", false, false);
									theApp.dlg.WriteToLog("!!! PERHAPS INTERESTING: " + sLastAPDU);

									CString sContents;
									for (UINT i=0; i < (dwRecvLength - 2); i++)
									if (bRecv[i] != 0x00)
										sContents.AppendChar(bRecv[i]);
									theApp.dlg.WriteToLog("  --> ASCII: " + sContents, true);
								}

								if (lReturn != SCARD_S_SUCCESS)
								{ /* we failed miserably */
									//memcpy(pRetBuffer, &bRecv, sizeof(bRecv));
								}
								else
								{
									//memcpy(pRetBuffer, &bRecv, sizeof(bRecv));
								}

								// refresh connection (cleaner, but slower!)
								if (theApp.dlg.c_chkReconnect.GetCheck()==1)
								{
									theApp.dlg.m_pSmartCard->CardDisconnect();
									theApp.dlg.m_pSmartCard->PrepareCard( false, bRawATR, &dwATRlen );
								}

							} // CLA
						} // INS
					} // P1
				} // P2
			} // P3
		} // D1
	} // D2


    /*------
    clean up */

	// if APDU console is visible, leave the card connected for reuse
	if (!theApp.dlg.m_pdlgAPDUconsole->IsWindowVisible())
	{
		theApp.dlg.m_pSmartCard->CardDisconnect();
	}

	char dateStr [9];
    char timeStr [9];
    _strdate(dateStr);
    _strtime(timeStr);
    theApp.dlg.WriteToLog("------ Command APDU scan completed on " + CString(dateStr) + " at " + CString(timeStr));
    theApp.dlg.WriteToLog("===========================================================");

	theApp.dlg.m_bAPDUScannerThreadIsRunning = false;

	// enable GUI
	theApp.dlg.ToggleGUI(false);

	CString sCurrentAPDU;
	theApp.dlg.c_txtCurrentAPDU.GetWindowText(sCurrentAPDU);
	theApp.dlg.c_txtCurrentAPDU.SetWindowText("");

	AfxEndThread(0);
    return 0;
}
