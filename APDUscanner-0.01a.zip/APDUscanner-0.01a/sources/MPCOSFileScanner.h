#pragma once

#include "APDUScanner.h"
#include "APDUScannerDlg.h"

#include "smartcard.h"
#include "filescanner.h"

class CMPCOSFileScanner : virtual public CFileScanner
{
public:
	static UINT FileScannerThread (LPVOID param);

	void StartScan();

	void TrySelectMF();
	void TrySelectDF();
	void TrySelectEF();

	void TryReadDF();
	void TryReadEF();
	CMPCOSFileScanner(void);
	~CMPCOSFileScanner(void);
};
